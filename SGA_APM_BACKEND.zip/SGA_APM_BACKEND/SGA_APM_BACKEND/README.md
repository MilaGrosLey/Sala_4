# SGA_APM (Sistema de Gestión Asistencias - APM)

SGA_APM es un sistema backend construido con Laravel 12 que provee una API RESTful para la gestión de asistencias, usuarios, espacios de trabajo (workspaces), códigos de asistencia, procesos de registro y otras entidades relacionadas.

## Características principales

- Autenticación y autorización con Laravel Sanctum
- Roles y permisos con Spatie Laravel Permissions
- Generación y validación de códigos de asistencia
- Registro de asistencia (check-in y check-out) con lógica de horario y zonas horarias
- Gestión de entidades: usuarios, workspaces, carreras, provincias, regiones, países, distritos, tipos de documentos, códigos de reinicio de contraseña, etc.
- Documentación de controladores con PHPDoc

## Requisitos

- PHP >= 8.1 (con extensiones: pdo, mbstring, tokenizer, xml, ctype, json, bcmath)
- Composer (para dependencias PHP)
- MySQL (Workbench o XAMPP)
- Git (para clonar el repositorio)
- Hoppscotch o Postman (para testear la API)

## Instalación y puesta en marcha

1. Clonar el repositorio:
   ```bash
   git clone <repo-url> sga-apm
   cd sga-apm
   ```

2. Instalar dependencias PHP con Composer:
   ```bash
   composer install
   ```

3. Copiar archivo de entorno y configurar variables:
   ```bash
   cp .env.example .env
   ```
   Ajustar en `.env`:
   - APP_NAME, APP_URL (opcional)
   - DB_CONNECTION, DB_DATABASE, DB_USERNAME, DB_PASSWORD
   - MAIL_MAILER, MAIL_HOST, MAIL_PORT, MAIL_USERNAME, MAIL_PASSWORD, MAIL_ENCRYPTION, MAIL_FROM_ADDRESS, MAIL_FROM_NAME="APM INVERSIONES E.I.R.L"

4. Generar clave de aplicación:
   ```bash
   php artisan key:generate
   ```

5. Migraciones y seeders:
   ```bash
   php artisan migrate --seed
   ```

6. Ejecutar servidor local:
   ```bash
   php artisan serve
   ```
   La API estará disponible en `http://127.0.0.1:8000`.


## Comandos extras

- Restauración total de la base de datos (elimina todas las tablas y las vuelve a crear):
  ```bash
  php artisan migrate:fresh --seed
  ```

- Limpiar cachés:
   - Regenera todos los cachés (config, rutas y vistas):
   ```bash
   php artisan optimize
   ```
   - Limpia todos los cachés generados por Laravel:
   ```bash
   php artisan optimize:clear
   ```

- Listar rutas registradas:
  ```bash
  php artisan route:list
  ```

## Pruebas (opcional)

- Para ejecutar pruebas unitarias y de integración:
  ```bash
  php artisan test
  ```

## Estructura principal del proyecto

Ver [docs/STRUCTURE.md](docs/STRUCTURE.md) para más detalles sobre la organización de carpetas, rutas y flujo de la aplicación.

## Bibliotecas y paquetes utilizados

Ver [docs/LIBRARIES.md](docs/LIBRARIES.md) para una lista de dependencias y su propósito.

---