<?php

use App\Http\Controllers\Auth\AuthenticatedController;
use App\Http\Controllers\Auth\PasswordResetCodeController;
use Illuminate\Support\Facades\Route;

Route::group([
    'middleware' => 'guest',
], static function () {
    Route::post('login', [AuthenticatedController::class, 'store']);
});

Route::group([
    'middleware' => 'auth:sanctum',
], static function () {
    Route::post('password/send-code', [PasswordResetCodeController::class, 'sendCode']);
    Route::post('password/reset', [PasswordResetCodeController::class, 'resetPassword']);
    Route::delete('logout', [AuthenticatedController::class, 'destroy']);
});
