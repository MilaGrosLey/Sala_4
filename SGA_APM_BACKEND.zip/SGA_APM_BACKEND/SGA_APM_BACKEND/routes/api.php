<?php

use App\Http\Controllers\Api\AttendanceCodeController;
use App\Http\Controllers\Api\AttendanceController;
use App\Http\Controllers\Api\AttendanceStatusController;
use App\Http\Controllers\Api\CareerController;
use App\Http\Controllers\Api\CountryController;
use App\Http\Controllers\Api\DistrictController;
use App\Http\Controllers\Api\DocumentTypeController;
use App\Http\Controllers\Api\EmailVerificationController;
use App\Http\Controllers\Api\InternshipController;
use App\Http\Controllers\Api\ProvinceController;
use App\Http\Controllers\Api\RecurringJustificationController;
use App\Http\Controllers\Api\RegionController;
use App\Http\Controllers\Api\RegistrationCodeController;
use App\Http\Controllers\Api\SkillController;
use App\Http\Controllers\Api\TechnicalAreaController;
use App\Http\Controllers\Api\UserController;
use App\Http\Controllers\Api\UserWorkspaceController;
use App\Http\Controllers\Api\WorkspaceController;
use App\Http\Controllers\Api\WorkspaceTypeController;
use Illuminate\Support\Facades\Route;

Route::group(['middleware' => 'auth:sanctum'], function () {

    // AttendanceCodeController Routes
    Route::group([
        'prefix'     => 'attendance-codes',
        'controller' => AttendanceCodeController::class,
    ], function () {
        Route::get('/', 'index');
        Route::post('/generate', 'generateCode');
        Route::get('/{attendanceCode}', 'show');
        Route::delete('/{attendanceCode}', 'destroy');
    });

    // AttendanceController Routes
    Route::group([
        'prefix'     => 'attendances',
        'controller' => AttendanceController::class,
    ], function () {
        Route::get('/', 'index');
        Route::get('/{attendance}', 'show');
        Route::post('/', 'store');
        Route::patch('/checkout', 'checkout');
        Route::delete('/{attendance}', 'destroy');
    });

    // AttendanceStatusController Routes
    Route::group([
        'prefix'     => 'attendance-statuses',
        'controller' => AttendanceStatusController::class,
    ], function () {
        Route::get('/', 'index');
        Route::post('/', 'store');
        Route::get('/{attendanceStatus}', 'show');
        Route::patch('/{attendanceStatus}', 'update');
        Route::delete('/{attendanceStatus}', 'destroy');
    });

    // CareerController Routes
    Route::group([
        'prefix'     => 'careers',
        'controller' => CareerController::class,
    ], function () {
        Route::get('/', 'index');
        Route::post('/', 'store');
        Route::get('/{career}', 'show');
        Route::patch('/{career}', 'update');
        Route::delete('/{career}', 'destroy');
    });

    // CountryController Routes
    Route::group([
        'prefix'     => 'countries',
        'controller' => CountryController::class,
    ], function () {
        Route::get('/', 'index');
        Route::post('/', 'store');
        Route::get('/{country}', 'show');
        Route::patch('/{country}', 'update');
        Route::delete('/{country}', 'destroy');
    });

    // DistrictController Routes
    Route::group([
        'prefix'     => 'districts',
        'controller' => DistrictController::class,
    ], function () {
        Route::get('/', 'index');
        Route::post('/', 'store');
        Route::get('/{province}', 'showByProvince');
        Route::patch('/{district}', 'update');
        Route::delete('/{district}', 'destroy');
    });

    // DocumentTypeController Routes
    Route::group([
        'prefix'     => 'document-types',
        'controller' => DocumentTypeController::class,
    ], function () {
        Route::get('/', 'index');
        Route::post('/', 'store');
        Route::get('/{documentType}', 'show');
        Route::patch('/{documentType}', 'update');
        Route::delete('/{documentType}', 'destroy');
    });

    // EmailVerificationController Routes
    Route::group([
        'prefix'     => 'email-verifications',
        'controller' => EmailVerificationController::class,
    ], function () {
        Route::get('/', 'index');
        Route::post('/', 'store');
        Route::get('/{emailVerification}', 'show');
        Route::patch('/{emailVerification}', 'update');
        Route::delete('/{emailVerification}', 'destroy');
    });

    // InternshipController Routes
    Route::group([
        'prefix'     => 'internships',
        'controller' => InternshipController::class,
    ], function () {
        Route::get('/', 'index');
        Route::post('/', 'store');
        Route::get('/{internship}', 'show');
        Route::patch('/{internship}', 'update');
        Route::delete('/{internship}', 'destroy');
    });

    // ProvinceController Routes
    Route::group([
        'prefix'     => 'provinces',
        'controller' => ProvinceController::class,
    ], function () {
        Route::get('/', 'index');
        Route::post('/', 'store');
        Route::get('/{region}', 'showByRegion');
        Route::patch('/{province}', 'update');
        Route::delete('/{province}', 'destroy');
    });

    // RecurringJustificationController Routes
    Route::group([
        'prefix'     => 'recurring-justifications',
        'controller' => RecurringJustificationController::class,
    ], function () {
        Route::get('/', 'index');
        Route::post('/', 'store');
        Route::get('/{recurringJustification}', 'show');
        Route::patch('/{recurringJustification}', 'update');
        Route::delete('/{recurringJustification}', 'destroy');
    });

    // RegionController Routes
    Route::group([
        'prefix'     => 'regions',
        'controller' => RegionController::class,
    ], function () {
        Route::get('/', 'index');
        Route::post('/', 'store');
        Route::get('/{region}', 'show');
        Route::patch('/{region}', 'update');
        Route::delete('/{region}', 'destroy');
    });

    // RegistrationCodeController Routes
    Route::group([
        'prefix'     => 'registration-codes',
        'controller' => RegistrationCodeController::class,
    ], function () {
        Route::post('/generate-code', 'generateCode');
        Route::post('/verify-code', 'verifyCode');
    });

    // SkillController Routes
    Route::group([
        'prefix'     => 'skills',
        'controller' => SkillController::class,
    ], function () {
        Route::get('/', 'index');
        Route::post('/', 'store');
        Route::get('/{skill}', 'show');
        Route::patch('/{skill}', 'update');
        Route::delete('/{skill}', 'destroy');
    });

    // WorkspaceController Routes
    Route::group([
        'prefix'     => 'workspaces',
        'controller' => WorkspaceController::class,
    ], function () {
        Route::get('/', 'index');
        Route::post('/', 'store');
        Route::get('/{workspace}', 'show');
        Route::patch('/{workspace}', 'update');
        Route::delete('/{workspace}', 'destroy');
    });

    // TechnicalAreaController Routes
    Route::group([
        'prefix'     => 'technical-areas',
        'controller' => TechnicalAreaController::class,
    ], function () {
        Route::get('/', 'index');
        Route::post('/', 'store');
        Route::get('/{technicalArea}', 'show');
        Route::patch('/{technicalArea}', 'update');
        Route::delete('/{technicalArea}', 'destroy');
    });

    // UserController Routes
    Route::group([
        'prefix'     => 'users',
        'controller' => UserController::class,
    ], function () {
        Route::get('/', 'index');
        Route::get('/search', 'searchUsers');
        Route::get('/{user}', 'show');
        Route::patch('/{user}', 'update');
        Route::delete('/{user}', 'destroy');
    });

    Route::group([
        'prefix'     => 'user-workspace',
        'controller' => UserWorkspaceController::class,
    ], function () {
        Route::get('/', 'index');
        Route::get('/roles', 'getWorkspaceRoles');
        Route::get('/{workspace}', 'show');
        Route::post('/assign', 'assignUserToWorkspace');
        Route::patch('/sync', 'syncWorkspaceMembers');
    });

    // WorkspaceTypeController Routes
    Route::group([
        'prefix'     => 'workspace-types',
        'controller' => WorkspaceTypeController::class,
    ], function () {
        Route::get('/', 'index');
        Route::post('/', 'store');
        Route::get('/{workspaceType}', 'show');
        Route::patch('/{workspaceType}', 'update');
        Route::delete('/{workspaceType}', 'destroy');
    });

});

Route::post('users', [UserController::class, 'store']);
