<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Código de recuperación</title>
</head>
<body style="font-family: Arial, sans-serif; background-color: #f7f7f7; padding: 20px;">
    <div style="background: white; padding: 30px; border-radius: 10px; max-width: 600px; margin: auto;">
        <h2 style="color: #333;">Hola,</h2>
        <p>Recibiste este mensaje porque solicitaste restablecer tu contraseña en <strong>{{ $appName }}</strong>.</p>
        <p>Tu código de recuperación es:</p>
        <div style="font-size: 24px; font-weight: bold; margin: 20px 0;">{{ $code }}</div>
        <p>Este código expirará en 15 minutos.</p>
        <p>Si no solicitaste este cambio, puedes ignorar este mensaje.</p>
        <br>
        <p style="color: #777;">— El equipo de {{ $appName }}</p>
    </div>
</body>
</html>
