<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('team_user', function (Blueprint $table) {
            $table->dropForeign(['team_id']);
            $table->dropForeign(['user_id']);
            $table->dropUnique('team_user_team_id_user_id_unique');
        });

        Schema::table('team_user', function (Blueprint $table) {
            $table->renameColumn('team_id', 'workspace_id');
        });

        Schema::rename('teams', 'workspaces');
        Schema::rename('team_user', 'user_workspace');

        Schema::table('user_workspace', function (Blueprint $table) {
            $table->foreign('user_id')->references('id')->on('users')->onDelete('cascade');
            $table->foreign('workspace_id')->references('id')->on('workspaces')->onDelete('cascade');
            $table->unique(['user_id', 'workspace_id']);
        });

        Schema::table('user_workspace', function (Blueprint $table) {
            $table->unsignedBigInteger('workspace_id')->after('user_id')->change();
        });

        Schema::table('user_workspace', function (Blueprint $table) {
            $table->string('role')->default('member')->after('workspace_id');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        // 1. Eliminar foreign keys y el índice unique
        Schema::table('user_workspace', function (Blueprint $table) {
            $table->dropForeign(['workspace_id']);
            $table->dropForeign(['user_id']);
            $table->dropUnique('user_workspace_workspace_id_user_id_unique');
        });

        // 2. Renombrar columna workspace_id → team_id
        Schema::table('user_workspace', function (Blueprint $table) {
            $table->renameColumn('workspace_id', 'team_id');
        });

        // 3. Renombrar tabla user_workspace → team_user
        Schema::rename('workspaces', 'teams');
        Schema::rename('user_workspace', 'team_user');

        // 4. Volver a crear las claves foráneas y el índice unique original
        Schema::table('team_user', function (Blueprint $table) {
            $table->foreign('team_id')->references('id')->on('teams')->onDelete('cascade');
            $table->foreign('user_id')->references('id')->on('users')->onDelete('cascade');
            $table->unique(['team_id', 'user_id']);
        });
    }
};
