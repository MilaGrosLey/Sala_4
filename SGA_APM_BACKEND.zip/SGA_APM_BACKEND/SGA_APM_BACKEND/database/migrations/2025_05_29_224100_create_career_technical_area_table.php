<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('career_technical_area', function (Blueprint $table) {
            $table->foreignId('career_id')->constrained('careers');
            $table->foreignId('technical_area_id')->constrained('technical_areas');
            $table->timestamps();

            $table->unique(['career_id', 'technical_area_id']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('career_technical_area');
    }
};
