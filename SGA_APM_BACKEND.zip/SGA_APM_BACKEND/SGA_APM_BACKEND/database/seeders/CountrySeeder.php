<?php

namespace Database\Seeders;

use App\Models\Country;
use Exception;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use League\Csv\Reader;

class CountrySeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        try {
            $csvFile = public_path('csv/countries.csv');

            $csv = Reader::createFromPath($csvFile, 'r');
            $csv->setDelimiter(';');
            $csv->setHeaderOffset(0);

            foreach ($csv as $row) {
                Country::create([
                    'name' => $row['name'],
                    'phone_code' => $row['phone_code'] ?? null,
                    'ISO2' => $row['ISO2'] ?? null,
                ]);
            }

            $this->command->info('Semillas de países insertadas correctamente en la base de datos.');
        } catch (Exception $e) {
            $this->command->error('Error al insertar semillas de países: ' . $e->getMessage());
        }
    }
}
