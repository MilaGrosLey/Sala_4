<?php
namespace Database\Seeders;

use App\Models\Skill;
use Illuminate\Database\Seeder;

class SkillSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $skills = [
            // 🧠 Lenguajes de programación
            ['name' => 'C'],
            ['name' => 'C++'],
            ['name' => 'C#'],
            ['name' => 'Java'],
            ['name' => 'JavaScript'],
            ['name' => 'PHP'],
            ['name' => 'Python'],
            ['name' => 'TypeScript'],

            ['name' => 'HTML'],
            ['name' => 'CSS'],

            // 🗄️ Bases de datos
            ['name' => 'MySQL'],
            ['name' => 'PostgreSQL'],
            ['name' => 'MongoDB'],
            ['name' => 'SQLite'],
            ['name' => 'Oracle'],
            ['name' => 'Microsoft SQL Server'],
            ['name' => 'Microsoft SQL Server'],

            // 🧱 Frameworks y Librerías
            ['name' => 'Laravel'],
            ['name' => 'React'],
            ['name' => 'Spring Boot'],
            ['name' => 'Django'],
            ['name' => 'Vue.js'],
            ['name' => 'Tailwind CSS'],

            // ⚙️ Herramientas y control de versiones
            ['name' => 'Git'],
            ['name' => 'GitHub'],
            ['name' => 'Docker'],

            // 🎨 Habilidades de Diseño Gráfico
            ['name' => 'Adobe Photoshop'],
            ['name' => 'Adobe Illustrator'],
            ['name' => 'Figma'],
            ['name' => 'Adobe XD'],
            ['name' => 'After Effects'],
            ['name' => 'InDesign'],
            ['name' => 'UX/UI'],

            // 📊 Habilidades de Administración
            ['name' => 'Microsoft Excel'],
            ['name' => 'Power BI'],
            ['name' => 'SAP'],
            ['name' => 'Gestión de Proyectos'],
            ['name' => 'Google Workspace'],
            ['name' => 'CRM'],
            ['name' => 'ERP'],
        ];

        foreach ($skills as $skill) {
            Skill::firstOrCreate(['name' => $skill['name']], $skill);
        }

    }
}
