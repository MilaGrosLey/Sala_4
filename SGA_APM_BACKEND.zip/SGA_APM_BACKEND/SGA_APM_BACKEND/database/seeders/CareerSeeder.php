<?php

namespace Database\Seeders;

use App\Models\Career;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class CareerSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $careers = [
            ['name' => 'Desarrollo de Software'],
            ['name' => 'Ingeniería de Software con IA'],
            ['name' => 'Diseño Grafico'],
            ['name' => 'Administración']
        ];

        foreach ($careers as $career) {
            Career::firstOrCreate(['name' => $career['name']], $career);
        }
    }
}
