<?php
namespace Database\Seeders;

use App\Enums\RoleEnum;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $admin = User::firstOrCreate(
            ['email' => 'admin@example.com'],
            [
                'document_number'   => '12345677',
                'name'              => 'admin',
                'paternal_lastname' => 'admino',
                'maternal_lastname' => 'admino',
                'address'           => 'Av. Los Próceres 123',
                'phone'             => '987654321',
                'user_name'         => 'admin',
                'password'          => Hash::make('1596ad'),
                'document_type_id'  => 1,
                'ubigeo_id'         => 150101,
                'country_id'        => 1,
            ]
        );
        $admin->assignRole(RoleEnum::ADMIN->value);

        $staff = User::firstOrCreate(
            ['email' => 'staff@example.com'],
            [
                'document_number'   => '12345678',
                'name'              => 'staff',
                'paternal_lastname' => 'staff',
                'maternal_lastname' => 'staff',
                'address'           => 'Av. Los Próceres 1234',
                'phone'             => '987654322',
                'user_name'         => 'staff',
                'password'          => Hash::make('1596st'),
                'document_type_id'  => 1,
                'ubigeo_id'         => 150101,
                'country_id'        => 1,
            ]
        );
        $staff->assignRole(RoleEnum::STAFF->value);

        /* comentar o borrar la linea de codigo, antes de subirlo al servidor, abajo (linea 53 a 57) */
        $roles = array_filter(array_column(RoleEnum::cases(), 'value'), fn($role) => $role !== RoleEnum::ADMIN->value);

        User::factory(49)->create()->each(function ($user) use ($roles) {
            $user->assignRole(fake()->randomElement($roles));
        });
    }
}
