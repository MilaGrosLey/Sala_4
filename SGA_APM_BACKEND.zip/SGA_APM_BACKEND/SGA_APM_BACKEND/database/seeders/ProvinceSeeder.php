<?php

namespace Database\Seeders;

use App\Models\Province;
use Exception;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use League\Csv\Reader;

class ProvinceSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        try {
            $csvFile = public_path('csv/provinces.csv');

            $csv = Reader::createFromPath($csvFile, 'r');
            $csv->setDelimiter(';');
            $csv->setHeaderOffset(0);

            foreach ($csv as $row) {
                Province::create([
                    'id' => $row['id'],
                    'name' => $row['name'] ?? null,
                    'region_id' => $row['region_id'] ?? null,
                ]);
            }

            $this->command->info('Semillas de provincias insertadas correctamente en la base de datos.');
        } catch (Exception $e) {
            $this->command->error('Error al insertar semillas de provincias: ' . $e->getMessage());
        }
    }
}
