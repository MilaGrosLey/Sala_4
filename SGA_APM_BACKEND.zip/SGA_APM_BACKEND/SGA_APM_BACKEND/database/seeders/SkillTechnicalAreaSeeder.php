<?php

namespace Database\Seeders;

use App\Models\Skill;
use App\Models\TechnicalArea;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class SkillTechnicalAreaSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Mapeo de skills por área técnica
        $mapping = [

            // 💻 Desarrollo de Software  y 🛠️ Ingeniería de Software con IA
            'Frontend' => [
                'HTML', 'CSS', 'JavaScript', 'TypeScript',
                'React', 'Vue.js', 'Tailwind CSS',
                'Figma','Git', 'GitHub', 'Docker',
            ],
            'Backend' => [
                'PHP', 'Laravel', 'Java', 'Spring Boot',
                'Python', 'Django', 'C#', 'C++', 'C',
                'MySQL', 'PostgreSQL', 'MongoDB',
                'SQLite', 'Oracle', 'Microsoft SQL Server',
                'Git', 'GitHub', 'Docker',
            ],
            'Fullstack' => [
                'HTML', 'CSS', 'JavaScript', 'TypeScript',
                'React', 'Vue.js', 'Tailwind CSS',
                'Figma',
                'PHP', 'Laravel', 'Java', 'Spring Boot',
                'Python', 'Django', 'C#', 'C++', 'C',
                'MySQL', 'PostgreSQL', 'MongoDB',
                'SQLite', 'Oracle', 'Microsoft SQL Server',
                'Git', 'GitHub', 'Docker',
            ],
            'No decido' => [
                'HTML', 'CSS', 'JavaScript', 'TypeScript',
                'React', 'Vue.js', 'Tailwind CSS',
                'Figma',
                'PHP', 'Laravel', 'Java', 'Spring Boot',
                'Python', 'Django', 'C#', 'C++', 'C',
                'MySQL', 'PostgreSQL', 'MongoDB',
                'SQLite', 'Oracle', 'Microsoft SQL Server',
                'Git', 'GitHub', 'Docker',
            ],
            'Pruebas y QA' => [
                'PHP', 'Laravel', 'Java', 'Spring Boot',
                'Python', 'Django', 'C#', 'C++', 'C',
                'MySQL', 'PostgreSQL', 'MongoDB',
                'SQLite', 'Oracle', 'Microsoft SQL Server',
                'Git', 'GitHub', 'Docker',
            ],

            // 🎨 Diseño Gráfico
            'Diseño Digital' => [
                'Adobe Photoshop', 'Adobe Illustrator', 
                'Adobe XD', 'After Effects', 'InDesign',
                'HTML', 'CSS', 'JavaScript', 'UX/UI', 'Figma',
            ],
            'Diseño Web' => [
                'Adobe Photoshop', 'Adobe Illustrator', 
                'Adobe XD', 'After Effects', 'InDesign',
                'HTML', 'CSS', 'JavaScript', 'UX/UI', 'Figma',
            ],
            'Multimedia' => [
                'Adobe Photoshop', 'Adobe Illustrator',
                'Adobe XD', 'After Effects', 'InDesign',
                'HTML', 'CSS', 'JavaScript', 'UX/UI', 'Figma',
            ],

            // 🏢 Administración
            'Gestión Empresarial' => [
                'Microsoft Excel', 'Gestión de Proyectos',
                'CRM', 'Power BI', 'Google Workspace', 
                'ERP', 'SAP',
            ],
            'Marketing' => [
                'Microsoft Excel', 'Gestión de Proyectos',
                'CRM', 'Power BI', 'Google Workspace', 
                'ERP', 'SAP',
                
            ],
            'Recursos Humanos' => [
                'Microsoft Excel', 'Gestión de Proyectos',
                'CRM', 'Power BI', 'Google Workspace', 
                'ERP', 'SAP',
                
            ],
            'Finanzas' => [
                'Microsoft Excel', 'Gestión de Proyectos',
                'CRM', 'Power BI', 'Google Workspace', 
                'ERP', 'SAP',
                
            ],
        ];

        // Recorrer cada área y asociar los skills
        foreach ($mapping as $areaName => $skills) {
            $technicalArea = TechnicalArea::where('name', $areaName)->first();

            if (!$technicalArea) {
                continue; // Si no existe, saltar
            }

            foreach ($skills as $skillName) {
                $skill = Skill::where('name', $skillName)->first();
                if ($skill) {
                    $technicalArea->skills()->syncWithoutDetaching([ 
                        $skill->id => [
                            'created_at' => now(),
                            'updated_at' => now(),
                        ]
                    ]);
                }
            }
            
        }
    }
}
