<?php
namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Permission;

//use App\Models\Permission;

class PermissionSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $permissions = [
            'attendance'              => [
                ['index', 'Muestra todas las asistencias', ['admin', 'staff', 'intern', 'coordinator']],
                ['show', 'Muestra una asistencia específica', ['admin', 'staff', 'intern', 'coordinator']],
                ['store', 'Crea una nueva asistencia', ['admin', 'staff', 'intern', 'coordinator']],
                ['update', 'Actualiza una asistencia', ['admin', 'staff', 'intern', 'coordinator']],
                ['destroy', 'Elimina una asistencia', ['admin']],
            ],

            'user'                    => [
                ['index', 'Muestra todos los usuarios', ['admin', 'staff', 'intern', 'coordinator']],
                ['show', 'Muestra un usuario específico', ['admin', 'staff', 'intern', 'coordinator']],
                ['update', 'Actualiza un usuario', ['admin', 'staff', 'intern', 'coordinator']],
                ['destroy', 'Elimina un usuario', ['admin']],
            ],

            'project'                 => [
                ['index', 'Muestra todos los proyectos', ['admin', 'staff', 'intern', 'coordinator']],
                ['show', 'Muestra un proyecto específico', ['admin', 'staff', 'intern', 'coordinator']],
                ['store', 'Crea un nuevo proyecto', ['admin', 'coordinator']],
                ['update', 'Actualiza un proyecto', ['admin', 'coordinator']],
                ['destroy', 'Elimina un proyecto', ['admin']],
            ],

            'attendance_code'         => [
                ['index', 'Muestra todos los códigos de asistencia', ['admin', 'staff', 'intern', 'coordinator']],
                ['show', 'Muestra un código de asistencia específico', ['admin', 'staff', 'intern', 'coordinator']],
                ['generate', 'Genera un nuevo código de asistencia', ['admin', 'staff', 'intern', 'coordinator']],
                ['destroy', 'Elimina un código de asistencia', ['admin']],
            ],

            'attendance_status'       => [
                ['index', 'Muestra todos los estados de asistencia', ['admin', 'staff', 'intern', 'coordinator']],
                ['show', 'Muestra un estado de asistencia específico', ['admin', 'staff', 'intern', 'coordinator']],
                ['store', 'Crea un nuevo estado de asistencia', ['admin', 'coordinator']],
                ['update', 'Actualiza un estado de asistencia', ['admin', 'coordinator']],
                ['destroy', 'Elimina un estado de asistencia', ['admin']],
            ],

            'career'                  => [
                ['index', 'Muestra todas las carreras', ['admin', 'staff', 'intern', 'coordinator']],
                ['show', 'Muestra una carrera específica', ['admin', 'staff', 'intern', 'coordinator']],
                ['store', 'Crea una nueva carrera', ['admin', 'coordinator']],
                ['update', 'Actualiza una carrera', ['admin', 'coordinator']],
                ['destroy', 'Elimina una carrera', ['admin']],
            ],

            'country'                 => [
                ['index', 'Muestra todos los países', ['admin', 'staff', 'intern', 'coordinator']],
                ['show', 'Muestra un país específico', ['admin', 'staff', 'intern', 'coordinator']],
                ['store', 'Crea un nuevo país', ['admin']],
                ['update', 'Actualiza un país', ['admin']],
                ['destroy', 'Elimina un país', ['admin']],
            ],

            'district'                => [
                ['index', 'Muestra todos los distritos', ['admin', 'staff', 'intern', 'coordinator']],
                ['show', 'Muestra un distrito específico', ['admin', 'staff', 'intern', 'coordinator']],
                ['store', 'Crea un nuevo distrito', ['admin']],
                ['update', 'Actualiza un distrito', ['admin']],
                ['destroy', 'Elimina un distrito', ['admin']],
            ],

            'document_type'           => [
                ['index', 'Muestra todos los tipos de documento', ['admin', 'staff', 'intern', 'coordinator']],
                ['show', 'Muestra un tipo de documento específico', ['admin', 'staff', 'intern', 'coordinator']],
                ['store', 'Crea un nuevo tipo de documento', ['admin']],
                ['update', 'Actualiza un tipo de documento', ['admin']],
                ['destroy', 'Elimina un tipo de documento', ['admin']],
            ],

            'email_verification'      => [
                ['index', 'Muestra todas las verificaciones de email', ['admin']],
                ['show', 'Muestra una verificación de email específica', ['admin']],
                ['store', 'Crea una nueva verificación de email', ['admin']],
                ['update', 'Actualiza una verificación de email', ['admin']],
                ['destroy', 'Elimina una verificación de email', ['admin']],
            ],

            'internship'              => [
                ['index', 'Muestra todas las pasantías', ['admin', 'staff', 'intern', 'coordinator']],
                ['show', 'Muestra una pasantía específica', ['admin', 'staff', 'intern', 'coordinator']],
                ['store', 'Crea una nueva pasantía', ['admin']],
                ['update', 'Actualiza una pasantía', ['admin']],
                ['destroy', 'Elimina una pasantía', ['admin']],
            ],

            'province'                => [
                ['index', 'Muestra todas las provincias', ['admin', 'staff', 'intern', 'coordinator']],
                ['show', 'Muestra una provincia específica', ['admin', 'staff', 'intern', 'coordinator']],
                ['store', 'Crea una nueva provincia', ['admin']],
                ['update', 'Actualiza una provincia', ['admin']],
                ['destroy', 'Elimina una provincia', ['admin']],
            ],

            'recurring_justification' => [
                ['index', 'Muestra todas las justificaciones recurrentes', ['admin', 'staff', 'intern']],
                ['show', 'Muestra una justificación recurrente específica', ['admin', 'staff', 'intern']],
                ['store', 'Crea una nueva justificación recurrente', ['admin']],
                ['update', 'Actualiza una justificación recurrente', ['admin']],
                ['destroy', 'Elimina una justificación recurrente', ['admin']],
            ],

            'region'                  => [
                ['index', 'Muestra todas las regiones', ['admin', 'staff', 'intern', 'coordinator']],
                ['show', 'Muestra una región específica', ['admin', 'staff', 'intern', 'coordinator']],
                ['store', 'Crea una nueva región', ['admin']],
                ['update', 'Actualiza una región', ['admin']],
                ['destroy', 'Elimina una región', ['admin']],
            ],

            'registration_code'       => [
                ['index', 'Muestra todos los códigos de registro', ['admin']],
                ['show', 'Muestra un código de registro específico', ['admin']],
                ['store', 'Crea un nuevo código de registro', ['admin']],
                ['update', 'Actualiza un código de registro', ['admin']],
                ['destroy', 'Elimina un código de registro', ['admin']],
            ],

            'skill'                   => [
                ['index', 'Muestra todas las habilidades', ['admin', 'staff', 'intern', 'coordinator']],
                ['show', 'Muestra una habilidad específica', ['admin', 'staff', 'intern', 'coordinator']],
                ['store', 'Crea una nueva habilidad', ['admin']],
                ['update', 'Actualiza una habilidad', ['admin']],
                ['destroy', 'Elimina una habilidad', ['admin']],
            ],

            'workspace'               => [
                ['index', 'Muestra todos los equipos', ['admin', 'staff', 'intern', 'coordinator']],
                ['show', 'Muestra un equipo específico', ['admin', 'staff', 'intern', 'coordinator']],
                ['store', 'Crea un nuevo equipo', ['admin', 'coordinator']],
                ['update', 'Actualiza un equipo', ['admin', 'coordinator']],
                ['destroy', 'Elimina un equipo', ['admin']],
            ],

            'workspace_type'          => [
                ['index', 'Muestra todos los tipos de equipo', ['admin', 'staff', 'intern', 'coordinator']],
                ['show', 'Muestra un tipo de equipo específico', ['admin', 'staff', 'intern', 'coordinator']],
                ['store', 'Crea un nuevo tipo de equipo', ['admin', 'coordinator']],
                ['update', 'Actualiza un tipo de equipo', ['admin', 'coordinator']],
                ['destroy', 'Elimina un tipo de equipo', ['admin']],
            ],

            'technical_area'          => [
                ['index', 'Muestra todas las áreas técnicas', ['admin', 'staff', 'intern', 'coordinator']],
                ['show', 'Muestra un área técnica específica', ['admin', 'staff', 'intern', 'coordinator']],
                ['store', 'Crea una nueva área técnica', ['admin']],
                ['update', 'Actualiza un área técnica', ['admin']],
                ['destroy', 'Elimina un área técnica', ['admin']],
            ],

            'user_workspace'          => [
                ['index', 'Muestra todas las relaciones de usuario con un workspace', ['admin', 'staff', 'intern', 'coordinator']],
                ['show', 'Muestra una relación de usuario con un workspace específica', ['admin', 'staff', 'intern', 'coordinator']],
                ['store', 'Crea una relación de usuario con un workspace', ['admin', 'coordinator']],
                ['roles', 'Muestra los roles disponibles para una relación de usuario con un workspace', ['admin', 'staff', 'intern', 'coordinator']],
            ],
        ];

        foreach ($permissions as $module => $actions) {
            foreach ($actions as [$action, $detail, $roles]) {
                Permission::updateOrCreate(
                    ['name' => "$module.$action"],
                    ['detail' => $detail]
                )->syncRoles($roles);
            }
        }
    }
}
