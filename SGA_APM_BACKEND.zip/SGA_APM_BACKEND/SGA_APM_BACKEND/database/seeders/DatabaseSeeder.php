<?php
namespace Database\Seeders;

// use Illuminate\Database\Console\Seeds\WithoutModelEvents;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        $this->call([
            RegionSeeder::class,
            CountrySeeder::class,
            ProvinceSeeder::class,
            DistrictSeeder::class,
            WorkspaceTypeSeeder::class,
            WorkspaceSeeder::class,
            DocumentTypeSeeder::class,
            CareerSeeder::class,
            TechnicalAreaSeeder::class,
            SkillSeeder::class,
            SkillTechnicalAreaSeeder::class,
            AttendanceStatusSeeder::class,
            RoleSeeder::class,
            UserSeeder::class,
            PermissionSeeder::class,
            CareerTechnicalAreaSeeder::class,
        ]);
    }
}
