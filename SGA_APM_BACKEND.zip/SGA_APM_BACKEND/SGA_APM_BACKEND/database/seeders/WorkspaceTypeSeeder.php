<?php
namespace Database\Seeders;

use App\Models\WorkspaceType;
use Illuminate\Database\Seeder;

class WorkspaceTypeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $workspaces = [
            [
                'name' => 'Proyecto',
            ],
            [
                'name' => 'Área',
            ],
        ];

        foreach ($workspaces as $workspace) {
            WorkspaceType::firstOrCreate(['name' => $workspace['name']], $workspace);
        }

    }
}
