<?php
namespace Database\Seeders;

use App\Models\Career;
use App\Models\TechnicalArea;
use Illuminate\Database\Seeder;

class CareerTechnicalAreaSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $mapping = [
            'Desarrollo de Software'        => ['Frontend', 'Backend', 'Fullstack', 'No decido'],
            'Ingeniería de Software con IA' => ['Frontend', 'Backend', 'Fullstack', 'Pruebas y QA', 'No decido'],
            'Diseño Grafico'                => ['Diseño Digital', 'Diseño Web', 'Multimedia'],
            'Administración'                => ['Recursos Humanos', 'Marketing', 'Finanzas', 'Gestión Empresarial'],
        ];

        foreach ($mapping as $career => $technicalAreas) {
            $career = Career::where('name', $career)->first();

            if (! $career) {
                continue;
            }

            foreach ($technicalAreas as $technicalAreasName) {
                $technicalArea = TechnicalArea::where('name', $technicalAreasName)->first();

                if (! $technicalArea) {
                    $this->command->info('No se pudo encontrar ' . $technicalAreasName);
                }

                if ($technicalArea) {
                    $career->technicalAreas()->syncWithoutDetaching([
                        $technicalArea->id,
                    ]);
                }

            }
        }

    }
}
