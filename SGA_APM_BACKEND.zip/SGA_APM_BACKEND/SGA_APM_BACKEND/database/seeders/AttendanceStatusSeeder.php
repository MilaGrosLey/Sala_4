<?php
namespace Database\Seeders;

use App\Models\AttendanceStatus;
use Illuminate\Database\Seeder;

class AttendanceStatusSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $attendanceStatus = [
            [
                'name'  => 'Presente',
                'color' => '#00FF00',
            ],
            [
                'name'  => 'Ausente',
                'color' => '#FF0000',
            ],
            [
                'name'  => 'Tarde',
                'color' => '#FFFF00',
            ],
            [
                'name'  => 'Justificado',
                'color' => '#00FFFF',
            ],

        ];

        foreach ($attendanceStatus as $status) {
            AttendanceStatus::create($status);
        }
    }
}
