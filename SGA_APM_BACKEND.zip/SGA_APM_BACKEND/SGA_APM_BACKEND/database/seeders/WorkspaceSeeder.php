<?php
namespace Database\Seeders;

use App\Models\Workspace;
use Illuminate\Database\Seeder;

class WorkspaceSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $workspaces = [
            ['name' => 'Reflexologia', 'workspace_type_id' => 1],
            ['name' => 'SCRUM Master', 'workspace_type_id' => 2],
            ['name' => 'Product Owner con IA', 'workspace_type_id' => 2],
            ['name' => 'Maquetación', 'workspace_type_id' => 1],
            ['name' => 'Web Form', 'workspace_type_id' => 1],
            ['name' => 'Agentes IA', 'workspace_type_id' => 1],
            ['name' => 'Automatización', 'workspace_type_id' => 1],
            ['name' => 'Pix0 DG POSTS', 'workspace_type_id' => 2],
            ['name' => 'Pix1 DG REELS', 'workspace_type_id' => 2],
            ['name' => 'MemberShips', 'workspace_type_id' => 1],
            ['name' => 'Nucleo Inverso', 'workspace_type_id' => 1],
            ['name' => 'Nucleo Inverso 2', 'workspace_type_id' => 1],
            ['name' => 'Multimedia', 'workspace_type_id' => 2],
            ['name' => 'Marketing', 'workspace_type_id' => 2],
        ];

        foreach ($workspaces as $workspace) {
            Workspace::updateOrCreate(['name' => $workspace['name']], $workspace);
        }
    }
}
