<?php
namespace Database\Seeders;

use App\Models\TechnicalArea;
use Illuminate\Database\Seeder;

class TechnicalAreaSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $technical_areas = [
            // 💻 Desarrollo de Software (career_id = 1) y 🛠️ Ingeniería de Software con IA (career_id = 2)
            ['name' => 'Frontend'],
            ['name' => 'Backend'],
            ['name' => 'Fullstack'],
            ['name' => 'No decido'],

            // 🛠️ Mas Ingeniería de Software con IA (career_id = 2)
            ['name' => 'Pruebas y QA'],

            // 🎨 Diseño Gráfico (career_id = 3)
            ['name' => 'Diseño Digital'],
            ['name' => 'Diseño Web'],
            ['name' => 'Multimedia'],

            // 🏢 Administración (career_id = 4)
            ['name' => 'Recursos Humanos'],
            ['name' => 'Marketing'],
            ['name' => 'Finanzas'],
            ['name' => 'Gestión Empresarial'],
        ];

        foreach ($technical_areas as $area) {
            TechnicalArea::firstOrCreate(['name' => $area['name']], $area);
        }
    }
}
