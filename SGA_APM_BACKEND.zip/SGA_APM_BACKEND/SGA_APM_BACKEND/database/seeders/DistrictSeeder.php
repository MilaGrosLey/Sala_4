<?php

namespace Database\Seeders;

use App\Models\District;
use Exception;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use League\Csv\Reader;

class DistrictSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        try {
        $csvFile =  public_path('csv/districts.csv');

            $csv = Reader::createFromPath($csvFile, 'r');
            $csv->setDelimiter(';');
            $csv->setHeaderOffset(0);

            foreach ($csv as $row) {
                District::create([
                    'id' => $row['id'],
                    'name' => $row['name'] ?? null,
                    'province_id' => $row['province_id'] ?? null,
                ]);
            }

            $this->command->info('Semillas de distritos insertadas correctamente en la base de datos ✔️.');
        } catch (Exception $e) {
            $this->command->error('Error al insertar semillas de distritos: ' . $e->getMessage());
        }
    }
}
