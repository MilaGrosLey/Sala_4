<?php

namespace Database\Seeders;

use App\Models\Region;
use Exception;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use League\Csv\Reader;

class RegionSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        try {
            $csvFile = public_path('csv/regions.csv');

            $csv = Reader::createFromPath($csvFile, 'r');
            $csv->setDelimiter(';');
            $csv->setHeaderOffset(0);

            foreach ($csv as $row) {
                Region::create([
                    'id'=>$row['id'],
                    'name' => $row['name'],
                ]);
            }

            $this->command->info('Semillas de regiones insertadas correctamente en la base de datos.');
        } catch (Exception $e) {
            $this->command->error('Error al insertar semillas de regiones: ' . $e->getMessage());
        }
    }
}
