<?php
namespace Database\Factories;

use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\User>
 */
class UserFactory extends Factory
{
    /**
     * The current password being used by the factory.
     */
    protected $model = User::class;

    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        // Nombres y apellidos peruanos
        $nombres   = ['José', 'María', 'Luis', 'Ana', 'Carlos', 'Rosa', 'Jorge', 'Carmen', 'Diego', 'Patricia'];
        $apellidos = ['Quispe', 'Huamán', 'García', 'Pérez', 'Rojas', 'Flores', 'Torres', 'Castro', 'Mendoza', 'Vargas'];

        $name     = $this->faker->randomElement($nombres);
        $paternal = $this->faker->randomElement($apellidos);
        $maternal = $this->faker->randomElement($apellidos);

        return [
            'document_number'   => $this->faker->unique()->numerify('########'),
            'name'              => $name,
            'paternal_lastname' => $paternal,
            'maternal_lastname' => $maternal,
            'address'           => $this->faker->streetAddress,
            'phone'             => $this->faker->numerify('9########'),
            'email'             => strtolower($name . '.' . $paternal . rand(1, 10000) . '@example.com'),
            'user_name'         => strtolower(substr($name, 0, 1) . $paternal . rand(1, 10000)),
            'password'          => Hash::make('1234'),
            'document_type_id'  => 1,
            'ubigeo_id'         => 150101,
            'country_id'        => 1,
            'remember_token'    => Str::random(10),
        ];
    }

    /**
     * Indicate that the model's email address should be unverified.
     */
    public function unverified(): static
    {
        return $this->state(fn(array $attributes) => [
            'email_verified_at' => null,
        ]);
    }
}
