<?php
namespace App\Exceptions\Conflicts;

use Exception;
use Illuminate\Http\Request;
use Illuminate\Http\Response;

class SoftDeletedConflictException extends Exception
{
    private $attribute;

    public function __construct($attribute)
    {
        $this->attribute = $attribute;
        $message         = "Este nombre '{$this->attribute}' ya existe, esta en estado eliminado. Vuelva a crearlo para restaurar el registro.";
        parent::__construct($message);
    }

    /**
     * Report the exception.
     */
    public function report(): void
    {
        // ...
    }

    /**
     * Render the exception as an HTTP response.
     */
    public function render(Request $request)
    {
        return response()->json([
            'error' => $this->getMessage(),
        ], 409);
    }
}
