<?php

use Carbon\Carbon;
use Illuminate\Support\Facades\Log;

if (! function_exists('withLimaTimeZone')) {
    function withLimaTimeZone($datetime, string $format = 'Y-m-d H:i:s'): ?string
    {
        if (empty($datetime)) {
            return null;
        }

        try {
            if ($datetime instanceof DateTimeInterface) {
                return Carbon::instance($datetime)
                    ->setTimezone('America/Lima')
                    ->format($format);
            }

            if (! is_string($datetime) || strtotime($datetime) === false) {
                Log::warning("withLimaTimeZone: Fecha inválida recibida: " . json_encode($datetime));
                return null;
            }

            return Carbon::parse($datetime)
                ->setTimezone('America/Lima')
                ->format($format);

        } catch (Exception $e) {
            Log::error("Error en withLimaTimeZone: " . $e->getMessage());
            return null;
        }
    }
}
