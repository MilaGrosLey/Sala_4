<?php
namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class ResetCodeMail extends Mailable
{
    use Queueable, SerializesModels;

    public $code;
    public $appName;

    /**
     * Create a new message instance.
     */
    public function __construct($code, $appName = 'APM INVERSIONES E.I.R.L')
    {
        $this->code    = $code;
        $this->appName = $appName;
    }

    public function build()
    {
        return $this->subject("Código de verificación - $this->appName")
            ->view('emails.reset_code');
    }

}
