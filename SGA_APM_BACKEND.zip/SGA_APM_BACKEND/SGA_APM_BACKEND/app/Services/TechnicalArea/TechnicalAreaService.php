<?php
namespace App\Services\TechnicalArea;

use App\Exceptions\Conflicts\SoftDeletedConflictException;
use App\Models\TechnicalArea;

class TechnicalAreaService
{
    /**
     * Get all technical areas.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function list()
    {
        return TechnicalArea::all();
    }

    /**
     * Find a specific technical area by ID.
     *
     * @param int $id
     * @return \App\Models\TechnicalArea
     * @throws \Illuminate\Database\Eloquent\ModelNotFoundException
     */
    public function find($id)
    {
        return TechnicalArea::findOrFail($id);
    }

    /**
     * Create a new technical area or restore if soft-deleted.
     * Checks for existing technical area with the same name and restores it if soft-deleted.
     *
     * @param array $data
     * @return \App\Models\TechnicalArea
     */
    public function create(array $data)
    {
        $area = TechnicalArea::withTrashed()
            ->where('name', $data['name'])
            ->first();
        if ($area) {
            if ($area->trashed()) {
                $area->restore();
            }
            $area->update($data);
            return $area;
        }
        return TechnicalArea::create($data);
    }

    /**
     * Update an existing technical area.
     * Validates name uniqueness and handles soft-deleted conflicts.
     *
     * @param \App\Models\TechnicalArea $technicalArea
     * @param array $data
     * @return \App\Models\TechnicalArea|\Illuminate\Http\JsonResponse
     * @throws \App\Exceptions\Conflicts\SoftDeletedConflictException
     */
    public function update(TechnicalArea $technicalArea, array $data)
    {
        if (isset($data['name']) && $data['name'] !== $technicalArea->name) {
            $softDeleted = TechnicalArea::onlyTrashed()
                ->where('name', $data['name'])
                ->first();
            if ($softDeleted) {
                throw new SoftDeletedConflictException($data['name']);
            }
            $exists = TechnicalArea::where('name', $data['name'])
                ->where('id', '!=', $technicalArea->id)
                ->whereNull('deleted_at')
                ->exists();
            if ($exists) {
                return response()->json([
                    'error' => 'Ya existe un registro activo con ese nombre.',
                ], 409);
            }
        }
        $technicalArea->update($data);
        return $technicalArea;
    }

    /**
     * Soft delete a technical area.
     *
     * @param \App\Models\TechnicalArea $technicalArea
     * @return bool
     */
    public function delete(TechnicalArea $technicalArea)
    {
        $technicalArea->delete();
        return true;
    }
}
