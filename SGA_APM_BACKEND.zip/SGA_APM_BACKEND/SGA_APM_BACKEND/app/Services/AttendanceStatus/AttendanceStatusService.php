<?php
namespace App\Services\AttendanceStatus;

use App\Exceptions\Conflicts\SoftDeletedConflictException;
use App\Models\AttendanceStatus;

class AttendanceStatusService
{
    /**
     * Get all attendance statuses.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function list()
    {
        return AttendanceStatus::all();
    }

    /**
     * Find a specific attendance status by ID.
     *
     * @param int $id
     * @return \App\Models\AttendanceStatus
     * @throws \Illuminate\Database\Eloquent\ModelNotFoundException
     */
    public function find($id)
    {
        return AttendanceStatus::findOrFail($id);
    }

    /**
     * Create a new attendance status or restore if soft-deleted.
     * Checks for existing attendance status with the same name and restores it if soft-deleted.
     *
     * @param array $data
     * @return \App\Models\AttendanceStatus
     */
    public function create(array $data)
    {

        $status = AttendanceStatus::withTrashed()->where('name', $data['name'])->first();

        if ($status) {
            if ($status->trashed()) {
                $status->restore();
            }

            $status->update($data);
            return $status;
        }

        return AttendanceStatus::create($data);
    }

    /**
     * Update an existing attendance status.
     * Validates name uniqueness and handles soft-deleted conflicts.
     *
     * @param \App\Models\AttendanceStatus $attendanceStatus
     * @param array $data
     * @return \App\Models\AttendanceStatus|\Illuminate\Http\JsonResponse
     * @throws \App\Exceptions\Conflicts\SoftDeletedConflictException
     */
    public function update(AttendanceStatus $attendanceStatus, array $data)
    {
        // Si el nombre cambia
        if (isset($data['name']) && $data['name'] !== $attendanceStatus->name) {
            $softDeleted = AttendanceStatus::onlyTrashed()
                ->where('name', $data['name'])
                ->first();
            if ($softDeleted) {
                throw new SoftDeletedConflictException($data['name']);
            }
            $exists = AttendanceStatus::where('name', $data['name'])
                ->where('id', '!=', $attendanceStatus->id)
                ->whereNull('deleted_at')
                ->exists();
            if ($exists) {
                return response()->json([
                    'error' => 'Ya existe un registro activo con ese nombre.',
                ], 409);
            }
        }
        $attendanceStatus->update($data);
        return $attendanceStatus;
    }

    /**
     * Soft delete an attendance status.
     *
     * @param \App\Models\AttendanceStatus $attendanceStatus
     * @return bool
     */
    public function delete(AttendanceStatus $attendanceStatus)
    {
        $attendanceStatus->delete();
        return true;
    }
}
