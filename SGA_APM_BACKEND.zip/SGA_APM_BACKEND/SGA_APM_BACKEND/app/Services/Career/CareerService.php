<?php
namespace App\Services\Career;

use App\Exceptions\Conflicts\SoftDeletedConflictException;
use App\Models\Career;

class CareerService
{
    /**
     * Get all careers.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function list()
    {
        return Career::all();
    }

    /**
     * Find a specific career by ID.
     *
     * @param int $id
     * @return \App\Models\Career
     * @throws \Illuminate\Database\Eloquent\ModelNotFoundException
     */
    public function find($id)
    {
        return Career::findOrFail($id);
    }

    /**
     * Create a new career or restore if soft-deleted.
     * Checks for existing career with the same name and restores it if soft-deleted.
     *
     * @param array $data
     * @return \App\Models\Career
     */
    public function create(array $data)
    {
        $career = Career::withTrashed()
            ->where('name', $data['name'])
            ->first();
        if ($career) {
            if ($career->trashed()) {
                $career->restore();
            }
            $career->update($data);
            return $career;
        }
        return Career::create($data);
    }

    /**
     * Update an existing career.
     * Validates name uniqueness and handles soft-deleted conflicts.
     *
     * @param \App\Models\Career $career
     * @param array $data
     * @return \App\Models\Career|\Illuminate\Http\JsonResponse
     * @throws \App\Exceptions\Conflicts\SoftDeletedConflictException
     */
    public function update(Career $career, array $data)
    {
        if (isset($data['name']) && $data['name'] !== $career->name) {
            $softDeleted = Career::onlyTrashed()
                ->where('name', $data['name'])
                ->first();
            if ($softDeleted) {
                throw new SoftDeletedConflictException($data['name']);
            }
            $exists = Career::where('name', $data['name'])
                ->where('id', '!=', $career->id)
                ->whereNull('deleted_at')
                ->exists();
            if ($exists) {
                return response()->json([
                    'error' => 'Ya existe un registro activo con ese nombre.',
                ], 409);
            }
        }
        $career->update($data);
        return $career;
    }

    /**
     * Soft delete a career.
     *
     * @param \App\Models\Career $career
     * @return bool
     */
    public function delete(Career $career)
    {
        $career->delete();
        return true;
    }
}
