<?php
namespace App\Services\RecurringJustification;

use App\Models\RecurringJustification;

class RecurringJustificationService
{
    /**
     * Get all recurring justifications.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function list()
    {
        return RecurringJustification::all();
    }

    /**
     * Find a specific recurring justification by ID.
     *
     * @param int $id
     * @return \App\Models\RecurringJustification
     * @throws \Illuminate\Database\Eloquent\ModelNotFoundException
     */
    public function find($id)
    {
        return RecurringJustification::findOrFail($id);
    }

    /**
     * Create a new recurring justification.
     *
     * @param array $data
     * @return \App\Models\RecurringJustification
     */
    public function create(array $data)
    {
        return RecurringJustification::create($data);
    }

    /**
     * Update an existing recurring justification.
     *
     * @param \App\Models\RecurringJustification $recurringJustification
     * @param array $data
     * @return \App\Models\RecurringJustification
     */
    public function update(RecurringJustification $recurringJustification, array $data)
    {
        $recurringJustification->update($data);
        return $recurringJustification;
    }

    /**
     * Delete a recurring justification.
     *
     * @param \App\Models\RecurringJustification $recurringJustification
     * @return bool
     */
    public function delete(RecurringJustification $recurringJustification)
    {
        $recurringJustification->delete();
        return true;
    }
}
