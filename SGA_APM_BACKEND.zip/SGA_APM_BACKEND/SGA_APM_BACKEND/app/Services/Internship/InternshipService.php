<?php
namespace App\Services\Internship;

use App\Exceptions\Conflicts\SoftDeletedConflictException;
use App\Models\Internship;

class InternshipService
{
    /**
     * Get all internships.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function list()
    {
        return Internship::all();
    }

    /**
     * Find a specific internship by ID.
     *
     * @param int $id
     * @return \App\Models\Internship
     * @throws \Illuminate\Database\Eloquent\ModelNotFoundException
     */
    public function find($id)
    {
        return Internship::findOrFail($id);
    }

    /**
     * Create a new internship.
     *
     * @param array $data
     * @return \App\Models\Internship
     */
    public function create(array $data)
    {
        return Internship::create($data);
    }

    /**
     * Update an existing internship.
     * Validates name uniqueness and handles soft-deleted conflicts.
     *
     * @param \App\Models\Internship $internship
     * @param array $data
     * @return \App\Models\Internship|\Illuminate\Http\JsonResponse
     * @throws \App\Exceptions\Conflicts\SoftDeletedConflictException
     */
    public function update(Internship $internship, array $data)
    {
        if (isset($data['name']) && $data['name'] !== $internship->name) {
            $softDeleted = Internship::onlyTrashed()
                ->where('name', $data['name'])
                ->first();
            if ($softDeleted) {
                throw new SoftDeletedConflictException($data['name']);
            }
            $exists = Internship::where('name', $data['name'])
                ->where('id', '!=', $internship->id)
                ->whereNull('deleted_at')
                ->exists();
            if ($exists) {
                return response()->json([
                    'error' => 'Ya existe un registro activo con ese nombre.',
                ], 409);
            }
        }
        $internship->update($data);
        return $internship;
    }

    /**
     * Soft delete an internship.
     *
     * @param \App\Models\Internship $internship
     * @return bool
     */
    public function delete(Internship $internship)
    {
        $internship->delete();
        return true;
    }
}
