<?php
namespace App\Services\Province;

use App\Exceptions\Conflicts\SoftDeletedConflictException;
use App\Models\Province;
use App\Models\Region;

class ProvinceService
{
    /**
     * Get all provinces.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function list()
    {
        return Province::all();
    }

    /**
     * Get provinces by region.
     * Includes region relationship data.
     *
     * @param \App\Models\Region $region
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function showByRegion(Region $region)
    {
        return Province::with('region')->where('region_id', $region->id)->get();
    }

    /**
     * Create a new province or restore if soft-deleted.
     * Checks for existing province with the same name and restores it if soft-deleted.
     *
     * @param array $data
     * @return \App\Models\Province
     */
    public function create(array $data)
    {
        $province = Province::withTrashed()
            ->where('name', $data['name'])
            ->first();
        if ($province) {
            if ($province->trashed()) {
                $province->restore();
            }
            $province->update($data);
            return $province;
        }
        return Province::create($data);
    }

    /**
     * Update an existing province.
     * Validates name and region uniqueness and handles soft-deleted conflicts.
     *
     * @param \App\Models\Province $province
     * @param array $data
     * @return \App\Models\Province|\Illuminate\Http\JsonResponse
     * @throws \App\Exceptions\Conflicts\SoftDeletedConflictException
     */
    public function update(Province $province, array $data)
    {
        $nameChanged   = isset($data['name']) && $data['name'] !== $province->name;
        $regionChanged = isset($data['region_id']) && $data['region_id'] !== $province->region_id;
        if ($nameChanged || $regionChanged) {
            $softDeleted = Province::onlyTrashed()
                ->where('name', $data['name'] ?? $province->name)
                ->where('region_id', $data['region_id'] ?? $province->region_id)
                ->first();
            if ($softDeleted) {
                throw new SoftDeletedConflictException($data['name']);
            }
            $exists = Province::where('name', $data['name'] ?? $province->name)
                ->where('region_id', $data['region_id'] ?? $province->region_id)
                ->where('id', '!=', $province->id)
                ->whereNull('deleted_at')
                ->exists();
            if ($exists) {
                return response()->json([
                    'error' => 'Ya existe un registro activo con estos datos.',
                ], 409);
            }
        }
        $province->update($data);
        return $province;
    }

    /**
     * Soft delete a province.
     *
     * @param \App\Models\Province $province
     * @return bool
     */
    public function delete(Province $province)
    {
        $province->delete();
        return true;
    }
}
