<?php
namespace App\Services\Skill;

use App\Exceptions\Conflicts\SoftDeletedConflictException;
use App\Models\Skill;

class SkillService
{
    /**
     * Get all skills.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function list()
    {
        return Skill::all();
    }

    /**
     * Find a specific skill by ID.
     *
     * @param int $id
     * @return \App\Models\Skill
     * @throws \Illuminate\Database\Eloquent\ModelNotFoundException
     */
    public function find($id)
    {
        return Skill::findOrFail($id);
    }

    /**
     * Create a new skill or restore if soft-deleted.
     * Checks for existing skill with the same name and restores it if soft-deleted.
     *
     * @param array $data
     * @return \App\Models\Skill
     */
    public function create(array $data)
    {
        $skill = Skill::withTrashed()
            ->where('name', $data['name'])
            ->first();
        if ($skill) {
            if ($skill->trashed()) {
                $skill->restore();
            }
            $skill->update($data);
            return $skill;
        }
        return Skill::create($data);
    }

    /**
     * Update an existing skill.
     * Validates name uniqueness and handles soft-deleted conflicts.
     *
     * @param \App\Models\Skill $skill
     * @param array $data
     * @return \App\Models\Skill|\Illuminate\Http\JsonResponse
     * @throws \App\Exceptions\Conflicts\SoftDeletedConflictException
     */
    public function update(Skill $skill, array $data)
    {
        if (isset($data['name']) && $data['name'] !== $skill->name) {
            $softDeleted = Skill::onlyTrashed()
                ->where('name', $data['name'])
                ->first();
            if ($softDeleted) {
                throw new SoftDeletedConflictException($data['name']);
            }
            $exists = Skill::where('name', $data['name'])
                ->where('id', '!=', $skill->id)
                ->whereNull('deleted_at')
                ->exists();
            if ($exists) {
                return response()->json([
                    'error' => 'Ya existe un registro activo con ese nombre.',
                ], 409);
            }
        }
        $skill->update($data);
        return $skill;
    }

    /**
     * Soft delete a skill.
     *
     * @param \App\Models\Skill $skill
     * @return bool
     */
    public function delete(Skill $skill)
    {
        $skill->delete();
        return true;
    }
}
