<?php
namespace App\Services\DocumentType;

use App\Exceptions\Conflicts\SoftDeletedConflictException;
use App\Models\DocumentType;

class DocumentTypeService
{
    /**
     * Get all document types.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function list()
    {
        return DocumentType::all();
    }

    /**
     * Find a specific document type by ID.
     *
     * @param int $id
     * @return \App\Models\DocumentType
     * @throws \Illuminate\Database\Eloquent\ModelNotFoundException
     */
    public function find($id)
    {
        return DocumentType::findOrFail($id);
    }

    /**
     * Create a new document type or restore if soft-deleted.
     * Checks for existing document type with the same name and restores it if soft-deleted.
     *
     * @param array $data
     * @return \App\Models\DocumentType
     */
    public function create(array $data)
    {
        // Buscar por nombre, incluyendo los soft deleted
        $type = DocumentType::withTrashed()->where('name', $data['name'])->first();
        if ($type) {
            // Si está eliminado, restaurar
            if ($type->trashed()) {
                $type->restore();
            }
            // Actualizar con los nuevos datos
            $type->update($data);
            return $type;
        }
        // Si no existe, crear
        return DocumentType::create($data);
    }

    /**
     * Update an existing document type.
     * Validates name uniqueness and handles soft-deleted conflicts.
     *
     * @param \App\Models\DocumentType $documentType
     * @param array $data
     * @return \App\Models\DocumentType|\Illuminate\Http\JsonResponse
     * @throws \App\Exceptions\Conflicts\SoftDeletedConflictException
     */
    public function update(DocumentType $documentType, array $data)
    {
        if (isset($data['name']) && $data['name'] !== $documentType->name) {
            $softDeleted = DocumentType::onlyTrashed()
                ->where('name', $data['name'])
                ->first();
            if ($softDeleted) {
                throw new SoftDeletedConflictException($data['name']);
            }
            $exists = DocumentType::where('name', $data['name'])
                ->where('id', '!=', $documentType->id)
                ->whereNull('deleted_at')
                ->exists();
            if ($exists) {
                return response()->json([
                    'error' => 'Ya existe un registro activo con ese nombre.',
                ], 409);
            }
        }
        $documentType->update($data);
        return $documentType;
    }

    /**
     * Soft delete a document type.
     *
     * @param \App\Models\DocumentType $documentType
     * @return bool
     */
    public function delete(DocumentType $documentType)
    {
        $documentType->delete();
        return true;
    }
}
