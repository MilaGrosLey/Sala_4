<?php
namespace App\Services\Country;

use App\Exceptions\Conflicts\SoftDeletedConflictException;
use App\Models\Country;

class CountryService
{
    /**
     * Get all countries.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function list()
    {
        return Country::all();
    }

    /**
     * Find a specific country by ID.
     *
     * @param int $id
     * @return \App\Models\Country
     * @throws \Illuminate\Database\Eloquent\ModelNotFoundException
     */
    public function find($id)
    {
        return Country::findOrFail($id);
    }

    /**
     * Create a new country or restore if soft-deleted.
     * Checks for existing country with the same name and restores it if soft-deleted.
     *
     * @param array $data
     * @return \App\Models\Country
     */
    public function create(array $data)
    {
        $country = Country::withTrashed()->where('name', $data['name'])->first();
        if ($country) {
            if ($country->trashed()) {
                $country->restore();
            }
            $country->update($data);
            return $country;
        }
        return Country::create($data);
    }

    /**
     * Update an existing country.
     * Validates name uniqueness and handles soft-deleted conflicts.
     *
     * @param \App\Models\Country $country
     * @param array $data
     * @return \App\Models\Country|\Illuminate\Http\JsonResponse
     * @throws \App\Exceptions\Conflicts\SoftDeletedConflictException
     */
    public function update(Country $country, array $data)
    {
        if (isset($data['name']) && $data['name'] !== $country->name) {
            $softDeleted = Country::onlyTrashed()
                ->where('name', $data['name'])
                ->first();
            if ($softDeleted) {
                throw new SoftDeletedConflictException($data['name']);
            }

            $exists = Country::where('name', $data['name'])
                ->where('id', '!=', $country->id)
                ->whereNull('deleted_at')
                ->exists();
            if ($exists) {
                return response()->json([
                    'error' => 'Ya existe un registro activo con ese nombre.',
                ], 409);
            }
        }

        $country->update($data);
        return $country;
    }

    /**
     * Soft delete a country.
     *
     * @param \App\Models\Country $country
     * @return bool
     */
    public function delete(Country $country)
    {
        $country->delete();
        return true;
    }
}
