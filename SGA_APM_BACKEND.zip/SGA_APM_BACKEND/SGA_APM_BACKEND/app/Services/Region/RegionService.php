<?php
namespace App\Services\Region;

use App\Exceptions\Conflicts\SoftDeletedConflictException;
use App\Models\Region;

class RegionService
{
    /**
     * Get all regions.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function list()
    {
        return Region::all();
    }

    /**
     * Find a specific region by ID.
     *
     * @param int $id
     * @return \App\Models\Region
     * @throws \Illuminate\Database\Eloquent\ModelNotFoundException
     */
    public function find($id)
    {
        return Region::findOrFail($id);
    }

    /**
     * Create a new region or restore if soft-deleted.
     * Checks for existing region with the same name and restores it if soft-deleted.
     *
     * @param array $data
     * @return \App\Models\Region
     */
    public function create(array $data)
    {
        $region = Region::withTrashed()
            ->where('name', $data['name'])
            ->first();
        if ($region) {
            if ($region->trashed()) {
                $region->restore();
            }
            $region->update($data);
            return $region;
        }
        return Region::create($data);
    }

    /**
     * Update an existing region.
     * Validates name uniqueness and handles soft-deleted conflicts.
     *
     * @param \App\Models\Region $region
     * @param array $data
     * @return \App\Models\Region|\Illuminate\Http\JsonResponse
     * @throws \App\Exceptions\Conflicts\SoftDeletedConflictException
     */
    public function update(Region $region, array $data)
    {
        if (isset($data['name']) && $data['name'] !== $region->name) {
            $softDeleted = Region::onlyTrashed()
                ->where('name', $data['name'])
                ->first();
            if ($softDeleted) {
                throw new SoftDeletedConflictException($data['name']);
            }
            $exists = Region::where('name', $data['name'])
                ->where('id', '!=', $region->id)
                ->whereNull('deleted_at')
                ->exists();
            if ($exists) {
                return response()->json([
                    'error' => 'Ya existe un registro activo con ese nombre.',
                ], 409);
            }
        }
        $region->update($data);
        return $region;
    }

    /**
     * Soft delete a region.
     *
     * @param \App\Models\Region $region
     * @return bool
     */
    public function delete(Region $region)
    {
        $region->delete();
        return true;
    }
}
