<?php
namespace App\Services\EmailVerification;

use App\Models\EmailVerification;

class EmailVerificationService
{
    /**
     * Get all email verifications.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function list()
    {
        return EmailVerification::all();
    }

    /**
     * Find a specific email verification by ID.
     *
     * @param int $id
     * @return \App\Models\EmailVerification
     * @throws \Illuminate\Database\Eloquent\ModelNotFoundException
     */
    public function find($id)
    {
        return EmailVerification::findOrFail($id);
    }

    /**
     * Create a new email verification.
     *
     * @param array $data
     * @return \App\Models\EmailVerification
     */
    public function create(array $data)
    {
        return EmailVerification::create($data);
    }

    /**
     * Update an existing email verification.
     *
     * @param \App\Models\EmailVerification $emailVerification
     * @param array $data
     * @return \App\Models\EmailVerification
     */
    public function update(EmailVerification $emailVerification, array $data)
    {
        $emailVerification->update($data);
        return $emailVerification;
    }

    /**
     * Delete an email verification.
     *
     * @param \App\Models\EmailVerification $emailVerification
     * @return bool
     */
    public function delete(EmailVerification $emailVerification)
    {
        $emailVerification->delete();
        return true;
    }
}
