<?php
namespace App\Services\User;

use App\Enums\RoleEnum;
use App\Models\RegistrationCode;
use App\Models\User;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Request;

class UserService
{
    /**
     * Get paginated list of users with related data.
     * Includes document type, district, province, region, and country information.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Contracts\Pagination\LengthAwarePaginator
     */
    public function index(Request $request)
    {
        $perPage = (int) $request->get('per_page', 10);

        $perPage = $perPage > 100 ? 100 : $perPage;

        $users = User::with(['documentType', 'district.province.region', 'country'])
            ->paginate($perPage)
            ->appends($request->query());

        return $users;
    }

    /**
     * Get a specific user with all related data.
     * Includes document type, district, province, region, and country information.
     *
     * @param \App\Models\User $user
     * @return \App\Models\User
     */
    public function show(User $user): User
    {
        $user->load(['documentType', 'district.province.region', 'country']);
        return $user;
    }

    /**
     * Search users by various criteria with pagination.
     * Searches by document number, name, lastnames, and combinations of these fields.
     *
     * @param array $request
     * @return \Illuminate\Contracts\Pagination\LengthAwarePaginator
     */
    public function searchUsers(array $request)
    {
        $perPage    = $request['per_page'] ?? 30;
        $searchTerm = $request['search'] ?? '';

        $query = User::with(['documentType', 'district.province.region', 'country']);

        if (! empty($searchTerm)) {
            $query->where(function ($query) use ($searchTerm) {
                $this->searchByTerm($query, $searchTerm);
            });
        }

        return $query->paginate($perPage)->appends([
            'per_page' => $perPage,
            'search'   => $searchTerm,
        ]);
    }

    /**
     * Create a new user with registration code validation.
     * Validates registration code, handles soft-deleted user restoration,
     * and assigns default intern role.
     *
     * @param array $data
     * @return \App\Models\User|array
     */
    public function store(array $data)
    {
        // Buscar y verificar código
        $code = RegistrationCode::where('code', $data['registration_code'])
            ->where('is_used', false)
            ->where(function ($query) {
                $query->whereNotNull('expires_at')
                    ->where('expires_at', '>', now());
            })
            ->first();

        if (! $code) {
            // Opcional: limpiar código vencido
            RegistrationCode::where('code', $data['registration_code'])
                ->whereNotNull('expires_at')
                ->where('expires_at', '<=', now())
                ->forceDelete();

            return [
                'error'   => true,
                'message' => 'El código ingresado no es válido o ya expiró.',
            ];
        }

        // Verificar si el usuario con el email ya existe (incluyendo soft-deleted)
        $user = User::withTrashed()->where('email', $data['email'])->first();

        if ($user) {
            if ($user->trashed()) {
                // Restaurar usuario eliminado
                $user->restore();

                // Mantener email y password del request, y resetear los demás campos a null
                $user->update([
                    'document_number'   => null,
                    'name'              => null,
                    'paternal_lastname' => null,
                    'maternal_lastname' => null,
                    'address'           => null,
                    'phone'             => null,
                    'user_name'         => null,
                    'document_type_id'  => null,
                    'ubigeo_id'         => null,
                    'country_id'        => null,
                    'password'          => bcrypt($data['password']),
                ]);
            } else {
                return [
                    'error'   => true,
                    'message' => 'Ya existe un usuario con este correo.',
                ];
            }
        } else {
            $user = User::create($data);
        }

        $user->assignRole(RoleEnum::INTERN->value);

        $code->forceDelete();

        return $user;
    }

    /**
     * Update an existing user.
     * Loads related data after update.
     *
     * @param array $data
     * @param \App\Models\User $user
     * @return \App\Models\User
     */
    public function update(array $data, User $user)
    {
        $user->update($data);

        $user->load(['documentType', 'district.province.region', 'country']);

        return $user;
    }

    /**
     * Soft delete a user.
     *
     * @param \App\Models\User $user
     * @return \Illuminate\Http\JsonResponse
     */
    public function destroy(User $user)
    {
        $user->delete();
        return response()->json(['message' => 'El usuario ha sido eliminado correctamente'], 200);
    }

    /**
     * Advanced search by term across multiple user fields.
     * Searches in document number, name, paternal and maternal lastnames,
     * and various combinations of these fields.
     *
     * @param \Illuminate\Database\Eloquent\Builder $query
     * @param string $searchTerm
     * @return \Illuminate\Database\Eloquent\Builder
     */
    private function searchByTerm(Builder $query, string $searchTerm): Builder
    {
        return $query->where(function ($q) use ($searchTerm) {
            $q->where('document_number', '=', $searchTerm)
                ->orWhere('document_number', 'LIKE', "{$searchTerm}%")
                ->orWhere('name', 'LIKE', "{$searchTerm}%")
                ->orWhere('name', 'LIKE', "% {$searchTerm}%")
                ->orWhere('paternal_lastname', 'LIKE', "{$searchTerm}%")
                ->orWhere('paternal_lastname', 'LIKE', "% {$searchTerm}%")
                ->orWhere('maternal_lastname', 'LIKE', "{$searchTerm}%")
                ->orWhere('maternal_lastname', 'LIKE', "% {$searchTerm}%")
                ->orWhereRaw("CONCAT(paternal_lastname, ' ', name) LIKE ?", ["{$searchTerm}%"])
                ->orWhereRaw("CONCAT(paternal_lastname, ' ', maternal_lastname, ' ', name) LIKE ?", ["{$searchTerm}%"])
                ->orWhereRaw("CONCAT(name, ' ', paternal_lastname, ' ', maternal_lastname) LIKE ?", ["{$searchTerm}%"])
                ->orWhereRaw("CONCAT(COALESCE(paternal_lastname, ''), ' ', COALESCE(SUBSTRING_INDEX(name, ' ', 1), ''), ' ', COALESCE(SUBSTRING_INDEX(name, ' ', -1), '')) LIKE ?", ["{$searchTerm}%"])
                ->orWhereRaw("CONCAT(COALESCE(maternal_lastname, ''), ' ', COALESCE(SUBSTRING_INDEX(name, ' ', 1), ''), ' ', COALESCE(SUBSTRING_INDEX(name, ' ', -1), '')) LIKE ?", ["{$searchTerm}%"])
                ->orWhereRaw("CONCAT(COALESCE(SUBSTRING_INDEX(name, ' ', 1), ''), ' ', COALESCE(paternal_lastname, ''), ' ', COALESCE(maternal_lastname, '')) LIKE ?", ["{$searchTerm}%"])
                ->orWhereRaw("CONCAT(COALESCE(SUBSTRING_INDEX(name, ' ', -1), ''), ' ', COALESCE(paternal_lastname, ''), ' ', COALESCE(maternal_lastname, '')) LIKE ?", ["{$searchTerm}%"]);
        });
    }
}
