<?php
namespace App\Services\Attendance;

use App\Models\Attendance;
use App\Models\AttendanceCode;
use App\Models\User;

class AttendanceService
{
    /**
     * Get all attendance records with related data.
     * Includes user, attendance code, and attendance status information.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function listAll()
    {
        $attendances = Attendance::with(['user:id,name,email', 'attendanceCode:id,code', 'attendanceStatus:id,name,color'])
            ->orderBy('check_in_time', 'desc')
            ->get();

        return $attendances;
    }

    /**
     * Get attendance records for a specific user.
     * Includes user, attendance code, and attendance status information.
     *
     * @param int $userId
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function listByUser($userId)
    {
        $attendances = Attendance::with(['user:id,name,email', 'attendanceCode:id,code', 'attendanceStatus:id,name,color'])
            ->where('user_id', $userId)
            ->orderBy('check_in_time', 'desc')
            ->get();
        return $attendances;
    }

    /**
     * Register a new attendance entry for a user.
     * Validates attendance code, user workspace membership, and prevents duplicate entries.
     * Automatically determines attendance status based on check-in time (Present/Late).
     *
     * @param array $validated
     * @return array
     * @throws \Illuminate\Database\Eloquent\ModelNotFoundException
     */
    public function registerAttendance(array $validated)
    {
        $attendanceCode = AttendanceCode::where('code', $validated['attendance_code'])
            ->where('workspace_id', $validated['workspace_id'])
            ->first();
        if (! $attendanceCode) {
            return [
                'error'   => true,
                'message' => 'Invalid attendance code for this workspace.',
            ];
        }
        $user = User::with('workspaces')->findOrFail($validated['user_id']);
        if (! $user->workspaces->pluck('id')->contains($validated['workspace_id'])) {
            return [
                'error'   => true,
                'message' => 'The user does not belong to the given workspace.',
            ];
        }
        $checkInUtc   = now();
        $checkInLima  = $checkInUtc->copy()->timezone('America/Lima');
        $limaStartDay = $checkInLima->copy()->startOfDay();
        $limaEndDay   = $checkInLima->copy()->endOfDay();
        $existing     = Attendance::where('user_id', $validated['user_id'])
            ->where('attendance_code_id', $attendanceCode->id)
            ->whereBetween('check_in_time', [
                $limaStartDay->copy()->timezone('UTC'),
                $limaEndDay->copy()->timezone('UTC'),
            ])
            ->first();
        if ($existing) {
            return [
                'error'   => true,
                'message' => 'Attendance already registered for this code today.',
            ];
        }
        $startTime  = $checkInLima->copy()->setTime(8, 0, 0);
        $graceTime  = $startTime->copy()->addMinutes(15);
        $statusId   = $checkInLima->lessThanOrEqualTo($graceTime) ? 1 : 3; // 1=Presente, 3=Tarde
        $attendance = Attendance::create([
            'user_id'              => $validated['user_id'],
            'attendance_code_id'   => $attendanceCode->id,
            'check_in_time'        => $checkInUtc,
            'check_out_time'       => null,
            'observation'          => $validated['observation'] ?? null,
            'attendance_status_id' => $statusId,
        ]);
        return [
            'error'      => false,
            'attendance' => $attendance,
        ];
    }

    /**
     * Register checkout time for an existing attendance entry.
     * Validates attendance code and ensures user has a valid check-in for the day.
     *
     * @param array $validated
     * @return array
     */
    public function checkout(array $validated)
    {
        $attendanceCode = AttendanceCode::where('code', $validated['attendance_code'])
            ->where('workspace_id', $validated['workspace_id'])
            ->first();
        if (! $attendanceCode) {
            return [
                'error'   => true,
                'message' => 'Invalid attendance code for this workspace.',
            ];
        }
        $nowUtc       = now();
        $nowLima      = $nowUtc->copy()->timezone('America/Lima');
        $limaDayStart = $nowLima->copy()->startOfDay();
        $limaDayEnd   = $nowLima->copy()->endOfDay();
        $attendance   = Attendance::where('user_id', $validated['user_id'])
            ->where('attendance_code_id', $attendanceCode->id)
            ->whereBetween('check_in_time', [
                $limaDayStart->timezone('UTC'),
                $limaDayEnd->timezone('UTC'),
            ])
            ->whereNull('check_out_time')
            ->first();
        if (! $attendance) {
            return [
                'error'   => true,
                'message' => 'No entry found for today or checkout already marked.',
            ];
        }
        $attendance->update([
            'check_out_time' => $nowUtc,
        ]);
        return [
            'error'      => false,
            'attendance' => $attendance,
        ];
    }

    /**
     * Delete an attendance record.
     *
     * @param \App\Models\Attendance $attendance
     * @return bool
     */
    public function destroy(Attendance $attendance)
    {
        $attendance->delete();
        return true;
    }
}
