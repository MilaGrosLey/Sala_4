<?php
namespace App\Services\RegistrationCode;

use App\Models\RegistrationCode;
use Illuminate\Support\Str;

class RegistrationCodeService
{
    /**
     * Get all registration codes.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function list()
    {
        return RegistrationCode::all();
    }

    /**
     * Find a specific registration code by ID.
     *
     * @param int $id
     * @return \App\Models\RegistrationCode
     * @throws \Illuminate\Database\Eloquent\ModelNotFoundException
     */
    public function find($id)
    {
        return RegistrationCode::findOrFail($id);
    }

    /**
     * Generate a new registration code.
     * Creates a random 10-character uppercase code that expires in 3 days.
     *
     * @return string
     */
    public function generate()
    {
        $code = strtoupper(Str::random(10));

        $registrationCode = RegistrationCode::create([
            'code'       => $code,
            'expires_at' => now()->addDays(3),
        ]);

        return $registrationCode->code;
    }

    /**
     * Verify a registration code.
     * Checks if the code exists, is not used, and has not expired.
     *
     * @param array $data
     * @return \App\Models\RegistrationCode|null
     */
    public function verifyCode(array $data)
    {
        $codigo = RegistrationCode::where('code', $data['code'])
            ->where('is_used', false)
            ->where(function ($q) {
                $q->whereNull('expires_at')
                    ->orWhere('expires_at', '>', now());
            })
            ->first();

        return $codigo;
    }

    /**
     * Delete a registration code.
     *
     * @param \App\Models\RegistrationCode $registrationCode
     * @return bool
     */
    public function delete(RegistrationCode $registrationCode)
    {
        $registrationCode->delete();
        return true;
    }
}
