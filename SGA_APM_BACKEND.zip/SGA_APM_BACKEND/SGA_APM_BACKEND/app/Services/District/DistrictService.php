<?php
namespace App\Services\District;

use App\Exceptions\Conflicts\SoftDeletedConflictException;
use App\Models\District;
use App\Models\Province;

class DistrictService
{
    /**
     * Get all districts.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function list()
    {
        return District::all();
    }

    /**
     * Get districts by province.
     * Uses the province relationship to fetch related districts.
     *
     * @param \App\Models\Province $province
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function showByProvince(Province $province)
    {
        return $province->districts()->get();
    }

    /**
     * Create a new district or restore if soft-deleted.
     * Checks for existing district with the same name and province, and restores it if soft-deleted.
     *
     * @param array $data
     * @return \App\Models\District
     */
    public function create(array $data)
    {
        $district = District::withTrashed()
            ->where('name', $data['name'])
            ->where('province_id', $data['province_id'])
            ->first();
        if ($district) {
            if ($district->trashed()) {
                $district->restore();
            }
            $district->update($data);
            return $district;
        }
        return District::create($data);
    }

    /**
     * Update an existing district.
     * Validates name and province uniqueness and handles soft-deleted conflicts.
     *
     * @param \App\Models\District $district
     * @param array $data
     * @return \App\Models\District|\Illuminate\Http\JsonResponse
     * @throws \App\Exceptions\Conflicts\SoftDeletedConflictException
     */
    public function update(District $district, array $data)
    {
        $nameChanged     = isset($data['name']) && $data['name'] !== $district->name;
        $provinceChanged = isset($data['province_id']) && $data['province_id'] !== $district->province_id;
        if ($nameChanged || $provinceChanged) {
            $softDeleted = District::onlyTrashed()
                ->where('name', $data['name'] ?? $district->name)
                ->where('province_id', $data['province_id'] ?? $district->province_id)
                ->first();
            if ($softDeleted) {
                throw new SoftDeletedConflictException($data['name']);
            }
            $exists = District::where('name', $data['name'] ?? $district->name)
                ->where('province_id', $data['province_id'] ?? $district->province_id)
                ->where('id', '!=', $district->id)
                ->whereNull('deleted_at')
                ->exists();
            if ($exists) {
                return response()->json([
                    'error' => 'Ya existe un registro activo con estos datos.',
                ], 409);
            }
        }
        $district->update($data);
        return $district;
    }

    /**
     * Soft delete a district.
     *
     * @param \App\Models\District $district
     * @return bool
     */
    public function delete(District $district)
    {
        $district->delete();
        return true;
    }
}
