<?php
namespace App\Services\WorkspaceType;

use App\Exceptions\Conflicts\SoftDeletedConflictException;
use App\Models\WorkspaceType;

class WorkspaceTypeService
{
    /**
     * Get all workspace types.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function list()
    {
        return WorkspaceType::all();
    }

    /**
     * Find a specific workspace type by ID.
     *
     * @param int $id
     * @return \App\Models\WorkspaceType
     * @throws \Illuminate\Database\Eloquent\ModelNotFoundException
     */
    public function find($id)
    {
        return WorkspaceType::findOrFail($id);
    }

    /**
     * Create a new workspace type or restore if soft-deleted.
     * Checks for existing workspace type with the same name and restores it if soft-deleted.
     *
     * @param array $data
     * @return \App\Models\WorkspaceType
     */
    public function create(array $data)
    {
        $type = WorkspaceType::withTrashed()
            ->where('name', $data['name'])
            ->first();
        if ($type) {
            if ($type->trashed()) {
                $type->restore();
            }
            $type->update($data);
            return $type;
        }
        return WorkspaceType::create($data);
    }

    /**
     * Update an existing workspace type.
     * Validates name uniqueness and handles soft-deleted conflicts.
     *
     * @param \App\Models\WorkspaceType $workspaceType
     * @param array $data
     * @return \App\Models\WorkspaceType|\Illuminate\Http\JsonResponse
     * @throws \App\Exceptions\Conflicts\SoftDeletedConflictException
     */
    public function update(WorkspaceType $workspaceType, array $data)
    {
        $nameChanged = isset($data['name']) && $data['name'] !== $workspaceType->name;

        if ($nameChanged) {
            $softDeleted = WorkspaceType::onlyTrashed()
                ->where('name', $data['name'])
                ->first();

            if ($softDeleted) {
                throw new SoftDeletedConflictException($data['name']);
            }

            $exists = WorkspaceType::where('name', $data['name'])
                ->where('id', '!=', $workspaceType->id)
                ->whereNull('deleted_at')
                ->exists();

            if ($exists) {
                return response()->json([
                    'error' => 'Ya existe un tipo de workspace activo con este nombre.',
                ], 409);
            }
        }

        $workspaceType->update($data);
        return $workspaceType;
    }

    /**
     * Soft delete a workspace type.
     *
     * @param \App\Models\WorkspaceType $workspaceType
     * @return bool
     */
    public function delete(WorkspaceType $workspaceType)
    {
        $workspaceType->delete();
        return true;
    }
}
