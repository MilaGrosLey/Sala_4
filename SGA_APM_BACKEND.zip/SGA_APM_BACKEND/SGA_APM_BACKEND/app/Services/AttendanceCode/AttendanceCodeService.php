<?php
namespace App\Services\AttendanceCode;

use App\Models\AttendanceCode;
use App\Models\Workspace;
use Carbon\Carbon;
use Illuminate\Support\Str;

class AttendanceCodeService
{
    /**
     * Get all attendance codes.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function list()
    {
        return AttendanceCode::all();
    }

    /**
     * Find a specific attendance code by ID.
     *
     * @param int $id
     * @return \App\Models\AttendanceCode
     * @throws \Illuminate\Database\Eloquent\ModelNotFoundException
     */
    public function find($id)
    {
        return AttendanceCode::findOrFail($id);
    }

    /**
     * Generate a new attendance code for a workspace.
     * Creates a unique code with format: YYYYMMDD-WorkspaceName-RandomString
     * Sets expiration time to 15 minutes from creation.
     *
     * @param array $data
     * @return \App\Models\AttendanceCode
     * @throws \Illuminate\Database\Eloquent\ModelNotFoundException
     */
    public function generateCode(array $data)
    {
        $workspace    = Workspace::findOrFail($data['workspace_id']);
        $date         = Carbon::now()->format('Ymd');
        $randomString = Str::random(5);
        $code         = $date . '-' . $workspace->name . '-' . $randomString;

        $attendanceCode = AttendanceCode::create([
            'code'          => $code,
            'late_after_at' => Carbon::now()->addMinutes(15),
            'workspace_id'  => $workspace->id,
        ]);

        $attendanceCode->description = 'Código generado para el espacio de trabajo "' . $workspace->name . '". '
            . 'Este código sirve para registrar la entrada y salida. '
            . 'Guárdalo en un lugar seguro, de lo contrario perderás el tiempo registrado entre ambos.';

        return $attendanceCode;
    }

    /**
     * Delete an attendance code.
     *
     * @param \App\Models\AttendanceCode $attendanceCode
     * @return bool
     */
    public function delete(AttendanceCode $attendanceCode)
    {
        $attendanceCode->delete();
        return true;
    }
}
