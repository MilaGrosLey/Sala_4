<?php
namespace App\Services\Workspace;

use App\Exceptions\Conflicts\SoftDeletedConflictException;
use App\Models\Workspace;

class WorkspaceService
{
    /**
     * Get all workspaces.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function list()
    {
        return Workspace::all();
    }

    /**
     * Find a specific workspace by ID.
     *
     * @param int $id
     * @return \App\Models\Workspace
     * @throws \Illuminate\Database\Eloquent\ModelNotFoundException
     */
    public function find($id)
    {
        return Workspace::findOrFail($id);
    }

    /**
     * Create a new workspace or restore if soft-deleted.
     * Checks for existing workspace with the same name and restores it if soft-deleted.
     *
     * @param array $data
     * @return \App\Models\Workspace
     */
    public function create(array $data)
    {
        $workspace = Workspace::withTrashed()
            ->where('name', $data['name'])
            ->first();
        if ($workspace) {
            if ($workspace->trashed()) {
                $workspace->restore();
            }
            $workspace->update($data);
            return $workspace;
        }
        return Workspace::create($data);
    }

    /**
     * Update an existing workspace.
     * Validates name uniqueness and handles soft-deleted conflicts.
     *
     * @param \App\Models\Workspace $workspace
     * @param array $data
     * @return \App\Models\Workspace|\Illuminate\Http\JsonResponse
     * @throws \App\Exceptions\Conflicts\SoftDeletedConflictException
     */
    public function update(Workspace $workspace, array $data)
    {
        $nameChanged = isset($data['name']) && $data['name'] !== $workspace->name;

        if ($nameChanged) {
            $softDeleted = Workspace::onlyTrashed()
                ->where('name', $data['name'])
                ->first();

            if ($softDeleted) {
                throw new SoftDeletedConflictException($data['name']);
            }

            $exists = Workspace::where('name', $data['name'])
                ->where('id', '!=', $workspace->id)
                ->whereNull('deleted_at')
                ->exists();

            if ($exists) {
                return response()->json([
                    'error' => 'Ya existe un registro activo con este nombre.',
                ], 409);
            }
        }

        $workspace->update($data);
        return $workspace;
    }

    /**
     * Soft delete a workspace.
     *
     * @param \App\Models\Workspace $workspace
     * @return bool
     */
    public function delete(Workspace $workspace)
    {
        $workspace->delete();
        return true;
    }
}
