<?php
namespace App\Services\UserWorkspace;

use App\Enums\WorkspaceRoleEnum;
use App\Models\UserWorkspace;
use App\Models\Workspace;
use Illuminate\Http\Request;

class UserWorkspaceService
{
    /**
     * Get list of workspaces with their users.
     * Supports pagination and includes basic user information (id, name, email).
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Database\Eloquent\Collection|\Illuminate\Contracts\Pagination\LengthAwarePaginator
     */
    public function list(Request $request)
    {
        $perPage = (int) $request->query('per_page', 0);

        $query = Workspace::with(['users' => function ($q) {
            $q->select('users.id', 'users.name', 'users.email');
        }])->whereHas('users');

        return $perPage > 0
        ? $query->paginate($perPage)
        : $query->get();
    }

    /**
     * Find a specific workspace with its users.
     * Includes basic user information (id, name, email).
     *
     * @param \App\Models\Workspace $workspace
     * @return \App\Models\Workspace
     * @throws \Illuminate\Database\Eloquent\ModelNotFoundException
     */
    public function find(Workspace $workspace)
    {
        return Workspace::with(['users' => function ($q) {
            $q->select('users.id', 'users.name', 'users.email');
        }])->findOrFail($workspace->id);
    }

    /**
     * Assign users to a workspace without removing existing assignments.
     * Uses syncWithoutDetaching to preserve existing user-workspace relationships.
     *
     * @param array $data
     * @return void
     * @throws \Illuminate\Database\Eloquent\ModelNotFoundException
     */
    public function assignUsers(array $data): void
    {
        $workspace = Workspace::findOrFail($data['workspace_id']);

        $syncData = [];
        foreach ($data['members'] as $member) {
            $syncData[$member['user_id']] = [];
        }

        $workspace->users()->syncWithoutDetaching($syncData);
    }

    /**
     * Synchronize users for a workspace, replacing all existing assignments.
     * Uses sync to completely replace the user-workspace relationships.
     *
     * @param array $data
     * @return void
     * @throws \Illuminate\Database\Eloquent\ModelNotFoundException
     */
    public function syncUsers(array $data): void
    {
        $workspace = Workspace::findOrFail($data['workspace_id']);

        $syncData = [];
        foreach ($data['members'] as $member) {
            $syncData[$member['user_id']] = [];
        }

        $workspace->users()->sync($syncData);
    }

    /**
     * Get all available workspace roles.
     * Returns formatted array with value and label for each role.
     *
     * @return array
     */
    public function getRoles(): array
    {
        return collect(WorkspaceRoleEnum::cases())
            ->map(fn($role) => [
                'value' => $role->value,
                'label' => ucfirst(str_replace('_', ' ', $role->name)),
            ])
            ->toArray();
    }

    /**
     * Delete a user-workspace relationship.
     *
     * @param \App\Models\UserWorkspace $userWorkspace
     * @return bool
     */
    public function delete(UserWorkspace $userWorkspace)
    {
        $userWorkspace->delete();
        return true;
    }
}
