<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class AttendanceStatus extends Model
{
    /** @use HasFactory<\Database\Factories\AttendanceStatusFactory> */
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'name',
        'color',
        'is_late',
        'is_justified',
    ];

    public function attendances(): HasMany
    {
        return $this->hasMany(Attendance::class);
    }
}
