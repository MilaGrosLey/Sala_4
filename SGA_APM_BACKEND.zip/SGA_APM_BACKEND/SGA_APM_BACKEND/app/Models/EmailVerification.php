<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

class EmailVerification extends Model
{
    /** @use HasFactory<\Database\Factories\EmailVerificationFactory> */
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'verification_code',
        'is_verified',
        'user_id',
        'expires_at'
    ];

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }
}