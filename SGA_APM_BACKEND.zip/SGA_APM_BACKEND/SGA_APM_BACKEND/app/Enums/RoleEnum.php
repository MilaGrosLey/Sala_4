<?php

// Esto hace cumplir estrictamente los tipos de datos.
declare (strict_types = 1);

namespace App\Enums;

enum RoleEnum: string {
    case ADMIN       = 'admin';
    case COORDINATOR = 'coordinator';
    case STAFF       = 'staff';
    case INTERN      = 'intern';
}
