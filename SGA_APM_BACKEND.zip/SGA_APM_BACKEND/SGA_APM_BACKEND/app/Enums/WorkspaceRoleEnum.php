<?php

declare (strict_types = 1);

namespace App\Enums;

enum WorkspaceRoleEnum: string {
    case LEADER     = 'leader';
    case SUB_LEADER = 'sub_leader';
    case MEMBER     = 'member';
}
