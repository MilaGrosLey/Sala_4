<?php
namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\Career\StoreCareerRequest;
use App\Http\Requests\Career\UpdateCareerRequest;
use App\Http\Resources\Career\CareerResource;
use App\Models\Career;
use App\Services\Career\CareerService;
use Illuminate\Http\JsonResponse;

class CareerController extends Controller
{
    private CareerService $careerService;

    public function __construct(CareerService $careerService)
    {
        $this->careerService = $careerService;
        $this->middleware('can:career.index')->only('index');
        $this->middleware('can:career.store')->only('store');
        $this->middleware('can:career.show')->only('show');
        $this->middleware('can:career.update')->only('update');
        $this->middleware('can:career.destroy')->only('destroy');
    }

    public function index()
    {
        $careers = $this->careerService->list();
        return CareerResource::collection($careers);
    }

    public function show(Career $career)
    {
        return new CareerResource($career);
    }

    public function store(StoreCareerRequest $request)
    {
        $career = $this->careerService->create($request->validated());
        return (new CareerResource($career))->response()->setStatusCode(201);
    }

    public function update(UpdateCareerRequest $request, Career $career)
    {
        $updated = $this->careerService->update($career, $request->validated());
        return new CareerResource($updated);
    }

    public function destroy(Career $career): JsonResponse
    {
        $this->careerService->delete($career);
        return response()->json(null, 204);
    }
}
