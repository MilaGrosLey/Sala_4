<?php
namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\RecurringJustification\StoreRecurringJustificationRequest;
use App\Http\Requests\RecurringJustification\UpdateRecurringJustificationRequest;
use App\Http\Resources\RecurringJustification\RecurringJustificationResource;
use App\Models\RecurringJustification;
use App\Services\RecurringJustification\RecurringJustificationService;
use Illuminate\Http\JsonResponse;

class RecurringJustificationController extends Controller
{
    private RecurringJustificationService $recurringJustificationService;

    public function __construct(RecurringJustificationService $recurringJustificationService)
    {
        $this->recurringJustificationService = $recurringJustificationService;
        $this->middleware('can:recurring_justification.index')->only('index');
        $this->middleware('can:recurring_justification.store')->only('store');
        $this->middleware('can:recurring_justification.show')->only('show');
        $this->middleware('can:recurring_justification.update')->only('update');
        $this->middleware('can:recurring_justification.destroy')->only('destroy');
    }

    public function index()
    {
        $justifications = $this->recurringJustificationService->list();
        return RecurringJustificationResource::collection($justifications);
    }

    public function show(RecurringJustification $recurringJustification)
    {
        return new RecurringJustificationResource($recurringJustification);
    }

    public function store(StoreRecurringJustificationRequest $request)
    {
        $justification = $this->recurringJustificationService->create($request->validated());
        return (new RecurringJustificationResource($justification))->response()->setStatusCode(201);
    }

    public function update(UpdateRecurringJustificationRequest $request, RecurringJustification $recurringJustification)
    {
        $updated = $this->recurringJustificationService->update($recurringJustification, $request->validated());
        return new RecurringJustificationResource($updated);
    }

    public function destroy(RecurringJustification $recurringJustification): JsonResponse
    {
        $this->recurringJustificationService->delete($recurringJustification);
        return response()->json(null, 204);
    }
}
