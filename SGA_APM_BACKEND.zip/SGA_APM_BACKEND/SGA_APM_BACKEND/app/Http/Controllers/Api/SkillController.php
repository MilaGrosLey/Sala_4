<?php
namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\Skill\StoreSkillRequest;
use App\Http\Requests\Skill\UpdateSkillRequest;
use App\Http\Resources\Skill\SkillResource;
use App\Models\Skill;
use App\Services\Skill\SkillService;
use Illuminate\Http\JsonResponse;

class SkillController extends Controller
{
    private SkillService $skillService;

    public function __construct(SkillService $skillService)
    {
        $this->skillService = $skillService;
        $this->middleware('can:skill.index')->only('index');
        $this->middleware('can:skill.store')->only('store');
        $this->middleware('can:skill.show')->only('show');
        $this->middleware('can:skill.update')->only('update');
        $this->middleware('can:skill.destroy')->only('destroy');
    }

    public function index()
    {
        $skills = $this->skillService->list();
        return SkillResource::collection($skills);
    }

    public function show(Skill $skill)
    {
        return new SkillResource($skill);
    }

    public function store(StoreSkillRequest $request)
    {
        $skill = $this->skillService->create($request->validated());
        return (new SkillResource($skill))->response()->setStatusCode(201);
    }

    public function update(UpdateSkillRequest $request, Skill $skill)
    {
        $updated = $this->skillService->update($skill, $request->validated());
        return new SkillResource($updated);
    }

    public function destroy(Skill $skill): JsonResponse
    {
        $this->skillService->delete($skill);
        return response()->json(null, 204);
    }
}
