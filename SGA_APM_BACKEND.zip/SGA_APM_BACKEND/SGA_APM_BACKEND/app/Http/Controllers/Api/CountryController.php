<?php
namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\Country\StoreCountryRequest;
use App\Http\Requests\Country\UpdateCountryRequest;
use App\Http\Resources\Country\CountryResource;
use App\Models\Country;
use App\Services\Country\CountryService;
use Illuminate\Http\JsonResponse;

class CountryController extends Controller
{
    private CountryService $countryService;

    public function __construct(CountryService $countryService)
    {
        $this->countryService = $countryService;
        $this->middleware('can:country.index')->only('index');
        $this->middleware('can:country.store')->only('store');
        $this->middleware('can:country.show')->only('show');
        $this->middleware('can:country.update')->only('update');
        $this->middleware('can:country.destroy')->only('destroy');
    }

    public function index()
    {
        $countries = $this->countryService->list();
        return CountryResource::collection($countries);
    }

    public function show(Country $country)
    {
        return new CountryResource($country);
    }

    public function store(StoreCountryRequest $request)
    {
        $country = $this->countryService->create($request->validated());
        return (new CountryResource($country))->response()->setStatusCode(201);
    }

    public function update(UpdateCountryRequest $request, Country $country)
    {
        $updated = $this->countryService->update($country, $request->validated());
        return new CountryResource($updated);
    }

    public function destroy(Country $country): JsonResponse
    {
        $this->countryService->delete($country);
        return response()->json(null, 204);
    }
}
