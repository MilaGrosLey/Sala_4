<?php
namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\Internship\StoreInternshipRequest;
use App\Http\Requests\Internship\UpdateInternshipRequest;
use App\Http\Resources\Internship\InternshipResource;
use App\Models\Internship;
use App\Services\Internship\InternshipService;
use Illuminate\Http\JsonResponse;

class InternshipController extends Controller
{
    private InternshipService $internshipService;

    public function __construct(InternshipService $internshipService)
    {
        $this->internshipService = $internshipService;
        $this->middleware('can:internship.index')->only('index');
        $this->middleware('can:internship.store')->only('store');
        $this->middleware('can:internship.show')->only('show');
        $this->middleware('can:internship.update')->only('update');
        $this->middleware('can:internship.destroy')->only('destroy');
    }

    public function index()
    {
        $internships = $this->internshipService->list();
        return InternshipResource::collection($internships);
    }

    public function show(Internship $internship)
    {
        return new InternshipResource($internship);
    }

    public function store(StoreInternshipRequest $request)
    {
        $internship = $this->internshipService->create($request->validated());
        return (new InternshipResource($internship))->response()->setStatusCode(201);
    }

    public function update(UpdateInternshipRequest $request, Internship $internship)
    {
        $updated = $this->internshipService->update($internship, $request->validated());
        return new InternshipResource($updated);
    }

    public function destroy(Internship $internship): JsonResponse
    {
        $this->internshipService->delete($internship);
        return response()->json(null, 204);
    }
}
