<?php
namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\EmailVerification\StoreEmailVerificationRequest;
use App\Http\Requests\EmailVerification\UpdateEmailVerificationRequest;
use App\Http\Resources\EmailVerification\EmailVerificationResource;
use App\Models\EmailVerification;
use App\Services\EmailVerification\EmailVerificationService;
use Illuminate\Http\JsonResponse;

class EmailVerificationController extends Controller
{
    private EmailVerificationService $emailVerificationService;

    public function __construct(EmailVerificationService $emailVerificationService)
    {
        $this->emailVerificationService = $emailVerificationService;
        $this->middleware('can:email_verification.index')->only('index');
        $this->middleware('can:email_verification.store')->only('store');
        $this->middleware('can:email_verification.show')->only('show');
        $this->middleware('can:email_verification.update')->only('update');
        $this->middleware('can:email_verification.destroy')->only('destroy');
    }

    public function index()
    {
        $verifications = $this->emailVerificationService->list();
        return EmailVerificationResource::collection($verifications);
    }

    public function show(EmailVerification $emailVerification)
    {
        return new EmailVerificationResource($emailVerification);
    }

    public function store(StoreEmailVerificationRequest $request)
    {
        $verification = $this->emailVerificationService->create($request->validated());
        return (new EmailVerificationResource($verification))->response()->setStatusCode(201);
    }

    public function update(UpdateEmailVerificationRequest $request, EmailVerification $emailVerification)
    {
        $updated = $this->emailVerificationService->update($emailVerification, $request->validated());
        return new EmailVerificationResource($updated);
    }

    public function destroy(EmailVerification $emailVerification): JsonResponse
    {
        $this->emailVerificationService->delete($emailVerification);
        return response()->json(null, 204);
    }
}
