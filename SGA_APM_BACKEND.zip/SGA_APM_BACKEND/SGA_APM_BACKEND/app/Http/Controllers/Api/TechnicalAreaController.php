<?php
namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\TechnicalArea\StoreTechnicalAreaRequest;
use App\Http\Requests\TechnicalArea\UpdateTechnicalAreaRequest;
use App\Http\Resources\TechnicalArea\TechnicalAreaResource;
use App\Models\TechnicalArea;
use App\Services\TechnicalArea\TechnicalAreaService;
use Illuminate\Http\JsonResponse;

class TechnicalAreaController extends Controller
{
    private TechnicalAreaService $technicalAreaService;

    public function __construct(TechnicalAreaService $technicalAreaService)
    {
        $this->technicalAreaService = $technicalAreaService;
        $this->middleware('can:technical_area.index')->only('index');
        $this->middleware('can:technical_area.store')->only('store');
        $this->middleware('can:technical_area.show')->only('show');
        $this->middleware('can:technical_area.update')->only('update');
        $this->middleware('can:technical_area.destroy')->only('destroy');
    }

    public function index()
    {
        $areas = $this->technicalAreaService->list();
        return TechnicalAreaResource::collection($areas);
    }

    public function show(TechnicalArea $technicalArea)
    {
        return new TechnicalAreaResource($technicalArea);
    }

    public function store(StoreTechnicalAreaRequest $request)
    {
        $area = $this->technicalAreaService->create($request->validated());
        return (new TechnicalAreaResource($area))->response()->setStatusCode(201);
    }

    public function update(UpdateTechnicalAreaRequest $request, TechnicalArea $technicalArea)
    {
        $updated = $this->technicalAreaService->update($technicalArea, $request->validated());
        return new TechnicalAreaResource($updated);
    }

    public function destroy(TechnicalArea $technicalArea): JsonResponse
    {
        $this->technicalAreaService->delete($technicalArea);
        return response()->json(null, 204);
    }
}
