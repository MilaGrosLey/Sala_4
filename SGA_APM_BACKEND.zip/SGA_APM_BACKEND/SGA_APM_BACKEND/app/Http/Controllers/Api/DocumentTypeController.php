<?php
namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\DocumentType\StoreDocumentTypeRequest;
use App\Http\Requests\DocumentType\UpdateDocumentTypeRequest;
use App\Http\Resources\DocumentType\DocumentTypeResource;
use App\Models\DocumentType;
use App\Services\DocumentType\DocumentTypeService;
use Illuminate\Http\JsonResponse;

class DocumentTypeController extends Controller
{
    private DocumentTypeService $documentTypeService;

    public function __construct(DocumentTypeService $documentTypeService)
    {
        $this->documentTypeService = $documentTypeService;
        $this->middleware('can:document_type.index')->only('index');
        $this->middleware('can:document_type.store')->only('store');
        $this->middleware('can:document_type.show')->only('show');
        $this->middleware('can:document_type.update')->only('update');
        $this->middleware('can:document_type.destroy')->only('destroy');
    }

    public function index()
    {
        $types = $this->documentTypeService->list();
        return DocumentTypeResource::collection($types);
    }

    public function show(DocumentType $documentType)
    {
        return new DocumentTypeResource($documentType);
    }

    public function store(StoreDocumentTypeRequest $request)
    {
        $type = $this->documentTypeService->create($request->validated());
        return (new DocumentTypeResource($type))->response()->setStatusCode(201);
    }

    public function update(UpdateDocumentTypeRequest $request, DocumentType $documentType)
    {
        $updated = $this->documentTypeService->update($documentType, $request->validated());
        return new DocumentTypeResource($updated);
    }

    public function destroy(DocumentType $documentType): JsonResponse
    {
        $this->documentTypeService->delete($documentType);
        return response()->json(null, 204);
    }
}
