<?php
namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\Province\StoreProvinceRequest;
use App\Http\Requests\Province\UpdateProvinceRequest;
use App\Http\Resources\Province\ProvinceResource;
use App\Models\Province;
use App\Models\Region;
use App\Services\Province\ProvinceService;
use Illuminate\Http\JsonResponse;

class ProvinceController extends Controller
{
    private ProvinceService $provinceService;

    public function __construct(ProvinceService $provinceService)
    {
        $this->provinceService = $provinceService;
        $this->middleware('can:province.index')->only('index');
        $this->middleware('can:province.store')->only('store');
        $this->middleware('can:province.show')->only('show');
        $this->middleware('can:province.update')->only('update');
        $this->middleware('can:province.destroy')->only('destroy');
    }

    public function index()
    {
        $provinces = $this->provinceService->list();
        return ProvinceResource::collection($provinces);
    }

    public function showByRegion(Region $region)
    {
        $provinces = $this->provinceService->showByRegion($region);
        return ProvinceResource::collection($provinces);
    }

    public function store(StoreProvinceRequest $request)
    {
        $province = $this->provinceService->create($request->validated());
        return (new ProvinceResource($province))->response()->setStatusCode(201);
    }

    public function update(UpdateProvinceRequest $request, Province $province)
    {
        $updated = $this->provinceService->update($province, $request->validated());
        return new ProvinceResource($updated);
    }

    public function destroy(Province $province): JsonResponse
    {
        $this->provinceService->delete($province);
        return response()->json(null, 204);
    }
}
