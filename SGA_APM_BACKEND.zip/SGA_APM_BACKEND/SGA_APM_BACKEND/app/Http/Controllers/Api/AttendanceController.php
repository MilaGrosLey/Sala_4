<?php
namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\Attendance\CheckoutAttendanceRequest;
use App\Http\Requests\Attendance\StoreAttendanceRequest;
use App\Http\Resources\Attendance\AttendanceResource;
use App\Models\Attendance;
use App\Services\Attendance\AttendanceService;

class AttendanceController extends Controller
{
    protected $attendanceService;

    public function __construct(AttendanceService $attendanceService)
    {
        $this->attendanceService = $attendanceService;
        $this->middleware('can:attendance.index')->only('index');
        $this->middleware('can:attendance.store')->only('store');
        $this->middleware('can:attendance.show')->only('show');
        $this->middleware('can:attendance.update')->only('checkout');
        $this->middleware('can:attendance.destroy')->only('destroy');
    }

    public function index()
    {
        $attendances = $this->attendanceService->listAll();
        return AttendanceResource::collection($attendances);
    }

    public function show($userId)
    {
        $attendances = $this->attendanceService->listByUser($userId);
        return response()->json([
            'user_id'     => $userId,
            'attendances' => AttendanceResource::collection($attendances),
        ]);
    }

    public function store(StoreAttendanceRequest $request)
    {
        $result = $this->attendanceService->registerAttendance($request->validated());
        if ($result['error']) {
            return response()->json(['message' => $result['message']], 422);
        }
        return response()->json([
            'message' => 'Attendance registered successfully.',
            'data'    => new AttendanceResource($result['attendance']),
        ], 201);
    }

    public function checkout(CheckoutAttendanceRequest $request)
    {
        $result = $this->attendanceService->checkout($request->validated());
        if ($result['error']) {
            $status = $result['message'] === 'No entry found for today or checkout already marked.' ? 404 : 422;
            return response()->json(['message' => $result['message']], $status);
        }
        return response()->json([
            'message' => 'Checkout registered successfully.',
            'data'    => new AttendanceResource($result['attendance']),
        ]);
    }

    public function destroy(Attendance $attendance)
    {
        $this->attendanceService->destroy($attendance);
        return response()->json(null, 204);
    }
}
