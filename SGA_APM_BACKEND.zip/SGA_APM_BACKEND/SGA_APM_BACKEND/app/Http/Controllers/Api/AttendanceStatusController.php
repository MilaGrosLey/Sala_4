<?php
namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\AttendanceStatus\StoreAttendanceStatusRequest;
use App\Http\Requests\AttendanceStatus\UpdateAttendanceStatusRequest;
use App\Http\Resources\AttendanceStatus\AttendanceStatusResource;
use App\Models\AttendanceStatus;
use App\Services\AttendanceStatus\AttendanceStatusService;
use Illuminate\Http\JsonResponse;

class AttendanceStatusController extends Controller
{
    private AttendanceStatusService $attendanceStatusService;

    public function __construct(AttendanceStatusService $attendanceStatusService)
    {
        $this->attendanceStatusService = $attendanceStatusService;
        $this->middleware('can:attendance_status.index')->only('index');
        $this->middleware('can:attendance_status.store')->only('store');
        $this->middleware('can:attendance_status.show')->only('show');
        $this->middleware('can:attendance_status.update')->only('update');
        $this->middleware('can:attendance_status.destroy')->only('destroy');
    }

    public function index()
    {
        $statuses = $this->attendanceStatusService->list();
        return AttendanceStatusResource::collection($statuses);
    }

    public function show(AttendanceStatus $attendanceStatus)
    {
        return new AttendanceStatusResource($attendanceStatus);
    }

    public function store(StoreAttendanceStatusRequest $request)
    {
        $status = $this->attendanceStatusService->create($request->validated());
        return (new AttendanceStatusResource($status))->response()->setStatusCode(201);
    }

    public function update(UpdateAttendanceStatusRequest $request, AttendanceStatus $attendanceStatus)
    {
        $updated = $this->attendanceStatusService->update($attendanceStatus, $request->validated());
        return new AttendanceStatusResource($updated);
    }

    public function destroy(AttendanceStatus $attendanceStatus): JsonResponse
    {
        $this->attendanceStatusService->delete($attendanceStatus);
        return response()->json(null, 204);
    }
}
