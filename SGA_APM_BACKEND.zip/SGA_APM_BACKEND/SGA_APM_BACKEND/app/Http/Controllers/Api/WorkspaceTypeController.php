<?php
namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\WorkspaceType\StoreWorkspaceTypeRequest;
use App\Http\Requests\WorkspaceType\UpdateWorkspaceTypeRequest;
use App\Http\Resources\WorkspaceType\WorkspaceTypeResource;
use App\Models\WorkspaceType;
use App\Services\WorkspaceType\WorkspaceTypeService;
use Illuminate\Http\JsonResponse;

class WorkspaceTypeController extends Controller
{
    private WorkspaceTypeService $workspaceTypeService;

    public function __construct(WorkspaceTypeService $workspaceTypeService)
    {
        $this->workspaceTypeService = $workspaceTypeService;
        $this->middleware('can:workspace_type.index')->only('index');
        $this->middleware('can:workspace_type.store')->only('store');
        $this->middleware('can:workspace_type.show')->only('show');
        $this->middleware('can:workspace_type.update')->only('update');
        $this->middleware('can:workspace_type.destroy')->only('destroy');
    }

    public function index()
    {
        $types = $this->workspaceTypeService->list();
        return WorkspaceTypeResource::collection($types);
    }

    public function show(WorkspaceType $workspaceType)
    {
        return new WorkspaceTypeResource($workspaceType);
    }

    public function store(StoreWorkspaceTypeRequest $request)
    {
        $type = $this->workspaceTypeService->create($request->validated());
        return (new WorkspaceTypeResource($type))->response()->setStatusCode(201);
    }

    public function update(UpdateWorkspaceTypeRequest $request, WorkspaceType $workspaceType)
    {
        $updated = $this->workspaceTypeService->update($workspaceType, $request->validated());
        return new WorkspaceTypeResource($updated);
    }

    public function destroy(WorkspaceType $workspaceType): JsonResponse
    {
        $this->workspaceTypeService->delete($workspaceType);
        return response()->json(null, 204);
    }
}
