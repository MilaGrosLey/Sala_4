<?php
namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\RegistrationCode\VerifyCodeRequest;
use App\Http\Resources\RegistrationCode\GenerateCodeResource;
use App\Http\Resources\RegistrationCode\RegistrationCodeResource;
use App\Http\Resources\RegistrationCode\VerifyCodeResource;
use App\Models\RegistrationCode;
use App\Services\RegistrationCode\RegistrationCodeService;
use Illuminate\Http\JsonResponse;

class RegistrationCodeController extends Controller
{
    private RegistrationCodeService $registrationCodeService;

    public function __construct(RegistrationCodeService $registrationCodeService)
    {
        $this->registrationCodeService = $registrationCodeService;
        $this->middleware('can:registration_code.store')->only('generateCode', 'verifyCode');
        $this->middleware('can:registration_code.index')->only('index');
        $this->middleware('can:registration_code.show')->only('show');
        $this->middleware('can:registration_code.update')->only('update');
        $this->middleware('can:registration_code.destroy')->only('destroy');
    }

    public function index()
    {
        $codes = $this->registrationCodeService->list();
        return RegistrationCodeResource::collection($codes);
    }

    public function show(RegistrationCode $registrationCode)
    {
        return new RegistrationCodeResource($registrationCode);
    }

    public function generateCode()
    {
        $code = $this->registrationCodeService->generate();
        return new GenerateCodeResource($code);
    }

    public function verifyCode(VerifyCodeRequest $request): JsonResponse
    {
        $codigo = $this->registrationCodeService->verifyCode($request->validated());

        if (! $codigo) {
            return (new VerifyCodeResource([
                'valido'  => false,
                'mensaje' => 'Código inválido o expirado',
            ]))->response()->setStatusCode(400);
        }

        return (new VerifyCodeResource(['valido' => true, 'mensaje' => 'Código válido']))->response();
    }

    public function destroy(RegistrationCode $registrationCode): JsonResponse
    {
        $this->registrationCodeService->delete($registrationCode);
        return response()->json(null, 204);
    }

}
