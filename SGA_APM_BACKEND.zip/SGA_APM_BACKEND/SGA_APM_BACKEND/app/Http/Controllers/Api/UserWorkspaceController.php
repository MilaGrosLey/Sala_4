<?php
namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\UserWorkspace\AssignUserToWorkspaceRequest;
use App\Http\Requests\UserWorkspace\SyncWorkspaceMembersRequest;
use App\Http\Resources\UserWorkspace\UserWorkspaceResource;
use App\Models\UserWorkspace;
use App\Models\Workspace;
use App\Services\UserWorkspace\UserWorkspaceService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class UserWorkspaceController extends Controller
{
    private UserWorkspaceService $userWorkspaceService;

    public function __construct(UserWorkspaceService $userWorkspaceService)
    {
        $this->userWorkspaceService = $userWorkspaceService;
        $this->middleware('can:user_workspace.index')->only('index');
        $this->middleware('can:user_workspace.show')->only('show');
        $this->middleware('can:user_workspace.store')->only('assignUserToWorkspace', 'syncWorkspaceMembers');
        $this->middleware('can:user_workspace.roles')->only('getWorkspaceRoles');

        /*
        Esto se usa por si se quiere usar el middleware(personalizado) de workspace.role, en la cual verifica si el usuario tiene el rol de leader o sub_leader en el user_workspace

        $this->middleware([
            'can:user_workspace.store', // permisos -> admin, coordinator, staff, intern (verificar el permiso si tiene permitido el acceso a staff, intern, sino actualizar el permiso o crear un nuevo permiso y reemplazar el actual)
            'workspace.role:leader,sub_leader', // roles -> leader, sub_leader
        ])->only('assignUserToWorkspace', 'syncWorkspaceMembers');

        Eso quiere decir que el usuario debe tener el dos roles uno global(can:user_workspace.store) y otro local(workspace.role:leader,sub_leader).
        El global es si tiene rol de admin, coordinator, staff o intern y el local es si tiene rol de leader o sub_leader en el user_workspace.
        Lo cual se verifica dos cosas el middleware de can y el middleware de workspace.role para acceder a los metodos assignUserToWorkspace y syncWorkspaceMembers.
        EJemplo: un usuario tiene rol staff y tiene rol de member en el user_workspace, por lo tanto no puede acceder a los metodos assignUserToWorkspace y syncWorkspaceMembers.
        Pero si tiene rol de leader o sub_leader en el user_workspace, por lo tanto puede acceder a los metodos assignUserToWorkspace y syncWorkspaceMembers.
        Si es admin o coordinator, puede acceder a los metodos assignUserToWorkspace y syncWorkspaceMembers sin importar el rol en el user_workspace.
        */
    }

    public function index(Request $request)
    {
        $userWorkspaces = $this->userWorkspaceService->list($request);
        return UserWorkspaceResource::collection($userWorkspaces);
    }

    public function show(Workspace $workspace)
    {
        $workspace = $this->userWorkspaceService->find($workspace);
        return new UserWorkspaceResource($workspace);
    }

    public function assignUserToWorkspace(AssignUserToWorkspaceRequest $request): JsonResponse
    {
        $this->userWorkspaceService->assignUsers($request->validated());

        return response()->json(['message' => 'Miembros asignados correctamente'], 200);
    }

    public function syncWorkspaceMembers(SyncWorkspaceMembersRequest $request): JsonResponse
    {
        $this->userWorkspaceService->syncUsers($request->validated());

        return response()->json(['message' => 'Miembros del workspace actualizados correctamente'], 200);
    }

    public function getWorkspaceRoles(): JsonResponse
    {
        $roles = $this->userWorkspaceService->getRoles();
        return response()->json($roles);
    }

    public function destroy(UserWorkspace $userWorkspace): JsonResponse
    {
        $this->userWorkspaceService->delete($userWorkspace);
        return response()->json(null, 204);
    }

}
