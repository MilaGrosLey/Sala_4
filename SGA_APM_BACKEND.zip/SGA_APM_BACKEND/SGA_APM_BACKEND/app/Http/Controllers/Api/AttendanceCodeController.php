<?php
namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\AttendanceCode\GenerateCodeRequest;
use App\Http\Resources\AttendanceCode\AttendanceCodeResource;
use App\Models\AttendanceCode;
use App\Services\AttendanceCode\AttendanceCodeService;
use Illuminate\Http\JsonResponse;

class AttendanceCodeController extends Controller
{
    private AttendanceCodeService $attendanceCodeService;

    public function __construct(AttendanceCodeService $attendanceCodeService)
    {
        $this->attendanceCodeService = $attendanceCodeService;
        $this->middleware('can:attendance_code.index')->only('index');
        $this->middleware('can:attendance_code.show')->only('show');
        $this->middleware('can:attendance_code.destroy')->only('destroy');
        $this->middleware([
            'can:attendance_code.generate',
            'workspace.role:leader,subleader',
        ])->only('generateCode');
    }

    public function index()
    {
        $codes = $this->attendanceCodeService->list();
        return AttendanceCodeResource::collection($codes);
    }

    public function show(AttendanceCode $attendanceCode)
    {
        return new AttendanceCodeResource($attendanceCode);
    }

    public function generateCode(GenerateCodeRequest $request)
    {
        $code = $this->attendanceCodeService->generateCode($request->validated());
        return new AttendanceCodeResource($code);
    }

    public function destroy(AttendanceCode $attendanceCode): JsonResponse
    {
        $this->attendanceCodeService->delete($attendanceCode);
        return response()->json(null, 204);
    }
}
