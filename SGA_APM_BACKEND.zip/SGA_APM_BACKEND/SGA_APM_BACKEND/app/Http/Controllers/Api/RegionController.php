<?php
namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\Region\StoreRegionRequest;
use App\Http\Requests\Region\UpdateRegionRequest;
use App\Http\Resources\Region\RegionResource;
use App\Models\Region;
use App\Services\Region\RegionService;
use Illuminate\Http\JsonResponse;

class RegionController extends Controller
{
    private RegionService $regionService;

    public function __construct(RegionService $regionService)
    {
        $this->regionService = $regionService;
        $this->middleware('can:region.index')->only('index');
        $this->middleware('can:region.store')->only('store');
        $this->middleware('can:region.show')->only('show');
        $this->middleware('can:region.update')->only('update');
        $this->middleware('can:region.destroy')->only('destroy');
    }

    public function index()
    {
        $regions = $this->regionService->list();
        return RegionResource::collection($regions);
    }

    public function show(Region $region)
    {
        return new RegionResource($region);
    }

    public function store(StoreRegionRequest $request)
    {
        $region = $this->regionService->create($request->validated());
        return (new RegionResource($region))->response()->setStatusCode(201);
    }

    public function update(UpdateRegionRequest $request, Region $region)
    {
        $updated = $this->regionService->update($region, $request->validated());
        return new RegionResource($updated);
    }

    public function destroy(Region $region): JsonResponse
    {
        $this->regionService->delete($region);
        return response()->json(null, 204);
    }
}
