<?php
namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\Workspace\StoreWorkspaceRequest;
use App\Http\Requests\Workspace\UpdateWorkspaceRequest;
use App\Http\Resources\Workspace\WorkspaceResource;
use App\Models\Workspace;
use App\Services\Workspace\WorkspaceService;
use Illuminate\Http\JsonResponse;

class WorkspaceController extends Controller
{
    private WorkspaceService $workspaceService;

    public function __construct(WorkspaceService $workspaceService)
    {
        $this->workspaceService = $workspaceService;
        $this->middleware('can:workspace.index')->only('index');
        $this->middleware('can:workspace.store')->only('store');
        $this->middleware('can:workspace.show')->only('show');
        $this->middleware('can:workspace.update')->only('update');
        $this->middleware('can:workspace.destroy')->only('destroy');
    }

    public function index()
    {
        $workspaces = $this->workspaceService->list();
        return WorkspaceResource::collection($workspaces);
    }

    public function show(Workspace $workspace)
    {
        return new WorkspaceResource($workspace);
    }

    public function store(StoreWorkspaceRequest $request)
    {
        $workspace = $this->workspaceService->create($request->validated());
        return (new WorkspaceResource($workspace))->response()->setStatusCode(201);
    }

    public function update(UpdateWorkspaceRequest $request, Workspace $workspace)
    {
        $updated = $this->workspaceService->update($workspace, $request->validated());
        return new WorkspaceResource($updated);
    }

    public function destroy(Workspace $workspace): JsonResponse
    {
        $this->workspaceService->delete($workspace);
        return response()->json(null, 204);
    }
}
