<?php
namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\District\StoreDistrictRequest;
use App\Http\Requests\District\UpdateDistrictRequest;
use App\Http\Resources\District\DistrictResource;
use App\Models\District;
use App\Models\Province;
use App\Services\District\DistrictService;
use Illuminate\Http\JsonResponse;

class DistrictController extends Controller
{
    private DistrictService $districtService;

    public function __construct(DistrictService $districtService)
    {
        $this->districtService = $districtService;
        $this->middleware('can:district.index')->only('index');
        $this->middleware('can:district.store')->only('store');
        $this->middleware('can:district.show')->only('show');
        $this->middleware('can:district.update')->only('update');
        $this->middleware('can:district.destroy')->only('destroy');
    }

    public function index()
    {
        $districts = $this->districtService->list();
        return DistrictResource::collection($districts);
    }

    public function showByProvince(Province $province)
    {
        $districts = $this->districtService->showByProvince($province);
        return DistrictResource::collection($districts);
    }

    public function store(StoreDistrictRequest $request)
    {
        $district = $this->districtService->create($request->validated());
        return (new DistrictResource($district))->response()->setStatusCode(201);
    }

    public function update(UpdateDistrictRequest $request, District $district)
    {
        $updated = $this->districtService->update($district, $request->validated());
        return new DistrictResource($updated);
    }

    public function destroy(District $district): JsonResponse
    {
        $this->districtService->delete($district);
        return response()->json(null, 204);
    }
}
