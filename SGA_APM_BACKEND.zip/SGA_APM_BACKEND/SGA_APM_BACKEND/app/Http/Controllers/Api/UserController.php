<?php
namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\User\SearchUsersRequest;
use App\Http\Requests\User\StoreUserRequest;
use App\Http\Requests\User\UpdateUserRequest;
use App\Http\Resources\User\UserDetailResource;
use App\Http\Resources\User\UserListResource;
use App\Models\User;
use App\Services\User\UserService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;

class UserController extends Controller
{
    public function __construct(private UserService $userService)
    {
        $this->userService = $userService;

        $this->middleware('can:user.index')->only('index');
        $this->middleware('can:user.show')->only('show');
        $this->middleware('can:user.update')->only('update');
        $this->middleware('can:user.destroy')->only('destroy');
    }

    /**
     * Display a listing of the resource.
     */
    public function index(Request $request): AnonymousResourceCollection
    {
        $users = $this->userService->index($request);
        return UserListResource::collection($users);
    }

    /**
     * Display the specified resource.
     */
    public function show(User $user): UserDetailResource
    {
        $user = $this->userService->show($user);
        return new UserDetailResource($user);
    }

    /**
     * Display a listing of the resource.
     */
    public function searchUsers(SearchUsersRequest $request): AnonymousResourceCollection
    {
        $users = $this->userService->searchUsers($request->validated());
        return UserListResource::collection($users);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreUserRequest $request): JsonResponse | UserDetailResource
    {
        $result = $this->userService->store($request->validated());

        if (is_array($result) && isset($result['error'])) {
            return response()->json([
                'message' => $result['message'],
            ], 422);
        }

        return new UserDetailResource($result);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateUserRequest $request, User $user): UserDetailResource
    {
        $user = $this->userService->update($request->validated(), $user);
        return new UserDetailResource($user);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(User $user): JsonResponse
    {
        return $this->userService->destroy($user);
    }

}
