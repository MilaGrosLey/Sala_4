<?php
namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Response;

class AuthenticatedController extends Controller
{

    /**
     * Authenticate the user and issue a new API token.
     *
     * @param Request $request HTTP request containing user credentials.
     * @return JsonResponse Access token, token type, and user role on success or error message on failure.
     */
    public function store(Request $request)
    {
        // Validar los datos
        $credentials = $request->validate([
            'email'    => ['required', 'email'],
            'password' => ['required'],
        ]);

        // Intentar autenticación
        if (! Auth::attempt($credentials)) {
            return response()->json(['message' => 'Credenciales inválidas.'], Response::HTTP_UNAUTHORIZED);
        }

        // Obtener usuario autenticado
        $user = $request->user();

        // Eliminar tokens anteriores (opcional pero recomendable)
        $user->tokens()->delete();
        // Crear nuevo token
        $token = $user->createToken('token-api')->plainTextToken;

        // Retornar token y usuario
        return response()->json([
            'access_token' => $token,
            'token_type'   => 'Bearer',
            'role'         => $user->getRoleNames()->first(),
        ], Response::HTTP_OK);
    }

    /**
     * Revoke the current access token and logout the authenticated user.
     *
     * @param Request $request HTTP request.
     * @return JsonResponse Success message on successful logout.
     */
    public function destroy(Request $request)
    {
        $request->user()->currentAccessToken()->delete();

        return new JsonResponse([
            'message' => 'Cerró sesión exitosamente.',
        ], Response::HTTP_OK);
    }
}
