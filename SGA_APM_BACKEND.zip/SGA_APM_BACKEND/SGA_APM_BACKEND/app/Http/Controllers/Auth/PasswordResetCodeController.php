<?php
namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Mail\ResetCodeMail;
use App\Models\PasswordResetCode;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;

class PasswordResetCodeController extends Controller
{
    /**
     * Send a password reset code to a user's email.
     *
     * @param Request $request HTTP request containing 'email' and optional 'app_name'.
     * @return \Illuminate\Http\JsonResponse Message indicating code dispatch status.
     */
    public function sendCode(Request $request)
    {
        $request->validate([
            'email' => 'required|email|exists:users,email',
        ]);

        $code = rand(100000, 999999);

        PasswordResetCode::updateOrCreate(
            ['email' => $request->email],
            [
                'token'      => $code,
                'created_at' => now(),
                'expires_at' => now()->addMinutes(15),
            ]
        );

        $appName = $request->input('app_name', 'APM INVERSIONES E.I.R.L');

        Mail::to($request->email)->send(new ResetCodeMail($code, $appName));

        return response()->json(['message' => 'Código enviado correctamente.']);
    }

    /**
     * Reset the user's password using a valid reset code.
     *
     * @param Request $request HTTP request containing 'email', 'code', and 'new_password' (confirmed).
     * @return \Illuminate\Http\JsonResponse Message indicating password reset status.
     */
    public function resetPassword(Request $request)
    {
        $request->validate([
            'email'        => 'required|email',
            'code'         => 'required',
            'new_password' => 'required|min:5|confirmed',
        ]);

        $tokenRecord = PasswordResetCode::where('email', $request->email)
            ->where('token', $request->code)
            ->where('expires_at', '>=', now())
            ->first();

        if (! $tokenRecord) {
            return response()->json(['message' => 'Código inválido o expirado.'], 422);
        }

        $user           = User::where('email', $request->email)->first();
        $user->password = Hash::make($request->new_password);
        $user->save();

        // Borra el código después de usarlo
        $tokenRecord->delete();

        return response()->json(['message' => 'Contraseña actualizada correctamente.']);
    }

}
