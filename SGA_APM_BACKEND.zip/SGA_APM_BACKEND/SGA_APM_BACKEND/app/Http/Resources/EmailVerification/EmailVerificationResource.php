<?php
namespace App\Http\Resources\EmailVerification;

use Illuminate\Http\Resources\Json\JsonResource;

class EmailVerificationResource extends JsonResource
{
    public function toArray($request)
    {
        return [
            'id'                => $this->id,
            'verification_code' => $this->verification_code,
            'is_verified'       => $this->is_verified,
            'user_id'           => $this->user_id,
            'expires_at'        => $this->expires_at,
        ];
    }
}
