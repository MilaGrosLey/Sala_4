<?php
namespace App\Http\Resources\Workspace;

use Illuminate\Http\Resources\Json\JsonResource;

class WorkspaceResource extends JsonResource
{
    public function toArray($request)
    {
        return [
            'id'                => $this->id,
            'name'              => $this->name,
            'description'       => $this->description,
            'workspace_type_id' => $this->workspace_type_id,
        ];
    }
}
