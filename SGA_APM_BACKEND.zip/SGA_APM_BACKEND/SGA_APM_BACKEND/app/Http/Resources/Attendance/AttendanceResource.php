<?php
namespace App\Http\Resources\Attendance;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class AttendanceResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'id'              => $this->id,
            'user'            => $this->whenLoaded('user', function () {
                return [
                    'id'    => $this->user->id,
                    'name'  => $this->user->name,
                    'email' => $this->user->email,
                ];
            }),
            'attendance_code' => $this->attendanceCode->code ?? null,
            'status'          => $this->whenLoaded('attendanceStatus', function () {
                return [
                    'id'    => $this->attendanceStatus->id,
                    'name'  => $this->attendanceStatus->name,
                    'color' => $this->attendanceStatus->color,
                ];
            }),
            'check_in_time'   => withLimaTimeZone($this->check_in_time),
            'check_out_time'  => $this->check_out_time ? withLimaTimeZone($this->check_out_time) : null,
            'observation'     => $this->observation,
            'created_at'      => withLimaTimeZone($this->created_at),
            'updated_at'      => withLimaTimeZone($this->updated_at),
        ];
    }
}
