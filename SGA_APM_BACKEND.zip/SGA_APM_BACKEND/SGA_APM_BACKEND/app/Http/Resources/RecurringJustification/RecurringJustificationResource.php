<?php
namespace App\Http\Resources\RecurringJustification;

use Illuminate\Http\Resources\Json\JsonResource;

class RecurringJustificationResource extends JsonResource
{
    public function toArray($request)
    {
        return [
            'id'      => $this->id,
            'weekday' => $this->weekday,
            'reason'  => $this->reason,
            'user_id' => $this->user_id,
        ];
    }
}
