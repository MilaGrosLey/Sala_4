<?php
namespace App\Http\Resources\User;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

/**
 * @mixin \App\Models\User
 */
class UserDetailResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'id'                => $this->id,
            'document_number'   => $this->document_number,
            'name'              => $this->name,
            'paternal_lastname' => $this->paternal_lastname,
            'maternal_lastname' => $this->maternal_lastname,
            'address'           => $this->address,
            'phone'             => $this->phone,
            'email'             => $this->email,
            'user_name'         => $this->user_name,

            'document_type'     => $this->whenLoaded('documentType', function () {
                return [
                    'id'   => $this->document_type_id,
                    'name' => $this->documentType->name ?? null,
                ];
            }),

            'district'          => $this->whenLoaded('district', function () {
                $d = $this->district;
                return [
                    'id'       => $d->id,
                    'name'     => $d->name,
                    'province' => $d->province ? [
                        'id'     => $d->province->id,
                        'name'   => $d->province->name,
                        'region' => $d->province->region ? [
                            'id'   => $d->province->region->id,
                            'name' => $d->province->region->name,
                        ] : null,
                    ] : null,
                ];
            }),

            'country'           => $this->whenLoaded('country', function () {
                return [
                    'id'   => $this->country_id,
                    'name' => $this->country->name ?? null,
                ];
            }),

            'created_at'        => withLimaTimeZone($this->created_at),
            'updated_at'        => withLimaTimeZone($this->updated_at),
            'deleted_at'        => withLimaTimeZone($this->deleted_at),
        ];
    }
}
