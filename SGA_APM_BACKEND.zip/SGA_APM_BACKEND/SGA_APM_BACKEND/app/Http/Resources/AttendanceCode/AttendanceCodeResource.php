<?php
namespace App\Http\Resources\AttendanceCode;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class AttendanceCodeResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'id'            => $this->id,
            'code'          => $this->code,
            'description'   => $this->when(! is_null($this->description), $this->description),
            'workspace_id'  => $this->workspace_id,
            'late_after_at' => withLimaTimeZone($this->late_after_at),
            'created_at'    => withLimaTimeZone($this->created_at),
            'updated_at'    => withLimaTimeZone($this->updated_at),
        ];
    }
}
