<?php
namespace App\Http\Resources\Internship;

use Illuminate\Http\Resources\Json\JsonResource;

class InternshipResource extends JsonResource
{
    public function toArray($request)
    {
        return [
            'id'         => $this->id,
            'start_date' => $this->start_date,
            'end_date'   => $this->end_date,
            'user_id'    => $this->user_id,
        ];
    }
}
