<?php
namespace App\Http\Resources\RegistrationCode;

use Illuminate\Http\Resources\Json\JsonResource;

class RegistrationCodeResource extends JsonResource
{
    public function toArray($request)
    {
        return [
            'id'         => $this->id,
            'code'       => $this->code,
            'is_used'    => $this->is_used,
            'expires_at' => $this->expires_at,
        ];
    }
}
