<?php
namespace App\Http\Resources\RegistrationCode;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class GenerateCodeResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'code'         => $this->resource,
            'message'      => 'Código generado correctamente',
            'generated_at' => withLimaTimeZone(now()->toISOString()),
        ];
    }
}
