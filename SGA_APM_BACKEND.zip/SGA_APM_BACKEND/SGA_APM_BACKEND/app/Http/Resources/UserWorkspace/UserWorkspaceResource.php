<?php
namespace App\Http\Resources\UserWorkspace;

use Illuminate\Http\Resources\Json\JsonResource;

class UserWorkspaceResource extends JsonResource
{
    public function toArray($request)
    {
        return [
            'workspace_id'  => $this->id,
            'name'          => $this->name ?? null,
            'members_count' => $this->users->count(),
            'members'       => $this->users->map(function ($user) {
                return [
                    'user_id' => $user->id,
                    'name'    => $user->name ?? null,
                    'email'   => $user->email ?? null,
                ];
            })->values(),
        ];
    }
}
