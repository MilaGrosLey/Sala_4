<?php
namespace App\Http\Requests\Workspace;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class UpdateWorkspaceRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        $workspace = $this->route('workspace')->id ?? null;
        return [
            'name'              => [
                'required',
                Rule::unique('workspaces', 'name')
                    ->ignore($workspace)
                    ->whereNull('deleted_at'),
            ],
            'description'       => 'nullable',
            'workspace_type_id' => 'required|exists:workspace_types,id',
        ];
    }
}
