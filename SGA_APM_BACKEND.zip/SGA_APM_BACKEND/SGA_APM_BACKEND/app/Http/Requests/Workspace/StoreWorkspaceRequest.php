<?php
namespace App\Http\Requests\Workspace;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class StoreWorkspaceRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'name'              => [
                'required',
                Rule::unique('workspaces', 'name')->whereNull('deleted_at'),
            ],
            'description'       => 'nullable',
            'workspace_type_id' => 'required|exists:workspace_types,id',
        ];
    }
}
