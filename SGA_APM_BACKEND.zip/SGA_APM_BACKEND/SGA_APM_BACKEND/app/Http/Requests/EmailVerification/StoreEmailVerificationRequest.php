<?php
namespace App\Http\Requests\EmailVerification;

use Illuminate\Foundation\Http\FormRequest;

class StoreEmailVerificationRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'verification_code' => 'required|string|max:255',
            'is_verified'       => 'required|boolean',
            'user_id'           => 'required|exists:users,id',
            'expires_at'        => 'nullable|date',
        ];
    }
}
