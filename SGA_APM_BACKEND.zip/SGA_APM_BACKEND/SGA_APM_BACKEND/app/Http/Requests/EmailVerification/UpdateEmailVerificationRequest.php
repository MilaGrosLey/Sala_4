<?php
namespace App\Http\Requests\EmailVerification;

use Illuminate\Foundation\Http\FormRequest;

class UpdateEmailVerificationRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'verification_code' => 'sometimes|string|max:255',
            'is_verified'       => 'sometimes|boolean',
            'user_id'           => 'sometimes|exists:users,id',
            'expires_at'        => 'nullable|date',
        ];
    }
}
