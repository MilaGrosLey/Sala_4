<?php
namespace App\Http\Requests\TechnicalArea;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class StoreTechnicalAreaRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'name' => [
                'required',
                Rule::unique('technical_areas')->whereNull('deleted_at'),
            ],
        ];
    }
}
