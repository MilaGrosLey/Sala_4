<?php
namespace App\Http\Requests\TechnicalArea;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class UpdateTechnicalAreaRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        $technicalArea = $this->route('technicalArea')->id ?? null;
        return [
            'name' => [
                'required',
                Rule::unique('technical_areas', 'name')
                    ->ignore($technicalArea)
                    ->whereNull('deleted_at'),
            ],
        ];
    }
}
