<?php
namespace App\Http\Requests\User;

use Illuminate\Foundation\Http\FormRequest;

class UpdateUserRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        $userId = $this->route('user')?->id ?? null;

        return [
            'document_number'   => 'sometimes|string|max:20|unique:users,document_number,' . $userId,
            'name'              => 'sometimes|string|max:255',
            'paternal_lastname' => 'sometimes|string|max:255',
            'maternal_lastname' => 'sometimes|string|max:255',
            'email'             => 'sometimes|email|unique:users,email,' . $userId,
            'user_name'         => 'sometimes|string|max:50|unique:users,user_name,' . $userId,
            'phone'             => 'sometimes|string|max:20',
            'address'           => 'sometimes|string|max:255',
            'document_type_id'  => 'sometimes|exists:document_types,id',
            'ubigeo_id'         => 'sometimes|exists:districts,id',
            'country_id'        => 'sometimes|exists:countries,id',
        ];
    }
}
