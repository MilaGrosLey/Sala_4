<?php
namespace App\Http\Requests\RecurringJustification;

use Illuminate\Foundation\Http\FormRequest;

class StoreRecurringJustificationRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'weekday' => 'required|integer|min:0|max:6',
            'reason'  => 'required|string|max:255',
            'user_id' => 'required|exists:users,id',
        ];
    }
}
