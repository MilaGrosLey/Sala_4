<?php
namespace App\Http\Requests\RecurringJustification;

use Illuminate\Foundation\Http\FormRequest;

class UpdateRecurringJustificationRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'weekday' => 'sometimes|integer|min:0|max:6',
            'reason'  => 'sometimes|string|max:255',
            'user_id' => 'sometimes|exists:users,id',
        ];
    }
}
