<?php
namespace App\Http\Requests\AttendanceStatus;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class StoreAttendanceStatusRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'name'  => [
                'required',
                Rule::unique('attendance_statuses', 'name')
                    ->whereNull('deleted_at'),
            ],
            'color' => 'required|string',
        ];
    }
}
