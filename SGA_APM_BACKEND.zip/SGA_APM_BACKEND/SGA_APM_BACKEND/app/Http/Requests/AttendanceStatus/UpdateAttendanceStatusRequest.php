<?php
namespace App\Http\Requests\AttendanceStatus;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class UpdateAttendanceStatusRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        $attendanceStatus = $this->route('attendanceStatus')->id ?? null;
        return [
            'name'  => [
                'required',
                Rule::unique('attendance_statuses', 'name')
                    ->ignore($attendanceStatus)
                    ->whereNull('deleted_at'),
            ],
            'color' => 'required|string',
        ];
    }
}
