<?php
namespace App\Http\Requests\DocumentType;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class UpdateDocumentTypeRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        $documentType = $this->route('documentType')->id ?? null;

        return [
            'name'        => [
                'sometimes',
                'string',
                'max:255',
                Rule::unique('document_types', 'name')
                    ->ignore($documentType)
                    ->whereNull('deleted_at'),
            ],
            'description' => 'nullable|string|max:255',
        ];
    }
}
