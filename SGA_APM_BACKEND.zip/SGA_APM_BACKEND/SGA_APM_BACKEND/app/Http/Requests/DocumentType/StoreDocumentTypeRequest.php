<?php
namespace App\Http\Requests\DocumentType;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class StoreDocumentTypeRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'name'        => [
                'sometimes',
                'string',
                'max:255',
                Rule::unique('document_types', 'name')
                    ->ignore($this->id)
                    ->whereNull('deleted_at'),
            ],
            'description' => 'nullable|string|max:255',
        ];
    }
}
