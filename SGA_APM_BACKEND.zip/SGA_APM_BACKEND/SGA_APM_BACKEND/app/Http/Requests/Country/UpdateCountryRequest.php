<?php
namespace App\Http\Requests\Country;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class UpdateCountryRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        $country = $this->route('country')->id ?? null;
        return [
            'name'       => [
                'required',
                Rule::unique('countries', 'name')
                    ->ignore($country)
                    ->whereNull('deleted_at'),
            ],
            'phone_code' => 'nullable',
            'ISO2'       => 'nullable',
        ];
    }
}
