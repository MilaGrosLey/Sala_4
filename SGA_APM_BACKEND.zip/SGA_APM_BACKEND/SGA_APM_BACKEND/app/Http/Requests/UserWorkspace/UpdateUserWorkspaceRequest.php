<?php
namespace App\Http\Requests\UserWorkspace;

use Illuminate\Foundation\Http\FormRequest;

class UpdateUserWorkspaceRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'workspace_id'      => 'sometimes|exists:workspaces,id',
            'members'           => 'sometimes|array|min:1',
            'members.*.user_id' => 'sometimes|exists:users,id',
        ];
    }
}
