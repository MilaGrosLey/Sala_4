<?php
namespace App\Http\Requests\UserWorkspace;

use Illuminate\Foundation\Http\FormRequest;

class StoreUserWorkspaceRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'workspace_id'      => 'required|exists:workspaces,id',
            'members'           => 'required|array|min:1',
            'members.*.user_id' => 'required|exists:users,id',
        ];
    }
}
