<?php
namespace App\Http\Requests\Career;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class UpdateCareerRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        $career = $this->route('career')->id ?? null;
        return [
            'name' => [
                'required',
                Rule::unique('careers', 'name')
                    ->ignore($career)
                    ->whereNull('deleted_at'),
            ],
        ];
    }
}
