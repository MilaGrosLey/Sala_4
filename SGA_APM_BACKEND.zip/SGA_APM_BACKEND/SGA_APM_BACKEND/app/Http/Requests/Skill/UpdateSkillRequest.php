<?php
namespace App\Http\Requests\Skill;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class UpdateSkillRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        $skill = $this->route('skill')->id ?? null;
        return [
            'name'              => [
                'required',
                Rule::unique('skills', 'name')
                    ->ignore($skill)
                    ->whereNull('deleted_at'),
            ],
            'technical_area_id' => 'sometimes|exists:technical_areas,id',
        ];
    }
}
