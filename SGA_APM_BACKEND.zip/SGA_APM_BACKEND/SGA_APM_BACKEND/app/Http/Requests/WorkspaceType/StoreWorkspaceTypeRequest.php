<?php
namespace App\Http\Requests\WorkspaceType;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class StoreWorkspaceTypeRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'name'        => [
                'required',
                Rule::unique('workspace_types', 'name')->whereNull('deleted_at'),
            ],
            'description' => 'nullable',
        ];
    }
}
