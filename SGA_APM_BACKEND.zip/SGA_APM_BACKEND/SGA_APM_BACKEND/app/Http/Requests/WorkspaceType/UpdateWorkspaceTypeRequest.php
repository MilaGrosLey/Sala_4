<?php
namespace App\Http\Requests\WorkspaceType;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class UpdateWorkspaceTypeRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        $workspaceType = $this->route('workspaceType')->id ?? null;
        return [
            'name'        => [
                'required',
                Rule::unique('workspace_types', 'name')
                    ->ignore($workspaceType)
                    ->whereNull('deleted_at'),
            ],
            'description' => 'nullable',
        ];
    }
}
