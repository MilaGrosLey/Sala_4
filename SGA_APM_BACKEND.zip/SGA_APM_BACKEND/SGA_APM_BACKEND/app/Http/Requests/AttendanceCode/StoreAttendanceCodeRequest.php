<?php
namespace App\Http\Requests\AttendanceCode;

use Illuminate\Foundation\Http\FormRequest;

class StoreAttendanceCodeRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'code'        => 'required|string|max:255',
            'description' => 'required|string',
            'status'      => 'required|boolean',
            'expires_at'  => 'nullable|date',
        ];
    }

    /**
     * Get custom messages for validator errors.
     *
     * @return array
     */
    public function messages(): array
    {
        return [
            'code.required'        => 'El código es obligatorio.',
            'code.string'          => 'El código debe ser una cadena de texto.',
            'code.max'             => 'El código no puede tener más de 255 caracteres.',
            'description.required' => 'La descripción es obligatoria.',
            'description.string'   => 'La descripción debe ser una cadena de texto.',
            'status.required'      => 'El estado es obligatorio.',
            'status.boolean'       => 'El estado debe ser verdadero o falso.',
            'expires_at.date'      => 'La fecha de expiración debe ser una fecha válida.',
        ];
    }
}
