<?php
namespace App\Http\Requests\AttendanceCode;

use Illuminate\Foundation\Http\FormRequest;

class UpdateAttendanceCodeRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'code'        => 'sometimes|string|max:255',
            'description' => 'sometimes|string',
            'status'      => 'sometimes|boolean',
            'expires_at'  => 'nullable|date',
        ];
    }

    /**
     * Get custom messages for validator errors.
     *
     * @return array
     */
    public function messages(): array
    {
        return [
            'code.string'        => 'El código debe ser una cadena de texto.',
            'code.max'           => 'El código no puede tener más de 255 caracteres.',
            'description.string' => 'La descripción debe ser una cadena de texto.',
            'status.boolean'     => 'El estado debe ser verdadero o falso.',
            'expires_at.date'    => 'La fecha de expiración debe ser una fecha válida.',
        ];
    }
}
