<?php
namespace App\Http\Requests\Internship;

use Illuminate\Foundation\Http\FormRequest;

class StoreInternshipRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'start_date' => 'required|date',
            'end_date'   => 'nullable|date',
            'user_id'    => 'required|exists:users,id',
        ];
    }
}
