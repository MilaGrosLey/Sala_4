<?php
namespace App\Http\Requests\Internship;

use Illuminate\Foundation\Http\FormRequest;

class UpdateInternshipRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'start_date' => 'sometimes|date',
            'end_date'   => 'nullable|date',
            'user_id'    => 'sometimes|exists:users,id',
        ];
    }
}
