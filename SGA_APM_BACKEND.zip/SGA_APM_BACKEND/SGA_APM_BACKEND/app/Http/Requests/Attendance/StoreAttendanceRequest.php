<?php
namespace App\Http\Requests\Attendance;

use Illuminate\Foundation\Http\FormRequest;

class StoreAttendanceRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'workspace_id'    => 'required|exists:workspaces,id',
            'attendance_code' => 'required|string',
            'observation'     => 'nullable|string|max:500',
            'user_id'         => 'required|exists:users,id',
        ];
    }
}
