<?php
namespace App\Http\Requests\Attendance;

use Illuminate\Foundation\Http\FormRequest;

class CheckoutAttendanceRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'workspace_id'    => 'required|exists:workspaces,id',
            'attendance_code' => 'required|string',
            'user_id'         => 'required|exists:users,id',
        ];
    }
}
