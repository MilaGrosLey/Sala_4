<?php
namespace App\Http\Requests\Province;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class UpdateProvinceRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        $province = $this->route('province')->id ?? null;
        return [
            'name'      => [
                'required',
                Rule::unique('provinces', 'name')
                    ->ignore($province)
                    ->whereNull('deleted_at'),
            ],
            'region_id' => 'sometimes|exists:regions,id',
        ];
    }
}
