<?php
namespace App\Http\Requests\RegistrationCode;

use Illuminate\Foundation\Http\FormRequest;

class UpdateRegistrationCodeRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'code'       => 'sometimes|string|max:255',
            'is_used'    => 'sometimes|boolean',
            'expires_at' => 'nullable|date',
        ];
    }
}
