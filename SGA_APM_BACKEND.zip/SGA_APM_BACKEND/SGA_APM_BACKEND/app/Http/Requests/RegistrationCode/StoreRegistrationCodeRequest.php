<?php
namespace App\Http\Requests\RegistrationCode;

use Illuminate\Foundation\Http\FormRequest;

class StoreRegistrationCodeRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'code'       => 'required|string|max:255',
            'is_used'    => 'required|boolean',
            'expires_at' => 'nullable|date',
        ];
    }
}
