<?php
namespace App\Http\Requests\District;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class StoreDistrictRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'name'        => [
                'required',
                Rule::unique('districts', 'name')->whereNull('deleted_at'),
            ],
            'province_id' => 'required|exists:provinces,id',
        ];
    }
}
