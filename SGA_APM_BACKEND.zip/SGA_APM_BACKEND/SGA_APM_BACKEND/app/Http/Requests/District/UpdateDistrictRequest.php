<?php
namespace App\Http\Requests\District;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class UpdateDistrictRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        $district = $this->route('district')->id ?? null;
        return [
            'name'        => [
                'required',
                Rule::unique('districts', 'name')
                    ->ignore($district)
                    ->whereNull('deleted_at'),
            ],
            'province_id' => [
                'required',
                'exists:provinces,id',
            ],
        ];
    }
}
