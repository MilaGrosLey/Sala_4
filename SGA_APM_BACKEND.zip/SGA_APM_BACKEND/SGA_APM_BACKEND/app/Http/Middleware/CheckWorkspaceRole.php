<?php
namespace App\Http\Middleware;

use App\Models\Workspace;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class CheckWorkspaceRole
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next, string ...$roles): Response
    {
        $user = $request->user();

        $workspace = $request->workspace_id;

        if ($user->hasRole('admin') || $user->hasRole('coodinator')) {
            return $next($request);
        }

        if (! $workspace) {
            abort(400, 'El workspace_id es requerido.');
        }

        $workspace = Workspace::find($workspace);

        if (! $workspace) {
            abort(404, 'Workspace no encontrado.');
        }

        $userWorkspace = $workspace->users()
            ->where('user_id', $user->id)
            ->first();

        if (! $userWorkspace || ! in_array($userWorkspace->pivot->role, $roles)) {
            abort(403, 'No autorizado para esta acción en el workspace.');
        }

        return $next($request);
    }
}
