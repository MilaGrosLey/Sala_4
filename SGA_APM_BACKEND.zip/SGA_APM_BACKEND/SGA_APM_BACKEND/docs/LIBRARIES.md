# Librerías y Paquetes Utilizados

Este documento describe las principales dependencias y librerías usadas en el proyecto SGA_APM.

## 1. Laravel Framework
- **Descripción**: Framework PHP para desarrollo de aplicaciones web.
- **Versión**: 12.x
- **Uso**: Base de la aplicación, enrutamiento, ORM Eloquent, middleware, validación, colas, eventos.

## 2. Laravel Sanctum
- **Descripción**: Autenticación de tokens API.
- **Uso**: Gestión de tokens personales para usuarios autenticados.

## 3. Spatie Laravel Permission
- **Descripción**: Gestión de roles y permisos.
- **Uso**: Control de acceso granular (`can:resource.action` middleware en controladores).
 
## 4. Doctrine DBAL
- **Descripción**: Librería de abstracción de base de datos.
- **Versión**: ^4.2
- **Uso**: Soporta operaciones avanzadas en migraciones como renombrar columnas o cambiar tipos de datos.

## 5. League CSV
- **Descripción**: Manejo de archivos CSV.
- **Versión**: ^9.23
- **Uso**: Importación y exportación de datos en formato CSV.

## 6. guzzlehttp/guzzle
- **Descripción**: Cliente HTTP.
- **Uso**: Envío de mails y consumo de APIs externas.

## 7. laravel/ui o Breeze (según configuración)
- **Descripción**: Frontend scaffolding (si existe parte UI).
- **Uso**: Bootstrap de vistas de autenticación.

## 8. barryvdh/laravel-debugbar (opcional)
- **Descripción**: Barra de depuración en desarrollo.
- **Uso**: Depuración de consultas, vistas y rendimiento.

## 9. symfony/*
- **Descripción**: Componentes Symfony incluidos en Laravel.
- **Uso**: Console, HttpFoundation, Routing, Validator, Mail.

## 10. phpmailer/phpmailer (indirecto)
- **Descripción**: Cliente SMTP (dependencia de SwiftMailer en Laravel).
- **Uso**: Envío de correos.

## 11. fakerphp/faker
- **Descripción**: Generación de datos de prueba.
- **Uso**: Seeders y pruebas unitarias.

## 12. PHPUnit
- **Descripción**: Framework de pruebas para PHP.
- **Uso**: Tests unitarios e integrados (comando `php artisan test`).

---

Para ver la versión exacta de cada paquete, revisar el archivo `composer.json` y `composer.lock`.