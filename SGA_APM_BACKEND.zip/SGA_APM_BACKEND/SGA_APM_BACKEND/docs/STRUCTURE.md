# Estructura General del Proyecto SGA_APM

Este documento describe la organización de carpetas, convenciones y flujo de trabajo en el proyecto.

```
SGA_APM/
├── app/
│   ├── Enums/             # Enumeraciones del sistema (RoleEnum, WorkspaceRoleEnum)
│   ├── Exceptions/        # Excepciones personalizadas
│   │   └── Conflicts/     # Excepciones de conflictos (SoftDeletedConflictException)
│   ├── Helpers/           # Funciones helper personalizadas
│   ├── Http/
│   │   ├── Controllers/   # Controladores API y Auth
│   │   │   ├── Api/       # Controladores de recursos RESTful
│   │   │   └── Auth/      # Controladores de autenticación
│   │   ├── Middleware/    # Middlewares personalizados
│   │   ├── Requests/      # Form Request validations organizados por entidad
│   │   │   ├── Attendance/
│   │   │   ├── AttendanceCode/
│   │   │   ├── AttendanceStatus/
│   │   │   ├── Career/
│   │   │   ├── Country/
│   │   │   ├── District/
│   │   │   ├── DocumentType/
│   │   │   ├── EmailVerification/
│   │   │   ├── Internship/
│   │   │   ├── Province/
│   │   │   ├── RecurringJustification/
│   │   │   ├── Region/
│   │   │   ├── RegistrationCode/
│   │   │   ├── Skill/
│   │   │   ├── TechnicalArea/
│   │   │   ├── User/
│   │   │   ├── UserWorkspace/
│   │   │   ├── Workspace/
│   │   │   └── WorkspaceType/
│   │   └── Resources/     # API Resources organizados por entidad
│   │       ├── Attendance/
│   │       ├── AttendanceCode/
│   │       ├── AttendanceStatus/
│   │       ├── Career/
│   │       ├── Country/
│   │       ├── District/
│   │       ├── DocumentType/
│   │       ├── EmailVerification/
│   │       ├── Internship/
│   │       ├── Province/
│   │       ├── RecurringJustification/
│   │       ├── Region/
│   │       ├── RegistrationCode/
│   │       ├── Skill/
│   │       ├── TechnicalArea/
│   │       ├── User/
│   │       ├── UserWorkspace/
│   │       ├── Workspace/
│   │       └── WorkspaceType/
│   ├── Mail/              # Clases de correo electrónico
│   ├── Models/            # Modelos Eloquent
│   ├── Providers/         # Service Providers
│   └── Services/          # Lógica de negocio (Domain Services) organizados por entidad
│       ├── Attendance/
│       ├── AttendanceCode/
│       ├── AttendanceStatus/
│       ├── Career/
│       ├── Country/
│       ├── District/
│       ├── DocumentType/
│       ├── EmailVerification/
│       ├── Internship/
│       ├── Province/
│       ├── RecurringJustification/
│       ├── Region/
│       ├── RegistrationCode/
│       ├── Report/
│       ├── Skill/
│       ├── TechnicalArea/
│       ├── User/
│       ├── UserWorkspace/
│       ├── Workspace/
│       └── WorkspaceType/
├── bootstrap/             # Arranque de la aplicación
├── config/                # Configuraciones del sistema
├── database/
│   ├── factories/         # Fábricas de modelos para pruebas
│   ├── migrations/        # Migraciones de base de datos
│   └── seeders/           # Seeders de datos iniciales
├── docs/                  # Documentación interna (estructura, librerías, etc.)
├── public/                # Punto de entrada público (index.php)
│   └── csv/               # Archivos CSV para seeders
├── resources/             # Vistas, assets (JS/CSS), si hay frontend
│   ├── css/
│   ├── js/
│   └── views/
│       └── emails/        # Plantillas de correo electrónico
├── routes/
│   ├── api.php            # Rutas de API REST
│   ├── auth.php           # Rutas de autenticación
│   ├── console.php        # Rutas de comandos Artisan
│   └── web.php            # Rutas web (si existen vistas)
├── storage/               # Logs y archivos generados
├── tests/                 # Pruebas unitarias y de integración
│   ├── Feature/           # Pruebas de características
│   └── Unit/              # Pruebas unitarias
└── vendor/                # Dependencias Composer
```

## Arquitectura y Patrones

### **Separación de Responsabilidades**
- **Controladores**: Solo manejan requests, validaciones y respuestas HTTP
- **Servicios**: Contienen toda la lógica de negocio
- **Requests**: Validaciones específicas por entidad
- **Resources**: Formateo de respuestas API
- **Models**: Relaciones y configuración de Eloquent

### **Organización por Entidad**
Cada entidad del sistema tiene su propia estructura organizada:
```
Entity/
├── Controllers/           # app/Http/Controllers/Api/EntityController.php
├── Requests/             # app/Http/Requests/Entity/
│   ├── StoreEntityRequest.php
│   ├── UpdateEntityRequest.php
│   └── [Otros requests específicos]
├── Resources/            # app/Http/Resources/Entity/
│   └── EntityResource.php
├── Services/             # app/Services/Entity/EntityService.php
└── Models/               # app/Models/Entity.php
```

### **Patrones Implementados**
1. **Repository Pattern**: Los servicios actúan como repositorios
2. **Form Request Validation**: Validaciones centralizadas por entidad
3. **API Resources**: Formateo consistente de respuestas
4. **Soft Delete**: Manejo de eliminación lógica con restauración
5. **Conflict Resolution**: Manejo de conflictos con soft-deleted records
6. **Model Binding**: Resolución automática de modelos en rutas

## Convenciones y Flujo

### **Nomenclatura**
- **Controllers**: `EntityController` (singular, PascalCase)
- **Services**: `EntityService` (singular, PascalCase)
- **Requests**: `ActionEntityRequest` (verbo + entidad, PascalCase)
- **Resources**: `EntityResource` (singular, PascalCase)
- **Models**: `Entity` (singular, PascalCase)

### **Middleware y Permisos**
- **Autenticación**: `auth:sanctum`
- **Permisos**: `can:resource.action` (ej: `can:user.index`)
- **Roles de Workspace**: `workspace.role:leader,sub_leader`

### **Validaciones**
- **Store**: Validaciones para crear nuevos registros
- **Update**: Validaciones para actualizar registros existentes
- **Custom**: Validaciones específicas por funcionalidad

### **Respuestas API**
- **Success**: HTTP 200/201 con Resource formateado
- **Error**: HTTP 400/409/422 con mensajes en español (parcialmente traducidos)
- **Delete**: HTTP 204 (No Content)

## Desarrollo y Despliegue

### **Entorno Local**
- **Servidor**: `php artisan serve`
- **Testing**: Postman/Hoppscotch para probar endpoints
- **Database**: Migrations y seeders para datos de prueba

### **Entorno de Producción**
- **Servidor**: NGINX/Apache con PHP-FPM
- **Variables**: Configurar `.env` con credenciales de producción
- **Colas**: Supervisor para procesamiento en background
- **Logs**: Configurar rotación de logs

### **CI/CD (Opcional)**
- **GitHub Actions**: Tests automáticos en push
- **GitLab CI**: Pipeline de build y deploy
- **Tests**: Unit y Feature tests antes del deploy

---

_Este documento ayuda a nuevos desarrolladores a comprender rápidamente la estructura, patrones y buenas prácticas del proyecto SGA_APM._