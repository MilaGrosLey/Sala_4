# APM Inversiones - Sistema de Asistencia

Sistema web para la gestión de asistencia, proyectos y equipos en APM Inversiones. Permite controlar la asistencia de los miembros, gestionar proyectos, equipos y generar reportes detallados en PDF y Excel.

## 🚀 Características principales

- **Gestión de asistencia**: Registro y visualización de asistencias, ausencias, tardanzas y justificaciones.
- **Gestión de proyectos**: Alta, edición y visualización de proyectos y sus integrantes.
- **Gestión de empleados**: Administración de usuarios, roles y generación de códigos de invitación.
- **Dashboard**: Estadísticas visuales de desempeño y asistencia.
- **Reportes**: Exportación de reportes en PDF y Excel.
- **Autenticación y roles**: Registro, login, recuperación y cambio de contraseña, control de acceso por roles.

## 📁 Estructura del proyecto

- `src/features/` - Módulos principales (auth, dashboard, empleados, proyectos, reportes, etc.)
- `src/components/` - Componentes reutilizables (botones, tablas, modales, etc.)
- `src/services/` - Servicios de API, utilidades y configuración de Axios.
- `src/pages/SideBar/` - Navegación lateral y menú principal.
- `src/routes/` - Rutas protegidas y contexto de autenticación.
- `src/utils/` - Utilidades generales (localStorage, roles, etc.)
- `src/mock/` - Datos de ejemplo para desarrollo.

## 🛠️ Instalación y ejecución

1. **Clona el repositorio:**
   ```bash
   git clone <REPO_URL>
   cd apm-inversiones-asistencia
   ```
2. **Instala las dependencias:**
   ```bash
   npm install
   ```
3. **Inicia el entorno de desarrollo:**
   ```bash
   npm run dev
   ```
4. **Accede a la app:**
   Abre [http://localhost:5173](http://localhost:5173) en tu navegador.

## ⚙️ Scripts útiles

- `npm run dev` - Inicia el servidor de desarrollo.
- `npm run build` - Genera la build de producción.
- `npm run preview` - Previsualiza la build.
- `npm run lint` - Linting de código.
- `npm run stylelint` - Linting de estilos.

## 👥 Roles y permisos

- **Admin**: Acceso total a todas las funcionalidades.
- **Member/Intern**: Acceso a gestión de proyectos, equipo y reportes.
- **User**: Acceso a su perfil y visualización de asistencia.

## 📚 Más documentación

- [docs/LIBRERIAS.md](docs/LIBRERIAS.md) - Librerías y dependencias.
- [docs/ESTRUCTURA.md](docs/ESTRUCTURA.md) - Estructura y arquitectura.
- [docs/DESARROLLO.md](docs/DESARROLLO.md) - Guía de desarrollo y buenas prácticas.

---
