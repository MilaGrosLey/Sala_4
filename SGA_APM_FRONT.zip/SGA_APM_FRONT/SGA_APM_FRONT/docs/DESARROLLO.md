# 👨‍💻 Guía de desarrollo y buenas prácticas

## Convenciones de código

- Usa siempre ESLint y Stylelint antes de hacer commit.
- Sigue la estructura de carpetas y componentes ya definida.
- Nombra los archivos y carpetas en inglés y en minúsculas/camelCase.
- Los componentes deben ser funcionales y usar hooks.
- Usa módulos CSS para estilos locales y evita estilos globales innecesarios.

## Agregar nuevas funcionalidades

1. Crea una carpeta en `src/features/` para el nuevo módulo.
2. Usa hooks para la lógica de negocio y servicios para la API.
3. Reutiliza componentes de `src/components/` siempre que sea posible.
4. Agrega rutas protegidas si es necesario en `src/routes/Router.jsx`.
5. Documenta el código y agrega comentarios claros.

## Pruebas y debug

- Usa los mocks de `src/mock/` para pruebas locales.
- Verifica la consola del navegador y las respuestas de la API.
- Usa las herramientas de React DevTools y Redux DevTools si es necesario.

## Contribuir y delegar

- Lee primero todos los README y la estructura del proyecto.
- Antes de empezar, pregunta al responsable del proyecto sobre el flujo de trabajo y tareas pendientes.
- Haz pull requests claros y bien documentados.
- Si delegas, explica la estructura, los hooks y los servicios principales.
- Mantén la comunicación y documenta cualquier cambio importante.

## Consejos adicionales

- Mantén el código limpio y modular.
- Usa variables de entorno para endpoints sensibles.
- Actualiza la documentación si cambias la estructura o agregas módulos.

---