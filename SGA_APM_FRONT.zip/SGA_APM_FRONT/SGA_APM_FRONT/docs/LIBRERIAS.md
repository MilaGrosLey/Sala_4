# 📦 Librerías y dependencias principales

Este proyecto utiliza un stack moderno de React con Vite y una serie de librerías para UI, manejo de datos y utilidades.

## Principales dependencias

- **React**: Librería principal para construir interfaces de usuario.
- **Vite**: Bundler ultrarrápido para desarrollo y build.
- **Ant Design (antd)**: Framework de componentes UI para React.
- **axios**: Cliente HTTP para consumir la API.
- **react-router**: Enrutamiento y navegación entre vistas.
- **react-toastify**: Notificaciones y alertas.
- **apexcharts / react-apexcharts**: Gráficas y visualizaciones en el dashboard.
- **jspdf / jspdf-autotable**: Generación de reportes PDF.
- **xlsx**: Exportación de reportes a Excel.
- **@phosphor-icons/react / lucide-react**: Iconografía moderna.
- **dayjs**: Manejo de fechas y horas.

## Dependencias de desarrollo

- **eslint, stylelint**: Linting de código y estilos.
- **@vitejs/plugin-react-swc**: Optimización de build para React.
- **@types/react, @types/react-dom**: Tipados para desarrollo.
- **@biomejs/biome**: Formateo y linting.

## ¿Para qué se usa cada una?

- **UI/UX**: antd, apexcharts, react-toastify, iconos.
- **Datos/API**: axios, dayjs, xlsx, jspdf.
- **Ruteo**: react-router.
- **Herramientas dev**: eslint, stylelint, biome, vite.

> Consulta el `package.json` para la lista completa y versiones.
