# 🏗️ Estructura y arquitectura del proyecto

## Estructura de carpetas

- **src/features/**: Módulos principales del sistema (auth, dashboard, empleados, proyectos, reportes, etc.).
- **src/components/**: Componentes reutilizables (botones, tablas, modales, stats, calendario, etc.).
- **src/services/**: Servicios de API, configuración de Axios, utilidades globales.
- **src/pages/SideBar/**: Navegación lateral y menú principal.
- **src/routes/**: Rutas protegidas, contexto de autenticación y roles.
- **src/utils/**: Utilidades generales (manejo de localStorage, roles, etc.).
- **src/mock/**: Datos de ejemplo para desarrollo y pruebas.

## Principales módulos/features

- **auth**: Login, registro, recuperación y cambio de contraseña, hooks y servicios de autenticación.
- **Dashboard**: Visualización de estadísticas, gráficas y métricas de asistencia y desempeño.
- **Employees**: Gestión de empleados, roles, invitaciones y administración de usuarios.
- **Projects**: Gestión de proyectos, alta, edición, visualización y asignación de integrantes.
- **Reports**: Generación y exportación de reportes en PDF y Excel.
- **Team**: Visualización y gestión de equipos de trabajo.
- **Profile**: Edición y visualización del perfil de usuario.

## Hooks y servicios reutilizables

- **Hooks**: Cada módulo tiene hooks propios para manejar lógica de negocio y estado (ej: `useAuth`, `useProjects`, `useEmployees`, `useStatistic`).
- **Servicios**: Abstracción de llamadas HTTP a la API usando Axios (`src/services/Axios/`).

## Flujo de autenticación y roles

- El login y registro se gestionan en `auth/services` y `auth/hooks`.
- El contexto de autenticación está en `src/routes/AuthContext.jsx`.
- Las rutas protegidas usan `ProtectedRoute.jsx` y controlan el acceso según el rol del usuario.

## Comunicación con la API

- Todas las llamadas HTTP usan Axios y están centralizadas en los servicios de cada módulo.
- La configuración base de Axios está en `src/services/Axios/baseConfig.js`.
- El token JWT se almacena en localStorage y se envía en los headers.

## Ejemplo de flujo de datos

1. El usuario inicia sesión (login) → se guarda el token y rol en localStorage.
2. Se accede a las rutas protegidas según el rol.
3. Los módulos (proyectos, empleados, etc.) consumen la API usando los hooks y servicios.
4. Los datos se muestran en componentes reutilizables (tablas, cards, stats, etc.).

---

> Para detalles de cada módulo, revisa los archivos y carpetas correspondientes en `src/features/`.
