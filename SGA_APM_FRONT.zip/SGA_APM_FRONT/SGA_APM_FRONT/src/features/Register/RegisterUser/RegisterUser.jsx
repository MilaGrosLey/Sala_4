import { ConfigProvider, Form, Input, Button, DatePicker, message } from 'antd';
import { UserOutlined, LockOutlined, MailOutlined } from '@ant-design/icons';
import Style from './RegisterUser.module.css';
import { useState } from 'react';
import { Link } from 'react-router';

const RegisterUsusario = () => {
  const [loading, setLoading] = useState(false);

  const onFinish = (values) => {
    setLoading(true);
    console.log('Received values:', values);
    // Simulate an API call
    setTimeout(() => {
      setLoading(false);
      message.success('Registro exitoso!');
    }, 2000);
  };

  const validateMessages = {
    required: 'Este campo es obligatorio!',
    types: {
      email: 'Por favor ingresa un correo válido!',
    },
  };

  return (
    <ConfigProvider
      theme={{
        components: {
          Input: {
            colorText: '#ffffff',
          },
          Button: {
            colorPrimary: '#52c41a',
          },
        },
      }}
    >
      <div className={Style.container}>
        <div className={Style.content}>
          <div className={Style.profile}>
            <div className={Style.title}>
              <p className={Style.titleText}>Registro</p>
            </div>
            <div className={Style.formContainer}>
              <Form
                name="register"
                onFinish={onFinish}
                className={Style.form}
                layout="vertical"
                validateMessages={validateMessages}
              >
                <Form.Item
                  className={Style.formItem}
                  name="nombre"
                  label={<span style={{ color: 'white' }}>Nombre</span>}
                  rules={[{ required: true }]}
                >
                  <Input
                    prefix={<UserOutlined className="site-form-item-icon" />}
                  />
                </Form.Item>
                <Form.Item
                  className={Style.formItem}
                  name="apellidoPaterno"
                  label={
                    <span style={{ color: 'white' }}>Apellido Paterno</span>
                  }
                  rules={[{ required: true }]}
                >
                  <Input
                    prefix={<UserOutlined className="site-form-item-icon" />}
                  />
                </Form.Item>
                <Form.Item
                  className={Style.formItem}
                  name="apellidoMaterno"
                  label={
                    <span style={{ color: 'white' }}>Apellido Materno</span>
                  }
                  rules={[{ required: true }]}
                >
                  <Input
                    prefix={<UserOutlined className="site-form-item-icon" />}
                  />
                </Form.Item>
                <Form.Item
                  className={Style.formItem}
                  name="email"
                  label={<span style={{ color: 'white' }}>Correo</span>}
                  rules={[{ required: true, type: 'email' }]}
                >
                  <Input
                    prefix={<MailOutlined className="site-form-item-icon" />}
                  />
                </Form.Item>
                <Form.Item
                  className={Style.formItem}
                  name="telefono"
                  label={<span style={{ color: 'white' }}>Teléfono</span>}
                  rules={[{ required: true }]}
                >
                  <Input />
                </Form.Item>

                <Form.Item
                  className={Style.formItem}
                  name="fechaNacimiento"
                  label={
                    <span style={{ color: 'white' }}>Fecha de Nacimiento</span>
                  }
                  rules={[{ required: true }]}
                >
                  <DatePicker style={{ width: '100%' }} />
                </Form.Item>
                <Form.Item
                  className={Style.formItem}
                  name="direccion"
                  label={<span style={{ color: 'white' }}>Dirección</span>}
                  rules={[{ required: true }]}
                >
                  <Input />
                </Form.Item>
                <Form.Item
                  className={Style.formItem}
                  name="password"
                  label={<span style={{ color: 'white' }}>Contraseña</span>}
                  rules={[{ required: true }]}
                >
                  <Input.Password
                    prefix={<LockOutlined className="site-form-item-icon" />}
                  />
                </Form.Item>
              </Form>
            </div>
            <Form.Item className={Style.submitButton}>
                <Link className={Style.cancelButton} to="/Inicio/gestionar-Usuarios">Cancelar </Link>
              <Button type="primary" htmlType="submit" loading={loading}>
                Registrarse
              </Button>
            </Form.Item>
          </div>
        </div>
      </div>
    </ConfigProvider>
  );
};

export default RegisterUsusario;
