import { get, post, put, del } from '../../../services/Axios/MethodsGeneral';

export const login = async (data) => {
  try {
    const response = await post('login', data);
    return response.data;
  } catch (error) {
    console.error('Login error:', error.message);
    throw error;
  }
};

export const register = async (data) => {
  try {
    const response = await post('users', data);
    return response.data;
  } catch (error) {
    console.error('Register error:', error);
    throw error;
  }
};

export const logOut = async () => {
  try {
    const response = await del('logout');
    return response.data;
  } catch (error) {
    console.error('Logout error:', error);
    throw error;
  }
};

export const changePassword = async (data) => {
  try {
    const response = await put('password/send-code', data);
    return response.data;
  } catch (error) {
    console.error('Change password error:', error);
    throw error;
  }
};
