import { Button, ConfigProvider, Form, Input, message } from 'antd';
import styles from './LoginForm.module.css';
import {
  EnvelopeIcon,
  PasswordIcon,
  EyeIcon,
  XCircleIcon,
  EyeSlashIcon,
} from '@phosphor-icons/react';
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router';
import { useAuth } from '../../hooks/authHook';
import { removeLocalStorage } from '../../../../utils/localStorage';

export default function LoginForm() {
  const [showPassword, setShowPassword] = useState(false);
  const [password, setPassword] = useState('');
  const [email, setEmail] = useState('');
  const { login, loading, error } = useAuth();

  const onSubmit = async () => {
    const credentials = { email, password };
    login(credentials);
  };

  const resetPassword = () => {
    setPassword('');
  };

  const resetEmail = () => {
    setEmail('');
  };

  useEffect(() => {
    removeLocalStorage('token');
  }, []);

  return (
    <ConfigProvider
      theme={{
        components: {
          Input: {
            colorBorder: 'transparent',
            activeBorderColor: 'transparent',
            hoverBorderColor: 'transparent',
            activeShadow: 'none',
            colorBgContainer: 'transparent',
          },
          Button: {
            defaultBg: '#c8a357',
            defaultHoverBg: '#a08651',
            defaultHoverColor: '#ffffff',
            defaultActiveBg: '#c8a357',
            defaultActiveColor: '#ffffff',
          },
        },
      }}
    >
      <>
        <Form name="login" onFinish={onSubmit}>
          <Form.Item
            name="email"
            rules={[{ required: true, message: 'Ingrese su correo' }]}
          >
            <div className={styles.input}>
              <EnvelopeIcon className={styles.iconFirst} />
              <Input
                type="email"
                placeholder="Correo"
                className={styles.inputText}
                onChange={(e) => setEmail(e.target.value)}
                value={email}
              />
              <XCircleIcon className={styles.icon} onClick={resetEmail} />
            </div>
          </Form.Item>
          <Form.Item
            name="password"
            rules={[{ required: true, message: 'Ingrese su contraseña' }]}
          >
            <div className={styles.input}>
              <PasswordIcon className={styles.iconFirst} />
              <Input
                type={showPassword ? 'text' : 'password'}
                placeholder="Contraseña"
                className={styles.inputText}
                onChange={(e) => setPassword(e.target.value)}
                value={password}
              />
              {showPassword ? (
                <EyeIcon
                  className={styles.icon}
                  onClick={() => setShowPassword(!showPassword)}
                />
              ) : (
                <EyeSlashIcon
                  className={styles.icon}
                  onClick={() => setShowPassword(!showPassword)}
                />
              )}
              <XCircleIcon className={styles.icon} onClick={resetPassword} />
            </div>
          </Form.Item>

          <Form.Item>
            <Button
              className={styles.button}
              block
              htmlType="submit"
              loading={loading}
            >
              Ingresar
            </Button>
          </Form.Item>
        </Form>
      </>
    </ConfigProvider>
  );
}
