import { Button, ConfigProvider, Form, Input, InputNumber } from 'antd';
import styles from './RegisterForm.module.css';
import {
  EnvelopeIcon,
  EyeIcon,
  EyeSlashIcon,
  KeyIcon,
  PasswordIcon,
} from '@phosphor-icons/react';
import { useState } from 'react';
import { useAuth } from '../../../hooks/authHook';

export default function RegisterForm() {
  const [showPassword, setShowPassword] = useState(false);
  const [password, setPassword] = useState('');
  const { register, loading, error } = useAuth();
  const onSubmit = (values) => {
    console.log(values);
    register(values);
  };

  return (
    <ConfigProvider
      theme={{
        components: {
          Input: {
            colorBorder: 'transparent',
            activeBorderColor: 'transparent',
            hoverBorderColor: 'transparent',
            activeShadow: 'none',
            colorBgContainer: 'transparent',
          },
          Button: {
            defaultBg: '#c8a357',
            defaultHoverBg: '#a08651',
            defaultHoverColor: '#ffffff',
            defaultActiveBg: '#c8a357',
            defaultActiveColor: '#ffffff',
          },
          InputNumber: {
            handleWidth: 0,
            colorBorder: 'transparent',
            activeBorderColor: 'transparent',
            hoverBorderColor: 'transparent',
            activeShadow: 'none',
            colorBgContainer: 'transparent',
            inputBg: 'transparent',
          },
        },
      }}
    >
      <>
        <Form name="registerForm" onFinish={onSubmit}>
          <Form.Item
            name="email"
            rules={[
              { required: true, message: 'Por favor Ingrese su correo!' },
            ]}
          >
            <div className={styles.containerInput}>
              <div>
                <EnvelopeIcon className={styles.iconFirst} />
              </div>
              <Input
                type="email"
                placeholder="Correo"
                className={styles.inputText}
              />
            </div>
          </Form.Item>
          <Form.Item
            name="password"
            rules={[{ required: true, message: 'Ingrese su contraseña' }]}
          >
            <div className={styles.input}>
              <PasswordIcon className={styles.iconFirst} />
              <Input
                type={showPassword ? 'text' : 'password'}
                placeholder="Contraseña"
                className={styles.inputText}
                onChange={(e) => setPassword(e.target.value)}
                value={password}
              />
              {showPassword ? (
                <EyeIcon
                  className={styles.icon}
                  onClick={() => setShowPassword(!showPassword)}
                />
              ) : (
                <EyeSlashIcon
                  className={styles.icon}
                  onClick={() => setShowPassword(!showPassword)}
                />
              )}
            </div>
          </Form.Item>
          <Form.Item
            name="registration_code"
            rules={[
              {
                required: true,
                max: 10,
                message: 'Por favor Ingrese el codigo de invitacion!',
              },
            ]}
          >
            <div className={styles.containerInput}>
              <div>
                <KeyIcon className={styles.iconFirst} />
              </div>
              <Input
                type="text"
                maxLength={10}
                placeholder="Codigo de invitacion"
                className={styles.inputText}
                style={{ width: '100%' }}
                controls={false}
              />
            </div>
          </Form.Item>
          <Form.Item>
            <Button
              className={styles.button}
              block
              htmlType="submit"
              loading={loading}
            >
              Confirmar
            </Button>
          </Form.Item>
        </Form>
      </>
    </ConfigProvider>
  );
}
