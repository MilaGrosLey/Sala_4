import { Button, ConfigProvider, Form, Input } from 'antd';
import styles from './FormChangePassword.module.css';
import { EnvelopeIcon, KeyIcon } from '@phosphor-icons/react';

export default function FormChangePassword() {
  const onSubmit = (values) => {
    console.log(values);
  };

  return (
    <ConfigProvider
      theme={{
        components: {
          Input: {
            colorBorder: 'transparent',
            activeBorderColor: 'transparent',
            hoverBorderColor: 'transparent',
            activeShadow: 'none',
            colorBgContainer: 'transparent',
          },
          Button: {
            defaultBg: '#c8a357',
            defaultHoverBg: '#a08651',
            defaultHoverColor: '#ffffff',
            defaultActiveBg: '#c8a357',
            defaultActiveColor: '#ffffff',
          },
        },
      }}
    >
      <>
        <Form name="changePassword" onFinish={onSubmit}>
          <Form.Item
            name="password"
            rules={[
              { required: true, message: 'Por favor Ingrese su contraseña!' },
            ]}
          >
            <div className={styles.containerInput}>
              <div>
                <KeyIcon className={styles.iconFirst} />
              </div>
              <Input
                type="password"
                placeholder="Ingrese su contraseña"
                className={styles.inputText}
              />
            </div>
          </Form.Item>
          <Form.Item
            name="passwordConfirm"
            dependencies={['password']}
            rules={[
              {
                required: true,
                message: 'Por favor confirma tu contraseña!',
              },
              ({ getFieldValue }) => ({
                validator(_, value) {
                  if (!value || getFieldValue('password') === value) {
                    return Promise.resolve();
                  }
                  return Promise.reject(
                    new Error('Las contraseñas no coinciden !'),
                  );
                },
              }),
            ]}
          >
            <div className={styles.containerInput}>
              <div>
                <KeyIcon className={styles.iconFirst} />
              </div>
              <Input
                type="password"
                placeholder="Repita su contraseña"
                className={styles.inputText}
              />
            </div>
          </Form.Item>
          <Form.Item>
            <Button className={styles.button} block htmlType="submit">
              Confirmar
            </Button>
          </Form.Item>
        </Form>
      </>
    </ConfigProvider>
  );
}
