import { useTheme } from '../../../../hooks/useTheme';
import styles from './ForgotPassword.module.css';
import { MoonIcon, SunIcon } from '@phosphor-icons/react';
import BackgroundShapes from '../../../../services/Particles/BackgroundShapes';
import { useEffect, useState } from 'react';
import FormForgotPassword from './FormForgotPassword/FormForgotPassword';
import { Link } from 'react-router';

export default function ForgotPassword() {
  const [mounted, setMounted] = useState(false);
  const { theme, switchTheme } = useTheme();

  useEffect(() => {
    setMounted(true);
    return () => setMounted(false);
  }, []);

  const icon =
    theme === 'light' ? (
      <SunIcon className={styles.iconTheme} onClick={switchTheme} />
    ) : (
      <MoonIcon className={styles.iconTheme} onClick={switchTheme} />
    );

  return (
    <div className={styles.container}>
      <BackgroundShapes />
      <div className={styles.header}>
        <div className={styles.icon}>{icon}</div>
      </div>
      <div
        className={`${styles.loginContainer} ${mounted ? styles.containerAnimation : ''}`}
      >
        <div className={styles.content}>
          <div className={styles.head}>
            <div
              className={`${styles.logo} ${mounted ? styles.logoAnimation : ''}`}
            >
              <img
                src="/lgoApmInversiones.webp"
                alt="Logo APM Inversiones"
                width="180"
                height="180"
              />
            </div>
            <div
              className={`${styles.title} ${mounted ? styles.titleAnimation : ''}`}
            >
              <h1 className={styles.title}>Recuperar contraseña</h1>
              <p
                className={`${styles.subtitle} ${mounted ? styles.subtitleAnimation : ''}`}
              >
                Ingresa tu correo para recibir instrucciones
              </p>
            </div>
          </div>
          <div
            className={`${styles.form} ${mounted ? styles.formAnimation : ''}`}
          >
            <FormForgotPassword />
          </div>
          <div className={styles.footerLinks}>
            <Link to="/" className={styles.link}>
              Regresar al inicio
            </Link>
          </div>
        </div>
      </div>
      <div className={styles.footer}>
        <p>© 2025 APM Inversiones. Todos los derechos reservados.</p>
      </div>
    </div>
  );
}
