import { Button, ConfigProvider, Form, Input, InputNumber } from 'antd';
import styles from './FormForgotPassword.module.css';
import { EnvelopeIcon, KeyIcon } from '@phosphor-icons/react';

export default function FormForgotPassword() {
  const onSubmit = (values) => {
    console.log(values);
  };

  return (
    <ConfigProvider
      theme={{
        components: {
          Input: {
            colorBorder: 'transparent',
            activeBorderColor: 'transparent',
            hoverBorderColor: 'transparent',
            activeShadow: 'none',
            colorBgContainer: 'transparent',
          },
          Button: {
            defaultBg: '#c8a357',
            defaultHoverBg: '#a08651',
            defaultHoverColor: '#ffffff',
            defaultActiveBg: '#c8a357',
            defaultActiveColor: '#ffffff',
          },
          InputNumber: {
            handleWidth: 0,
            colorBorder: 'transparent',
            activeBorderColor: 'transparent',
            hoverBorderColor: 'transparent',
            activeShadow: 'none',
            colorBgContainer: 'transparent',
            inputBg: 'transparent',
          },
        },
      }}
    >
      <>
        <Form name="forgotPassword" onFinish={onSubmit}>
          <Form.Item
            name="email"
            rules={[
              { required: true, message: 'Por favor Ingrese su correo!' },
            ]}
          >
            <div className={styles.containerInput}>
              <div>
                <EnvelopeIcon className={styles.iconFirst} />
              </div>
              <Input
                type="email"
                placeholder="Correo"
                className={styles.inputText}
              />
              <div>
                <button className={styles.btnSendCode} type="button">
                  Enviar Codigo
                </button>
              </div>
            </div>
          </Form.Item>
          <Form.Item
            name="code"
            rules={[
              {
                required: true,
                max: 6,
                message: 'Ingrese su codigo enviado al correo!',
              },
            ]}
          >
            <div className={styles.containerInput}>
              <div>
                <KeyIcon className={styles.iconFirst} />
              </div>
              <InputNumber
                type="number"
                placeholder="Codigo"
                maxLength={6}
                style={{ width: '100%' }}
                className={styles.inputText}
              />
            </div>
          </Form.Item>
          <Form.Item>
            <Button className={styles.button} block htmlType="submit">
              Confirmar
            </Button>
          </Form.Item>
        </Form>
      </>
    </ConfigProvider>
  );
}
