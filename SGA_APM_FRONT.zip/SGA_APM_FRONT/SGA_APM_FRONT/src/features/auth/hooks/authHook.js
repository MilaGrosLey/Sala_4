import { useNavigate } from 'react-router';
import { useToast } from '../../../services/Toastify/Toastify';
import {
  login as LoginService,
  logOut as logOutService,
  register as registerService,
  changePassword as changePasswordService,
} from '../services/authServices';
import { persistLocalStorage } from '../../../utils/localStorage';
import { useAuth as useAuthentication } from '../../../routes/AuthContext';
import { useState } from 'react';

export const useAuth = () => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const { showToast } = useToast();
  const { setIsAuthenticated, setUserRole } = useAuthentication();
  const navigate = useNavigate();

  const login = async (data) => {
    if (!data.email) {
      showToast('error', 'El campo de correo electrónico es obligatorio');
      return;
    }
    if (!data.password) {
      showToast('error', 'El campo de contraseña es obligatorio');
      return;
    }
    try {
      setLoading(true);
      const res = await LoginService(data);
      persistLocalStorage('token', res.access_token);
      persistLocalStorage('role', res.role);
      setIsAuthenticated(true);
      setUserRole(res.role);
      navigate('/Inicio');
      showToast('success', 'Inicio de sesión exitoso');
    } catch (error) {
      showToast(
        'error',
        error.response.data.message || 'Error al iniciar sesión',
      );
    } finally {
      setLoading(false);
    }
  };

  const logOut = async () => {
    try {
      setLoading(true);
      await logOutService();
      persistLocalStorage('token', '');
      setIsAuthenticated(false);
      setUserRole(null);
      showToast('success', 'Sesión cerrada exitosamente');
      navigate('/');
    } catch (error) {
      showToast(
        'error',
        error?.response?.data?.message || 'Error al cerrar sesión',
      );
    } finally {
      setLoading(false);
    }
  };

  const register = async (data) => {
    try {
      setLoading(true);
      const response = await registerService(data);
      showToast('success', 'Registro exitoso');
      navigate('/');
    } catch (error) {
      showToast('error', error?.response?.data?.message);
    } finally {
      setLoading(false);
    }
  };

  const changePassword = async (data) => {
    return null; // Implementación pendiente
  };

  return { login, logOut, register, changePassword, loading, error };
};
