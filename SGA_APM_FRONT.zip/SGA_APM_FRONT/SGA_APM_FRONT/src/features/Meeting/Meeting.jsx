import { ArrowsClockwiseIcon } from '@phosphor-icons/react';
import ButtonComponent from '../../components/Button/Button';
import styles from './Meeting.module.css';
import CardPerson from '../../components/CardsPerson/CardPerson';
import { useState } from 'react';
import { getRole } from '../../utils/role';
import ModalInfoEmployees from '../../components/ModalInfoEmployees/ModalInfoEmployees';
export default function Meeting() {
  const [viewCode, setViewCode] = useState(false);
  const [modalOpen, setModalOpen] = useState(false);
  const role = getRole();
  const changeViewCode = () => {
    setViewCode(!viewCode);
  };

  const onClick = () => {
    console.log('click');
  };

  const openModalInfo = () => {
    setModalOpen(true);
  };

  return (
    <>
      <div className={styles.container}>
        <div className={styles.header}>
          <div className={styles.info}>
            <div className={styles.date}>
              <p>11:12:32</p>
            </div>
            <div className={styles.TimeMeeting}>
              <p>Entrada : 8:00 - Salida : 12:00</p>
            </div>
          </div>
          <div className={styles.title}>
            <p>ReflexoPeru</p>
          </div>
          <div className={styles.btn}>
            <div className={styles.code}>
              {viewCode ? <p>12345R</p> : <p>******</p>}
            </div>
            <ButtonComponent
              text="Ver Codigo"
              onClick={changeViewCode}
              background="#c8a357"
              hover="#947940"
            />
            {role !== 1 ? (
              <ButtonComponent
                text="Salida"
                onClick={() => {}}
                background="#b20000"
                hover="#930505"
                block={true}
              />
            ) : (
              ''
            )}
          </div>
        </div>
        <div className={styles.content}>
          <div className={styles.integrates}>
            <div className={styles.btnUpdate}>
              <button onClick={onClick}>
                <ArrowsClockwiseIcon weight="fill" color="#fff" size={30} />
                Actualizar
              </button>
            </div>
          </div>
          <div className={styles.cardsAllContainer}>
            <div className={styles.Cards}>
              <div className={styles.titleCards}>
                <p>Lideres</p>
              </div>
              <div className={styles.cardsContainer}>
                <CardPerson
                  attendanceStatus="present"
                  openClick={openModalInfo}
                  name={'María González'}
                  rol={'Project Manager'}
                />
                <CardPerson
                  attendanceStatus="present"
                  openClick={openModalInfo}
                  name={'Carlos Mendoza'}
                  rol={'Tech Lead'}
                />
                <CardPerson
                  attendanceStatus="late"
                  openClick={openModalInfo}
                  name={'Laura Fernández'}
                  rol={'Scrum Master'}
                />
                <CardPerson
                  attendanceStatus="present"
                  openClick={openModalInfo}
                  name={'Jorge Ramírez'}
                  rol={'Product Owner'}
                />
              </div>
            </div>
            <div className={styles.Cards}>
              <div className={styles.titleCards}>
                <p>Equipo</p>
              </div>
              <div className={styles.cardsContainer}>
                <CardPerson
                  attendanceStatus="absences"
                  openClick={openModalInfo}
                  name={'Pedro Sánchez'}
                  rol={'Desarrollador Frontend'}
                />
                <CardPerson
                  attendanceStatus="justify"
                  openClick={openModalInfo}
                  name={'Ana López'}
                  rol={'Diseñadora UX/UI'}
                />
                <CardPerson
                  attendanceStatus="late"
                  openClick={openModalInfo}
                  name={'Miguel Torres'}
                  rol={'Desarrollador Backend'}
                />
                <CardPerson
                  attendanceStatus="present"
                  openClick={openModalInfo}
                  name={'Sofía Castro'}
                  rol={'QA Tester'}
                />
                <CardPerson
                  attendanceStatus="absences"
                  openClick={openModalInfo}
                  name={'Daniel Jiménez'}
                  rol={'Desarrollador Fullstack'}
                />
                <CardPerson
                  attendanceStatus="late"
                  openClick={openModalInfo}
                  name={'Elena Ruiz'}
                  rol={'Analista de Datos'}
                />
                <CardPerson
                  attendanceStatus="late"
                  openClick={openModalInfo}
                  name={'Roberto Navarro'}
                  rol={'DevOps Engineer'}
                />
                <CardPerson
                  attendanceStatus="absences"
                  openClick={openModalInfo}
                  name={'Lucía Díaz'}
                  rol={'Technical Writer'}
                />
              </div>
            </div>
          </div>
        </div>
      </div>
      <ModalInfoEmployees
        modalOpen={modalOpen}
        onOk={() => setModalOpen(false)}
        onCancel={() => setModalOpen(false)}
      />
    </>
  );
}
