import { ConfigProvider, message } from 'antd';
import styles from './Profile.module.css';
import ProfileForm from './ProfileForm';
import { useState } from 'react';

export default function Profile() {
  const [loading, setLoading] = useState(false);

  return (
    <ConfigProvider
      theme={{
        token: {
          colorPrimary: '#19b12d',
          borderRadius: 6,
        },
      }}
    >
      <div className={styles.container}>
        <div className={styles.content}>
          <div className={styles.header}>
            <h1 className={styles.title}>Perfil de Usuario</h1>
            <p className={styles.subtitle}>Actualiza tu información personal</p>
          </div>
          <ProfileForm />
        </div>
      </div>
    </ConfigProvider>
  );
}
