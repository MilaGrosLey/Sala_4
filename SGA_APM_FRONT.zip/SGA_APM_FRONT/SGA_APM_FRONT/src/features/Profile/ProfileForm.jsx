import {
  Button,
  Cascader,
  ConfigProvider,
  DatePicker,
  Form,
  Input,
  InputNumber,
  Select,
  Upload,
  message,
  Avatar,
} from 'antd';
import { LoadingOutlined, PlusOutlined, UserOutlined } from '@ant-design/icons';
import ImgCrop from 'antd-img-crop';
import styles from './ProfileForm.module.css';
import { useState } from 'react';

const { Option } = Select;

export default function ProfileForm() {
  const [form] = Form.useForm();
  const [loading, setLoading] = useState(false);
  const [imageUrl, setImageUrl] = useState();
  const [uploadLoading, setUploadLoading] = useState(false);

  const options = [
    {
      value: 'lima',
      label: 'Lima',
      children: [
        {
          value: 'lima_province',
          label: 'Lima Province',
          children: [
            {
              value: 'miraflores',
              label: 'Miraflores',
            },
            {
              value: 'barranco',
              label: 'Barranco',
            },
          ],
        },
      ],
    },
    {
      value: 'arequipa',
      label: 'Arequipa',
      children: [
        {
          value: 'arequipa_province',
          label: 'Arequipa Province',
          children: [
            {
              value: 'yanahuara',
              label: 'Yanahuara',
            },
            {
              value: 'cayma',
              label: 'Cayma',
            },
          ],
        },
      ],
    },
  ];

  const beforeUpload = (file) => {
    const isJpgOrPng = file.type === 'image/jpeg' || file.type === 'image/png';
    if (!isJpgOrPng) {
      message.error('Solo se permiten archivos JPG y PNG!');
      return false;
    }
    const isLt2M = file.size / 1024 / 1024 < 2;
    if (!isLt2M) {
      message.error('La imagen debe pesar menos de 2MB!');
      return false;
    }
    return true;
  };

  const handleChange = (info) => {
    if (info.file.status === 'uploading') {
      setUploadLoading(true);
      return;
    }
    if (info.file.status === 'done') {
      // Get this url from response in real world
      getBase64(info.file.originFileObj, (url) => {
        setUploadLoading(false);
        setImageUrl(url);
      });
    }
  };

  const getBase64 = (img, callback) => {
    const reader = new FileReader();
    reader.addEventListener('load', () => callback(reader.result));
    reader.readAsDataURL(img);
  };

  const uploadButton = (
    <div>
      {uploadLoading ? <LoadingOutlined /> : <PlusOutlined />}
      <div style={{ marginTop: 8 }}>Subir foto</div>
    </div>
  );

  const onFinish = async (values) => {
    setLoading(true);
    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1500));
      console.log('Profile updated:', values);
      message.success('Perfil actualizado exitosamente!');
    } catch (error) {
      message.error('Error al actualizar el perfil');
    } finally {
      setLoading(false);
    }
  };

  return (
    <ConfigProvider
      theme={{
        components: {
          Form: {
            labelColor: '#ffffff',
          },
          Input: {
            colorBgContainer: '#3d3e42',
            colorBorder: '#5a5b60',
            colorText: '#ffffff',
            colorTextPlaceholder: '#a0a0a0',
            hoverBorderColor: '#19b12d',
            activeBorderColor: '#19b12d',
          },
          Button: {
            defaultBg: '#19b12d',
            defaultHoverBg: '#117d20',
            defaultHoverColor: '#ffffff',
            defaultActiveBg: '#117d20',
            defaultActiveColor: '#ffffff',
          },
          Upload: {
            colorText: '#ffffff',
            controlHeightLG: 55,
          },
          Select: {
            colorBgContainer: '#3d3e42',
            colorBorder: '#5a5b60',
            colorText: '#ffffff',
            colorTextSecondary: '#a0a0a0',
            colorTextPlaceholder: '#a0a0a0',
            colorBgTextHover: '#19b12d',
            colorBgTextActive: '#19b12d',
            colorPrimary: '#19b12d',
            optionActiveBg: '#333231',
            colorBgElevated: '#3d3e42',
            optionSelectedBg: '#50525b',
            colorTextQuaternary: '#a0a0a0',
            activeBorderColor: '#19b12d',
          },
          InputNumber: {
            colorBgContainer: '#3d3e42',
            colorBorder: '#5a5b60',
            colorText: '#ffffff',
            colorTextPlaceholder: '#a0a0a0',
            handleWidth: 0,
          },
          DatePicker: {
            colorBgContainer: '#3d3e42',
            colorBorder: '#5a5b60',
            colorText: '#ffffff',
            colorTextPlaceholder: '#a0a0a0',
            colorBgElevated: '#3d3e42',
            colorPrimary: '#2f3035',
            colorTextHeading: '#ffffff',
            colorTextLabel: '#ffffff',
            colorIcon: '#ffffff',
            colorIconHover: '#19b12d',
            colorTextDisabled: '#a0a0a0',
            optionActiveBg: '#333231',
            cellHoverBg: '#333231',
          },
        },
      }}
    >
      <Form
        form={form}
        layout="vertical"
        onFinish={onFinish}
        className={styles.form}
      >
        <div className={styles.formContainer}>
          <div className={styles.photoSection}>
            <Form.Item>
              <ImgCrop rotationSlider>
                <Upload
                  name="avatar"
                  listType="picture-circle"
                  showUploadList={false}
                  beforeUpload={beforeUpload}
                  size="large"
                  onChange={handleChange}
                  customRequest={({ file, onSuccess }) => {
                    setTimeout(() => onSuccess('ok'), 0);
                  }}
                >
                  {imageUrl ? (
                    <Avatar src={imageUrl} size={100} icon={<UserOutlined />} />
                  ) : (
                    uploadButton
                  )}
                </Upload>
              </ImgCrop>
            </Form.Item>
          </div>

          <div className={styles.formInputContainers}>
            <div className={styles.formInputColumn}>
              <Form.Item
                name="documentType"
                label="Tipo de Documento"
                rules={[
                  {
                    required: true,
                    message: 'Seleccione un tipo de documento',
                  },
                ]}
              >
                <Select size="large" placeholder="Seleccione tipo">
                  <Option value="DNI">DNI</Option>
                  <Option value="RUC">RUC</Option>
                  <Option value="Other">Otro</Option>
                </Select>
              </Form.Item>

              <Form.Item
                name="lastName"
                label="Apellido Paterno"
                rules={[
                  { required: true, message: 'Ingrese su apellido paterno' },
                ]}
              >
                <Input size="large" placeholder="Ingrese su apellido paterno" />
              </Form.Item>

              <Form.Item
                name="email"
                label="Correo Electrónico"
                rules={[
                  {
                    type: 'email',
                    required: true,
                    message: 'Ingrese un correo válido',
                  },
                ]}
              >
                <Input
                  size="large"
                  placeholder="ejemplo@correo.com"
                  type="email"
                />
              </Form.Item>

              <Form.Item
                name="birthDate"
                label="Fecha de Nacimiento"
                rules={[{ required: true, message: 'Seleccione una fecha' }]}
              >
                <DatePicker
                  size="large"
                  style={{ width: '100%' }}
                  placeholder="Seleccione fecha"
                />
              </Form.Item>
            </div>

            <div className={styles.formInputColumn}>
              <Form.Item
                name="documentNumber"
                label="N° Documento"
                rules={[{ required: true, message: 'Ingrese un número' }]}
              >
                <InputNumber
                  size="large"
                  style={{ width: '100%' }}
                  placeholder="Ingrese su número"
                />
              </Form.Item>

              <Form.Item
                name="motherLastName"
                label="Apellido Materno"
                rules={[
                  { required: true, message: 'Ingrese su apellido materno' },
                ]}
              >
                <Input size="large" placeholder="Ingrese su apellido materno" />
              </Form.Item>

              <Form.Item
                name="phone"
                label="Teléfono"
                rules={[
                  {
                    required: true,
                    message: 'Ingrese su teléfono',
                    pattern: /^\d{9}$/,
                  },
                ]}
              >
                <InputNumber
                  size="large"
                  style={{ width: '100%' }}
                  placeholder="Ingrese su teléfono"
                  maxLength={9}
                />
              </Form.Item>

              <Form.Item
                name="practiceStart"
                label="Fecha Inicio Práctica"
                rules={[{ required: true }]}
              >
                <DatePicker
                  size="large"
                  style={{ width: '100%' }}
                  placeholder="Seleccione fecha"
                />
              </Form.Item>
            </div>

            <div className={styles.formInputColumn}>
              <Form.Item
                name="name"
                label="Nombres"
                rules={[{ required: true, message: 'Ingrese sus nombres' }]}
              >
                <Input size="large" placeholder="Ingrese sus nombres" />
              </Form.Item>

              <Form.Item
                name="gender"
                label="Género"
                rules={[{ required: true, message: 'Seleccione su género' }]}
              >
                <Select size="large" placeholder="Seleccione género">
                  <Option value="Masculino">Masculino</Option>
                  <Option value="Femenino">Femenino</Option>
                </Select>
              </Form.Item>

              <Form.Item
                name="practiceEnd"
                label="Fecha Fin Práctica"
                rules={[{ required: true }]}
              >
                <DatePicker
                  size="large"
                  style={{ width: '100%' }}
                  placeholder="Seleccione fecha"
                />
              </Form.Item>

              <Form.Item
                name="address"
                label="Dirección"
                rules={[{ required: true, message: 'Ingrese su dirección' }]}
              >
                <Input size="large" placeholder="Ingrese su dirección" />
              </Form.Item>
            </div>
          </div>

          <div className={styles.formFooter}>
            <Button
              type="primary"
              htmlType="submit"
              loading={loading}
              size="large"
              className={styles.submitButton}
            >
              Actualizar Perfil
            </Button>
          </div>
        </div>
      </Form>
    </ConfigProvider>
  );
}
