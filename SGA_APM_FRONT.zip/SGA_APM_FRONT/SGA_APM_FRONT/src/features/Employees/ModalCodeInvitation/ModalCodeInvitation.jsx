import { Avatar, ConfigProvider, Input, InputNumber, Modal } from 'antd';
import styles from './ModalCodeInvitation.module.css';
import { XCircleIcon } from '@phosphor-icons/react';
import ButtonComponent from '../../../components/Button/Button';
import { useEmployees } from '../Hook/employeesHook';

export default function ModalCodeInvitation({ modalOpen, onOk, onCancel }) {
  const { codeInvitation, generateEmployeeCodeInvitation } = useEmployees();

  return (
    <ConfigProvider
      theme={{
        components: {
          Modal: { contentBg: '#252525' },
          InputNumber: {
            handleWidth: 0,
            colorBgContainerDisabled: '#ffffff',
            colorTextDisabled: '#000000',
          },
          Input: {
            colorBgContainer: '#3d3e42',
            colorBorder: '#5a5b60',
            colorTextPlaceholder: '#a0a0a0',
            hoverBorderColor: '#19b12d',
            activeBorderColor: '#19b12d',
            fontSize: 16,
            colorTextDisabled: '#ffffff',
          },
        },
        token: {
          borderRadiusLG: 30,
        },
      }}
    >
      <>
        <Modal
          title={''}
          centered
          open={modalOpen}
          onOk={onOk}
          closeIcon={false}
          onCancel={onCancel}
          footer={null}
        >
          <div className={styles.container}>
            <div className={styles.title}>
              <p>Codigo de Invitacion</p>
            </div>
            <div className={styles.codeContainer}>
              <div className={styles.code}>
                <Input
                  value={codeInvitation}
                  style={{ width: '100%' }}
                  disabled={true}
                />
              </div>
              <div className={styles.btn}>
                <ButtonComponent
                  text="Generar"
                  background="#35B26E"
                  hover="#2E8B57"
                  onClick={generateEmployeeCodeInvitation}
                />
              </div>
            </div>
          </div>
        </Modal>
      </>
    </ConfigProvider>
  );
}
