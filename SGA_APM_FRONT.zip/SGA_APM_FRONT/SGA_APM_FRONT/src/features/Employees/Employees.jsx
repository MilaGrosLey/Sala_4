import TableComponent from '../../components/Table/Table';
import EmployeesMock from '../../mock/EmployeesMock';
import Ocupation from '../../mock/ocupationMock';
import { Space } from 'antd';
import ButtonComponent from '../../components/Button/Button';
import SearchBarComponent from '../../components/SearchBar/SearchBar';
import styles from './Employees.module.css';
import PaginationComponent from '../../components/Pagination/Pagination';
import { useEffect, useState } from 'react';
import ModalCodeInvitation from './ModalCodeInvitation/ModalCodeInvitation';
import { useEmployees } from './Hook/employeesHook';

export default function Employees() {
  const [modalOpen, setModalOpen] = useState(false);
  const ocupationMap = new Map(Ocupation.map((o) => [o.id, o.name]));
  const {
    employees,
    loading,
    listEmployees,
    error,
    generateEmployeeCodeInvitation,
  } = useEmployees();
  const [initialLoad, setInitialLoad] = useState(false);

  useEffect(() => {
    if (!initialLoad) {
      listEmployees();
      setInitialLoad(true);
    }
  }, [listEmployees]);
  
  const dataEmployees = employees.map((emp) => ({
    ...emp,
    ocupation_name: ocupationMap.get(emp.ocupation_id) || 'Frontend Developer',
    proyecto_name: emp.proyecto_id ? emp.proyecto_name : 'Reflexologia',
    name_full:
      `${emp.name || ''} ${emp.paternal_lastname || ''} ${emp.maternal_lastname || ''}`.trim(),
  }));

  const onClick = () => {
    console.log('click');
  };

  const openModalInfo = () => {
    setModalOpen(true);
  };
  const columns = [
    {
      title: 'Nombre',
      dataIndex: 'name_full',
      key: 'name_full',
      minWidth: 150,
    },
    {
      title: 'Correo',
      dataIndex: 'email',
      key: 'email',
      minWidth: 150,
    },
    {
      title: 'Proyecto',
      dataIndex: 'proyecto_name',
      key: 'proyecto_name',
      minWidth: 80,
      align: 'center',
    },
    {
      title: 'Cargo',
      dataIndex: 'ocupation_name',
      key: 'ocupation_id',
      minWidth: 80,
      align: 'center',
    },
    {
      title: 'Acciones',
      key: 'actions',
      align: 'center',
      render: () => (
        <Space size="middle">
          <ButtonComponent
            text="Mas Info"
            onClick={onSubmitInfo}
            background="#35B26E"
            hover="#2E8B57"
          />
          <ButtonComponent
            text="Editar"
            onClick={onSubmitEdit}
            background="#285cec"
            hover="#1b43b1"
          />
          <ButtonComponent
            text="Eliminar"
            onClick={onSubmitEdit}
            background="#b20000"
            hover="#930505"
          />
        </Space>
      ),
    },
  ];

  const onCreate = () => {};

  const onSubmitInfo = () => {};

  const onSubmitEdit = () => {};

  console.log('montando employees');
  return (
    <>
      <div className={styles.container}>
        <div className={styles.title}>
          <h1>Gestionar Empleados</h1>
        </div>
        <div className={styles.header}>
          <ButtonComponent
            text="Crear invitacion"
            onClick={openModalInfo}
            background="#35B26E"
            hover="#2E8B57"
          />
          <SearchBarComponent placeholder={'Buscador por nombre'} />
        </div>
        <div className={styles.table}>
          <TableComponent
            data={dataEmployees}
            loading={loading}
            columns={columns}
          />
        </div>
        <div className={styles.pagination}>
          <PaginationComponent />
        </div>
      </div>
      <ModalCodeInvitation
        modalOpen={modalOpen}
        onOk={() => setModalOpen(false)}
        onCancel={() => setModalOpen(false)}
      />
    </>
  );
}
