import { useNavigate } from 'react-router';
import { useToast } from '../../../services/Toastify/Toastify';
import { useEffect, useState } from 'react';
import {
  listEmployees as listEmployeesService,
  generateEmployeeCodeInvitation as generateEmployeeCodeInvitationService,
} from '../Services/employeesService';

export const useEmployees = () => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [codeInvitation, setCodeInvitation] = useState(null);
  const { showToast } = useToast();
  const [employees, setEmployees] = useState([]);

  const navigate = useNavigate();

  const listEmployees = async () => {
    try {
      setLoading(true);
      const res = await listEmployeesService();
      setEmployees(res);
      showToast('success', 'Empleados listados correctamente');
    } catch (error) {
      showToast(
        'error',
        error.response?.data?.message || 'Error al listar empleados',
      );
      setError(error);
    } finally {
      setLoading(false);
    }
  };

  const generateEmployeeCodeInvitation = async () => {
    try {
      setLoading(true);
      const res = await generateEmployeeCodeInvitationService();
      setCodeInvitation(res.code);
      showToast('success', 'Código de invitación generado correctamente');
    } catch (error) {
      showToast(
        'error',
        error.response?.data?.message ||
          'Error al generar código de invitación',
      );
      setError(error);
    } finally {
      setLoading(false);
    }
  };

  return {
    loading,
    error,
    employees,
    generateEmployeeCodeInvitation,
    listEmployees,
    codeInvitation,
  };
};
