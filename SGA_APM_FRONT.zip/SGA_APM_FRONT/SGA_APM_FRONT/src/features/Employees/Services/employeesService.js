import { get, post, put, del } from '../../../services/Axios/MethodsGeneral';

export const generateEmployeeCodeInvitation = async () => {
  try {
    const response = await post('registration-codes/generate');
    return response.data;
  } catch (error) {
    console.error('Error generating employee code invitation:', error);
    throw error;
  }
};

export const listEmployees = async () => {
  try {
    const response = await get('users');
    return response.data;
  } catch (error) {
    console.error('Error listing employees:', error);
    throw error;
  }
};