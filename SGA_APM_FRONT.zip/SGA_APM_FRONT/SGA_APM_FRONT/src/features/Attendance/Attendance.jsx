import { useNavigate } from 'react-router';
import CalendarioAsistencias from '../../components/CalendarAttendance/CalendarAttendance';
import CardProjects from '../../components/CardProjects/CardProjects';
import InputCode from '../../components/InputCode/InputCode';
import Stats from '../../components/Stats/Stats';
import styles from './Attendance.module.css';
import { getRole } from '../../utils/role';

import { useToast } from '../../services/Toastify/Toastify';
export default function Attendance() {
  const role = getRole();
  const navigate = useNavigate();
  const { showToast } = useToast();

  const onNavigate = (id) => () => {
    const urlActual = window.location.pathname;

    if (urlActual === '/Inicio/asistencia') {
      navigate(`${id}`);
    } else {
      navigate(`asistencia/${id}`);
    }
  };

  return (
    <div className={styles.container}>
      <div>
        <Stats />
      </div>
      <div
        className={`${styles.projectsContainer} ${role !== 1 ? styles.projectsContainerMargin : ''}`}
      >
        <div
          className={`${styles.projects} ${role !== 1 ? styles.projectsMargin : ''}`}
        >
          {role !== 1 ? (
            <div className={styles.InputCode}>
              <p>Ingresa el codigo de la reunion para marcar asistencia</p>
              <InputCode placeholder="Código de Reunión" onChange={() => {}} />
            </div>
          ) : null}
          <div className={styles.cardsContainer}>
            <CardProjects
              projectName="ReflexoPeru"
              justifieds="2"
              asistances="2"
              tardances="14"
              absences="2"
              onClick={onNavigate(1)}
            />
            {role === 1 ? (
              <CardProjects
                projectName="MarketingMedico"
                justifieds="0"
                asistances="2"
                tardances="12"
                absences="0"
                onClick={onNavigate(3)}
              />
            ) : null}
            {role === 1 ? (
              <CardProjects
                projectName="AgentesIA"
                justifieds="2"
                asistances="2"
                tardances="11"
                absences="2"
                onClick={onNavigate(4)}
              />
            ) : null}
            {role === 1 ? (
              <CardProjects
                projectName="MaquetacionWeb"
                justifieds="1"
                asistances="1"
                tardances="10"
                absences="1"
                onClick={onNavigate(5)}
              />
            ) : null}
            {role === 1 ? (
              <CardProjects
                projectName="Scrum Master"
                justifieds="0"
                asistances="0"
                tardances="9"
                absences="0"
                onClick={onNavigate(6)}
              />
            ) : null}
            {role === 1 ? (
              <CardProjects
                projectName="MemberSHIP"
                justifieds="2"
                asistances="2"
                tardances="8"
                absences="2"
                onClick={onNavigate(7)}
              />
            ) : null}
            {role === 1 ? (
              <CardProjects
                projectName="Automatizacion"
                justifieds="1"
                asistances="1"
                tardances="7"
                absences="1"
                onClick={onNavigate(8)}
              />
            ) : null}
          </div>
        </div>
        {role !== 1 ? (
          <div className={styles.calendar}>
            <CalendarioAsistencias
              width="10%"
              asistencias={[
                { fecha: '25/05/25', type: 'asistio' },
                { fecha: '27/05/25', type: 'justificado' },
                { fecha: '28/05/25', type: 'falto' },
                { fecha: '06/05/25', type: 'asistio' },
                { fecha: '07/05/25', type: 'asistio' },
                { fecha: '08/05/25', type: 'asistio' },
                { fecha: '09/05/25', type: 'asistio' },
                { fecha: '10/05/25', type: 'asistio' },
              ]}
            />
          </div>
        ) : null}
      </div>
    </div>
  );
}
