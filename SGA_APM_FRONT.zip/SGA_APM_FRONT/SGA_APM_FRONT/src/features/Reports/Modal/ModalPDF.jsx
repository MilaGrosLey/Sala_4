import { ConfigProvider, Modal, Spin, Alert } from 'antd';
import Logo from '/Logo.jpg';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { useEffect, useState } from 'react';
import ButtonComponent from '../../../components/Button/Button';

export default function ModalPDF({
  modalOpen,
  onCancel,
  columns = [],
  rows = [],
  reportName = 'Reporte',
  autoGenerate = true,
}) {
  const [pdfUrl, setPdfUrl] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const [pdfDoc, setPdfDoc] = useState(null);

  const generatePDF = async (download = false) => {
    setIsLoading(true);
    setError(null);
    try {
      const doc = new jsPDF();
      doc.addImage(Logo, 'JPEG', 10, 10, 40, 40);
      doc.setFontSize(18);
      doc.text('APM INVERSIONES E.I.R.L', 80, 30);
      doc.setFontSize(12);
      doc.text(`Reporte de ${reportName}`, 10, 60);

      if (columns.length > 0 && rows.length > 0) {
        const data = rows.map((row) => columns.map((col) => row[col] || ''));
        autoTable(doc, {
          startY: 70,
          head: [columns],
          body: data,
          styles: {
            cellPadding: 5,
            fontSize: 11,
            valign: 'middle',
            halign: 'center',
            font: 'Helvetica',
          },
          headStyles: {
            fillColor: [41, 128, 185],
            textColor: 255,
            fontStyle: 'bold',
            fontSize: 11,
            cellPadding: 5,
          },
          alternateRowStyles: {
            fillColor: [245, 245, 245],
          },
          margin: { horizontal: 10 },
          tableWidth: 'auto',
          rowPageBreak: 'avoid',
        });
      } else {
        doc.text('No hay datos disponibles', 10, 70);
      }
      setPdfDoc(doc);

      const pdfBlob = doc.output('blob');
      const url = URL.createObjectURL(pdfBlob);
      setPdfUrl(url);

      if (download) {
        doc.save(`${reportName}-${new Date().toISOString().slice(0, 10)}.pdf`);
      }

      return doc;
    } catch (error) {
      setError(error);
      console.error('Error generating PDF:', error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (modalOpen && autoGenerate) {
      generatePDF(false).catch(console.error);
    }
  }, [modalOpen, autoGenerate]);

  useEffect(() => {
    return () => {
      if (pdfUrl) {
        URL.revokeObjectURL(pdfUrl);
      }
    };
  }, [pdfUrl]);

  const handleCancel = () => {
    setPdfUrl(null);
    setError(null);
    onCancel();
  };

  return (
    <ConfigProvider
      theme={{
        components: {
          Modal: {
            contentBg: '#2f3035',
            headerBg: '#2f3035',
            titleColor: '#ffffff',
          },
        },
        token: {
          borderRadiusLG: 10,
          colorBgElevated: '#2f3035',
        },
      }}
    >
      <Modal
        title={`Vista previa del reporte: ${reportName}`}
        centered
        open={modalOpen}
        onCancel={handleCancel}
        width="90%"
        style={{ top: 20 }}
        styles={{
          body: {
            height: 'calc(100vh - 200px)',
            padding: 0,
            overflow: 'hidden',
          },
        }}
        destroyOnHidden
        footer={[
          <ButtonComponent
            key="close"
            onClick={handleCancel}
            background="#c8a357"
            hover="#aa8949"
            text="Cerrar"
            style={{ marginRight: 8 }}
          />,
          pdfUrl && (
            <ButtonComponent
              key="download"
              type="primary"
              onClick={() =>
                pdfDoc.save(
                  `${reportName}-${new Date().toISOString().slice(0, 10)}.pdf`,
                )
              }
              text="Descargar PDF"
              background="#285cec"
            />
          ),
        ]}
      >
        <div
          style={{
            display: 'flex',
            flexDirection: 'column',
            height: '100%',
            backgroundColor: '#f0f2f5',
            borderRadius: 4,
            overflow: 'hidden',
          }}
        >
          {error && (
            <Alert
              message="Error"
              description={`Ocurrió un error al generar el PDF: ${error.message}`}
              type="error"
              showIcon
              style={{ margin: 16 }}
            />
          )}

          {isLoading ? (
            <div
              style={{
                display: 'flex',
                justifyContent: 'center',
                alignItems: 'center',
                height: '100%',
              }}
            >
              <Spin size="large" tip="Generando PDF..." />
            </div>
          ) : pdfUrl ? (
            <iframe
              src={pdfUrl}
              width="100%"
              height="100%"
              title={`Vista previa - ${reportName}`}
              style={{ border: 'none' }}
            />
          ) : (
            <div
              style={{
                display: 'flex',
                justifyContent: 'center',
                alignItems: 'center',
                height: '100%',
                color: '#888',
              }}
            >
              No hay vista previa disponible
            </div>
          )}
        </div>
      </Modal>
    </ConfigProvider>
  );
}
