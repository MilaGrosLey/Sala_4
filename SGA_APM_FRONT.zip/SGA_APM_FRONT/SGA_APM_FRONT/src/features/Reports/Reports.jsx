import { ConfigProvider, DatePicker, Modal, Select } from 'antd';
import ButtonComponent from '../../components/Button/Button';
import styles from './Reports.module.css';
import EmployeesMock from '../../mock/EmployeesMock';
import { useState } from 'react';
import ProjectMock from '../../mock/ProjectsMock';
import ReportMock from '../../mock/ReportMock';
import dayjs from 'dayjs';
import { useNavigate } from 'react-router';
import { generateExcel } from './Excel/Template';
import ModalPDF from './Modal/ModalPDF';
import { ArrowLeft } from 'lucide-react';

const { RangePicker } = DatePicker;
export default function Reports() {
  const [selectedEmployee, setSelectedEmployee] = useState(false);
  const role = 1;
  const [selectedProject, setSelectedProject] = useState(false);

  const [dateRange, setDateRange] = useState([dayjs(), dayjs()]);
  const [selectedEmpId, setSelectedEmpId] = useState(null);
  const [selectedProjId, setSelectedProjId] = useState(null);
  const [modalOpen, setModalOpen] = useState(false);
  const [reportType, setReportType] = useState('1');
  const [pdfData, setPdfData] = useState({
    columns: [],
    rows: [],
    reportName: '',
  });

  const navigate = useNavigate();

  const handleDateChange = (dates, dateStrings) => {
    if (dates) {
      setDateRange(dates);
    } else {
      // Si el usuario borra las fechas, puedes manejarlo aquí
      // Por ejemplo, resetear a los valores por defecto
      setDateRange([dayjs().subtract(1, 'month'), dayjs()]);
    }
  };

  const onCancel = () => {
    navigate('/Inicio');
  };

  const options = [
    ...(role === 1
      ? [
          {
            value: '1',
            label: 'Horas y asistencias totales de todos los grupos',
          },
          {
            value: '2',
            label: 'Horas y asistencias totales de todos los miembros',
          },
        ]
      : []),
    {
      value: '3',
      label: 'Horas y asistencias totales de un grupo',
    },
    {
      value: '4',
      label: 'Horas y asistencias totales de un miembro',
    },
    {
      value: '5',
      label: 'Horas totales de un grupo/miembro',
    },
    {
      value: '6',
      label: 'Asistencias totales de un grupo/miembro',
    },
  ];

  const Employees = EmployeesMock.map((emp) => ({
    value: emp.id,
    label: `${emp.name} ${emp.paternal_lasname} ${emp.maternal_lastname}`,
  }));
  const Projects = ProjectMock.map((proj) => ({
    value: proj.id,
    label: proj.name,
  }));

  const preparePdfData = () => {
    let columns = [];
    let rows = [];
    let reportName = '';

    // Ejemplo básico - debes adaptar esto a tu lógica real
    switch (reportType) {
      case '1': // Reporte de todos los grupos
        columns = [
          'Proyecto',
          'Nombre y apellido',
          'Horas Totales',
          'Asistencias',
          'Faltas',
          'Tardanzas',
        ];
        rows = ReportMock.map((report) => ({
          Proyecto: report['Proyecto Nombre'],
          'Nombre y apellido': report['Nombre y apellido'],
          'Horas Totales': report['Horas Totales'],
          Asistencias: report.Asistencias,
          Faltas: report.Faltas,
          Tardanzas: report.Tardanzas,
        }));
        reportName =
          'Reporte de Asistencias y Horas Totales de los integrantes de todos los grupos';
        break;

      case '4': // Reporte de un miembro
        const employee = Employees.find((e) => e.value === selectedEmpId);
        columns = ['Fecha', 'Hora Entrada', 'Hora Salida', 'Horas Trabajadas'];
        rows = Array(10)
          .fill()
          .map((_, i) => ({
            Fecha: dayjs().subtract(i, 'day').format('DD/MM/YYYY'),
            'Hora Entrada': '08:00',
            'Hora Salida': '17:00',
            'Horas Trabajadas': '9',
          }));
        reportName = `Reporte de ${employee?.label || 'empleado'}`;
        break;

      // Agrega más casos según tus necesidades

      default:
        columns = ['Columna 1', 'Columna 2'];
        rows = [{ 'Columna 1': 'Dato 1', 'Columna 2': 'Dato 2' }];
        reportName = 'Reporte genérico';
    }

    // Filtrar por rango de fechas si es necesario
    if (dateRange && dateRange.length === 2) {
      // Aquí implementarías la lógica de filtrado por fecha
    }

    return { columns, rows, reportName };
  };

  const handleOpenModal = () => {
    const data = preparePdfData();
    setPdfData(data);
    setModalOpen(true);
  };
  const handleEmployeeChange = (value) => {
    setSelectedEmpId(value);
  };

  const handleProjectChange = (value) => {
    setSelectedProjId(value);
  };
  const handleReportTypeChange = (value) => {
    setReportType(value);
    setSelectedEmployee(['4', '5', '6'].includes(value));
    setSelectedProject(['3', '5', '6'].includes(value));
  };

  return (
    <ConfigProvider
      theme={{
        components: {
          Form: {
            labelColor: '#ffffff',
          },
          Input: {
            colorBgContainer: '#3d3e42',
            colorBorder: '#5a5b60',
            colorText: '#ffffff',
            colorTextPlaceholder: '#a0a0a0',
            hoverBorderColor: '#19b12d',
            activeBorderColor: '#19b12d',
            activeBorderColor: '#19b12d',
          },
          Button: {
            defaultBg: '#19b12d',
            defaultHoverBg: '#117d20',
            defaultHoverColor: '#ffffff',
            defaultActiveBg: '#117d20',
            defaultActiveColor: '#ffffff',
          },
          Upload: {
            colorText: '#ffffff',
            controlHeightLG: 55,
          },
          Select: {
            colorBgContainer: '#3d3e42',
            colorBorder: '#5a5b60',
            colorText: '#ffffff',
            hoverBorderColor: '#19b12d',
            colorTextSecondary: '#a0a0a0',
            colorTextPlaceholder: '#a0a0a0',
            colorBgTextHover: '#19b12d',
            colorBgTextActive: '#19b12d',
            colorPrimary: '#19b12d',
            colorBgElevated: '#3d3e42',
            optionSelectedBg: '#50525b',
            colorTextQuaternary: '#a0a0a0',
            activeBorderColor: '#19b12d',
            optionActiveBg: '#333231',
          },
          InputNumber: {
            colorBgContainer: '#3d3e42',
            colorBorder: '#5a5b60',
            colorText: '#ffffff',
            colorTextPlaceholder: '#a0a0a0',
            handleWidth: 0,
          },
          DatePicker: {
            colorBgContainer: '#3d3e42',
            colorBorder: '#5a5b60',
            colorText: '#ffffff',
            colorTextPlaceholder: '#a0a0a0',
            colorBgElevated: '#3d3e42',
            colorPrimary: '#2f3035',
            colorTextHeading: '#ffffff',
            colorTextLabel: '#ffffff',
            colorIcon: '#ffffff',
            colorIconHover: '#19b12d',
            colorTextDisabled: '#a0a0a0',
            activeBorderColor: '#19b12d',
            hoverBorderColor: '#19b12d',
            cellActiveWithRangeBg: '#117d20',
          },
        },
      }}
    >
      <div className={styles.container}>
        <div className={styles.header}>
          <button
            className={styles.backButton}
            onClick={onCancel}
            type="button"
          >
            <ArrowLeft /> Volver
          </button>
        </div>
        <div className={styles.content}>
          <div className={styles.form}>
            <div className={styles.title}>
              <h1>Tipos de Informes</h1>
            </div>
            <div className={styles.select}>
              <Select
                placeholder="Seleccione un Informe"
                onChange={handleReportTypeChange}
                options={options}
                style={{ width: '100%' }}
                defaultValue={options[0]}
              />
            </div>
            <div className={styles.datePicker}>
              {selectedEmployee && (
                <Select
                  placeholder="Seleccione un Empleado"
                  onChange={handleEmployeeChange}
                  options={Employees}
                  style={{ width: '100%' }}
                />
              )}
              {selectedProject && (
                <Select
                  placeholder="Seleccione un Proyecto"
                  onChange={handleProjectChange}
                  options={Projects}
                  style={{ width: '100%' }}
                />
              )}
              <RangePicker
                style={{ width: '100%' }}
                value={[dateRange[0], dateRange[1]]}
                onChange={handleDateChange}
              />
            </div>
            <div className={styles.button}>
              <ButtonComponent
                block={true}
                text="Descargar/Ver PDF"
                onClick={() => handleOpenModal()}
                background={'#8a1314'}
                hover={'#8a1314'}
              />
              <ButtonComponent
                block={true}
                text="Descargar Excel"
                onClick={() => generateExcel()}
                background={'#148d14'}
                hover={'#148d14'}
              />
            </div>
          </div>
        </div>
      </div>
      <ModalPDF
        modalOpen={modalOpen}
        columns={pdfData.columns}
        rows={pdfData.rows}
        reportName={pdfData.reportName}
        autoGenerate={true}
        onOk={() => setModalOpen(false)}
        onCancel={() => setModalOpen(false)}
      />
    </ConfigProvider>
  );
}
