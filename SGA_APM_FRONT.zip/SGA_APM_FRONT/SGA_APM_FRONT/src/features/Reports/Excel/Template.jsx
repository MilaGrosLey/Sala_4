import { read, utils, writeFileXLSX } from 'xlsx';

function generateExcel() {
  const rows = [
    {
      Proyecto: 'Proyecto 1',
      'Nombre y Apellido': 'Empleado 1',
      Asistencias: '10',
      Faltas: '2',
      Tardanzas: '1',
      'Horas Totales': '8',
    },
    {
      Proyecto: 'Proyecto 2',
      'Nombre y Apellido': 'Empleado 2',
      Asistencias: '9',
      Faltas: '3',
      Tardanzas: '2',
      'Horas Totales': '7',
    },
    {
      Proyecto: 'Proyecto 3',
      'Nombre y Apellido': 'Empleado 3',
      Asistencias: '8',
      Faltas: '4',
      Tardanzas: '3',
      'Horas Totales': '6',
    },
  ];

  const ws = utils.json_to_sheet(rows);

  const wb = utils.book_new();

  utils.book_append_sheet(wb, ws, 'Reporte');

  writeFileXLSX(wb, 'reporte.xlsx');
  console.log('sd');
}

export { generateExcel };
