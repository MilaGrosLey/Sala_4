// services/statisticService.js
import { mockData } from './mockData';

export const fetchStatisticData = async () => {
  try {
    // Simulate API call
    return mockData;
  } catch (error) {
    console.error('Error fetching data:', error);
    return mockData;
  }
};
