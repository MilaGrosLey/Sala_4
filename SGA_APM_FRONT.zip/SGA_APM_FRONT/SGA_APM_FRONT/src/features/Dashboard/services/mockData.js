// mock/mockData.js
export const mockData = {
  asistencias_por_dia: {
    1: 5,
    2: 4,
    3: 6,
    4: 5,
    5: 7,
    6: 6,
    7: 5,
    8: 4,
    9: 5,
    10: 6,
    11: 5,
    12: 7,
    13: 6,
    14: 5,
    15: 4,
    16: 6,
    17: 5,
    18: 7,
    19: 5,
    20: 6,
    21: 20,
    22: 6,
    23: 5,
    24: 7,
    25: 6,
    26: 5,
    27: 4,
    28: 6,
  },
  asistencias_por_mes: {
    a_tiempo: 120,
    tardanza: 25,
    falta: 10,
  },

  horas_por_mes: {
    horas: 60,
  },
  asistencias_equipo: {
    'Lucía Ramírez': {
      a_tiempo: 22,
      tardanza: 3,
      falta: 2,
    },
    'Carlos Méndez': {
      a_tiempo: 24,
      tardanza: 1,
      falta: 2,
    },
    'Valeria Torres': {
      a_tiempo: 18,
      tardanza: 5,
      falta: 3,
    },
    'Andrés Flores': {
      a_tiempo: 26,
      tardanza: 1,
      falta: 0,
    },
    'María Soto': {
      a_tiempo: 21,
      tardanza: 3,
      falta: 2,
    },
    'Diego Cabrera': {
      a_tiempo: 9,
      tardanza: 4,
      falta: 3,
    },
  },
};
