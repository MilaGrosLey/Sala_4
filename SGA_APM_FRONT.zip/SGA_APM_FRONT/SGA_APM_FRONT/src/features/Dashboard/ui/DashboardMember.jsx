import React, { useEffect, useRef, useState } from 'react';
import Chart from 'react-apexcharts';
import { ClockCircleOutlined, CheckCircleOutlined } from '@ant-design/icons';

import { ConfigProvider } from 'antd';
import { Clock, User as UserIcon } from '@phosphor-icons/react';
import Style from './DashboardMember.module.css';
import { useStatistic } from '../hook/Dashboardhook';
import {
  stackedBarChartOptions,
  areaChartOptions,
  pieChartOptions,
} from './ChartOptions';
import DashboardHeaderComponent from '../../../components/DashboardHeader/DashboardHeader';

export default function DashboardMember() {
  const {
    horastotales,
    asistenciasPorDia,
    asistenciasPorMes,
    asistenciasEquipo,
  } = useStatistic();

  const [chartDimensions, setChartDimensions] = useState({});
  const [rachaValue, setRachaValue] = useState(2);
  const chartRefs = useRef([]);

  useEffect(() => {
    const handleResize = () => {
      const newDimensions = {};
      chartRefs.current.forEach((ref, index) => {
        if (ref) {
          newDimensions[`chart-${index}`] = {
            width: ref.offsetWidth,
            height: ref.offsetHeight,
          };
        }
      });
      setChartDimensions(newDimensions);
    };

    handleResize();
    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  useEffect(() => {
    if (asistenciasPorDia.length > 0) {
      setRachaValue((prevValue) => {
        const newValue = prevValue + 1;
        return newValue > 20 ? 20 : newValue;
      });
    }
  }, [asistenciasPorDia]);

  const primerosNombres = asistenciasEquipo.map(
    (equipo) => equipo.name.split(' ')[0],
  );

  const updatedStackedBarChartOptions = {
    ...stackedBarChartOptions,
    xaxis: {
      ...stackedBarChartOptions.xaxis,
      categories: primerosNombres,
    },
  };

  const imageNumber = Math.min(Math.floor(rachaValue / 5) + 1, 5);

  return (
    <div className={Style.dashboardContainer}>
      <ConfigProvider
        theme={{
          token: {
            colorPrimary: '#00b96b',
            colorBgBase: '#2F3035',
            colorTextBase: '#f0f2f5',
          },
        }}
      >
        <div className={Style.dynamicContent}>
          
          <DashboardHeaderComponent title="Dashboard Member" />
              <div className={Style.contgraphs}>
            <div className={Style.contgraph}>
              <div className={Style.titlemetric}>
                <UserIcon weight="bold" />{' '}
                <h1>Asistencias del Equipo por Día</h1>
              </div>
              <div
                className={Style.graph}
                ref={(el) => (chartRefs.current[0] = el)}
                style={{ height: '85%' }}
              >
                <Chart
                  options={areaChartOptions}
                  series={[{ name: 'Asistencias', data: asistenciasPorDia }]}
                  type="area"
                  height={chartDimensions['chart-0']?.height || '50%'}
                  width={chartDimensions['chart-0']?.width || '100%'}
                />
              </div>
            </div>
          
          </div>
          <div className={Style.metricsContainer}>
         
              <div className={Style.contdonutgraph}>
              <div className={Style.titlemetric}>
                <UserIcon weight="bold" /> <h3>Asistencia del Mes</h3>
              </div>
              <div
                className={Style.graph}
                ref={(el) => (chartRefs.current[2] = el)}
                style={{ height: '100%' }}
              >
                <Chart
                  options={pieChartOptions}
                  series={asistenciasPorMes}
                  type="donut"
                  height="100%"
                  width="100%"
                />
              </div>
            </div>
               <div className={Style.conttreegraph}>
            
           
            <div className={Style.metriclarge}>
              <div className={Style.metricContent}>
                <div className={Style.metricInfolarge}>
                  <h1>REFLEXOPERU</h1>

                  <h1>LIDERES :</h1>
                  <h1>FRONT : ANGEL ABANTO - JEREMY VILLODAS</h1>
                  <h1>BACK: JERSON SAAVEDRA - ANGELA VEGASS</h1>
                </div>
              </div>
            </div>

            <div className={Style.contmetric}>
             <div className={Style.metric}>
              <div className={Style.titlemetrics}>
                <h1>RACHA DE ASISTENCIA:</h1>
              </div>
              <img
                src={`/Racha/fire_${imageNumber}.webp`}
                width={100}
                alt={`Fire ${imageNumber}`}
              />
              <h1>X{rachaValue}</h1>
            </div>
            
            <div className={Style.metric}>
              <div className={Style.metricContent}>
                <div className={Style.metricIcon}>
                  <ClockCircleOutlined />
                </div>
                <div className={Style.metricInfo}>
                  <p>60 H</p>
                  <p>Resumen de horas</p>
                </div>
              </div>
            </div>
            </div>
            </div>
          </div>
      
        </div>
      </ConfigProvider>
    </div>
  );
}
