// components/chartOptions.js

export const areaChartOptions = {
  chart: {
    type: 'area',
    toolbar: {
      show: false,
    },
    zoom: {
      enabled: false, // ❌ Desactiva el zoom
    },
  },

  dataLabels: {
    enabled: false,
  },

  showAlways: false,
  showForNullSeries: true,
  stroke: {
    curve: 'smooth',
  },
  tooltip: {
    theme: 'dark',
  },

  xaxis: {
    categories: Array.from({ length: 30 }, (_, i) => `${i + 1}`),
    labels: {
      style: {
        colors: '#ffffff', // Color de las etiquetas del eje X
      },
    },
  },
  yaxis: {
    labels: {
      style: {
        colors: '#ffffff', // Color de las etiquetas del eje Y
      },
    },
  },

  colors: ['#1DB954'],
  grid: {
    show: false,
  },
};

export const pieChartOptions = {
  chart: {
    type: 'donut',

    toolbar: {
      show: false,
    },
  },

  plotOptions: {
    pie: {
      donut: {
        size: '55%', // o 75%, 80%, etc.
      },
    },
  },
  stroke: {
    width: 0.5,
    colors: ['#00000066'],
  },

  labels: ['A Tiempo', 'Tardanza', 'Falta'],
  colors: ['#4CAF50', '#FFC107', '#F44336'],
  legend: {
    position: 'bottom',
    labels: {
      colors: '#ffffff', // Color del texto de la leyenda
    },
  },
  dataLabels: {
    enabled: false,
    fomater: (val) => `${val}`,
    style: {
      colors: ['#ffffff'], // Color de las etiquetas de datos
    },
  },
  responsive: [
    {
      breakpoint: 480,
      options: {
        chart: {
          width: 200,
        },
        legend: {
          position: 'bottom',
          labels: {
            colors: '#ffffff',
          },
        },
      },
    },
  ],
};

export const stackedBarChartOptions = {
  chart: {
    type: 'bar',
    stacked: true,
    toolbar: {
      show: false,
    },
  },
  tooltip: {
    theme: 'dark',
  },
  plotOptions: {
    bar: {
      horizontal: true,
      barHeight: '95%', // Ajusta la altura de las barras para que no ocupen todo el espacio
    },
  },
  dataLabels: {
    enabled: true,
    style: {
      colors: ['#ffffff'], // Color de las etiquetas de datos
    },
  },
  stroke: {
    width: 0.1,
    
    colors: ['#00000066'],
  },
  yaxis: {
    labels: {
      show: true,
      style: {
        colors: '#ffffff', // Color de las etiquetas del eje Y
      },
    },
  },
  xaxis: {
    labels: {
      show: false,
    },
    axisBorder: {
      show: false,
    },
    axisTicks: {
      show: false,
    },
  },
  fill: {
    colors: ['#4CAF50', '#FFC107', '#F44336', '#2196F3'],
  },
  legend: {
    labels: {
      colors: '#ffffff', // Color del texto de la leyenda
    },
  },
  grid: {
    show: false,
    row: {
      padding: 5 // ⬅️ Espacio entre las filas (barras horizontales)
    }
  },
};
