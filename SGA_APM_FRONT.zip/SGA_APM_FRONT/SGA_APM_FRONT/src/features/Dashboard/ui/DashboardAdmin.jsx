import React, { useEffect, useRef } from 'react';
import Chart from 'react-apexcharts';
import { ConfigProvider } from 'antd';
import { UserIcon } from '@phosphor-icons/react';
import Style from './DashboardAdmin.module.css';
import { useStatistic } from '../hook/Dashboardhook';
import { areaChartOptions, stackedBarChartOptions } from './ChartOptions';
import DashboardHeaderComponent from '../../../components/DashboardHeader/DashboardHeader';

export default function DashboardAdmin() {
  const { asistenciasPorDia, asistenciasEquipo } = useStatistic();
  const chartRefs = useRef([]);

  const primerosNombres = asistenciasEquipo.map(
    (equipo) => equipo.name.split(' ')[0],
  );

  const updatedStackedBarChartOptions = {
    ...stackedBarChartOptions,
    xaxis: {
      ...stackedBarChartOptions.xaxis,
      categories: primerosNombres,
    },
  };

  useEffect(() => {
    const handleResize = () => {
      chartRefs.current.forEach((ref) => {
        if (ref) {
          const chart = ref.chart;
          if (chart) {
            chart.updateOptions({
              chart: {
                height: '100%',
                width: '100%',
              },
            });
          }
        }
      });
    };

    handleResize();
    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  return (
    <div className={Style.dashboardContainer}>
      <ConfigProvider
        theme={{
          token: {
            colorPrimary: '#00b96b',
            colorBgBase: '#1e1f23',
            colorTextBase: '#f0f2f5',
          },
        }}
      >
        <div className={Style.dynamicContent}>
          <DashboardHeaderComponent title="Dashboard" />
          <div className={Style.groupone}>
            <div className={Style.contgraph}>
              <div className={Style.titlemetric}>
                <UserIcon weight="bold" />{' '}
                <h1>Asistencias del Equipo por Día</h1>
              </div>
              <div
                className={Style.graph}
                ref={(el) => (chartRefs.current[0] = { el, chart: el?.chart })}
              >
                <Chart
                  options={areaChartOptions}
                  series={[{ name: 'Asistencias', data: asistenciasPorDia }]}
                  type="area"
                  height="100%"
                  width="100%"
                />
              </div>
            </div>
            <div className={Style.conttwograph}>
              <div className={Style.contgraph}>
                <div className={Style.titlemetric}>
                  <UserIcon weight="bold" /> <h1>Asistencias del Equipo</h1>
                </div>
                <div
                  className={Style.graph}
                  ref={(el) =>
                    (chartRefs.current[1] = { el, chart: el?.chart })
                  }
                >
                  <Chart
                    options={updatedStackedBarChartOptions}
                    series={[
                      {
                        name: 'A Tiempo',
                        data: asistenciasEquipo.map((equipo) => equipo.data[0]),
                      },
                      {
                        name: 'Tardanza',
                        data: asistenciasEquipo.map((equipo) => equipo.data[1]),
                      },
                      {
                        name: 'Falta',
                        data: asistenciasEquipo.map((equipo) => equipo.data[2]),
                      },
                    ]}
                    type="bar"
                    height="100%"
                    width="100%"
                  />
                </div>
              </div>
              <div className={Style.contgraph}>
                <div className={Style.titlemetric}>
                  <UserIcon weight="bold" /> <h1>Asistencias del Equipo</h1>
                </div>
                <div
                  className={Style.graph}
                  ref={(el) =>
                    (chartRefs.current[2] = { el, chart: el?.chart })
                  }
                >
                  <Chart
                    options={updatedStackedBarChartOptions}
                    series={[
                      {
                        name: 'A Tiempo',
                        data: asistenciasEquipo.map((equipo) => equipo.data[0]),
                      },
                      {
                        name: 'Tardanza',
                        data: asistenciasEquipo.map((equipo) => equipo.data[1]),
                      },
                      {
                        name: 'Falta',
                        data: asistenciasEquipo.map((equipo) => equipo.data[2]),
                      },
                    ]}
                    type="bar"
                    height="100%"
                    width="100%"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </ConfigProvider>
    </div>
  );
}
