// DynamicDashboard.jsx
import { useAuth } from '../../../routes/AuthContext';
import Dashboard from './Dashboard';
import DashboardAdmin from './DashboardAdmin';
import DashboardMember from './DashboardMember';

export const DynamicDashboard = () => {
  const { userRole } = useAuth();

  switch (userRole) {
    case 'admin':
      return <DashboardAdmin />; // Admin Dashboard
    case 'intern':
      return <Dashboard />; // Lider Dashboard
    case 'user':
      return <DashboardMember />; // Member Dashboard
    default:
      return <Navigate to="/Inicio" />;
  }
};
