import React, { useEffect, useRef, useState } from 'react';
import { Menu, ConfigProvider } from 'antd';
import { ClockCircleOutlined, CheckCircleOutlined } from '@ant-design/icons';
import Chart from 'react-apexcharts';
import Style from './Dashboard.module.css';
import { useStatistic } from '../hook/Dashboardhook';
import DashboardHeaderComponent from '../../../components/DashboardHeader/DashboardHeader';
import {
  areaChartOptions,
  pieChartOptions,
  stackedBarChartOptions,
} from './ChartOptions';
import autoTable from 'jspdf-autotable';

export default function Dashboard() {
  const {
    horastotales,
    asistenciasPorDia,
    asistenciasPorMes,
    asistenciasEquipo,
  } = useStatistic();

  // Racha
  const [rachaValue, setRachaValue] = useState(2);
  const imageNumber = Math.min(Math.floor(rachaValue / 5) + 1, 5);

  const [chartDimensions, setChartDimensions] = useState({});
  const chartRefs = useRef([]);

  useEffect(() => {
    const handleResize = () => {
      const newDimensions = {};
      chartRefs.current.forEach((ref, index) => {
        if (ref) {
          newDimensions[`chart-${index}`] = {
            width: ref.offsetWidth,
            height: ref.offsetHeight,
          };
        }
      });
      setChartDimensions(newDimensions);
    };

    handleResize();
    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  const primerosNombres = asistenciasEquipo.map(
    (equipo) => equipo.name.split(' ')[0],
  );

  const updatedStackedBarChartOptions = {
    ...stackedBarChartOptions,
    xaxis: {
      ...stackedBarChartOptions.xaxis,
      categories: primerosNombres,
    },
  };
  return (
    <div className={Style.dashboardContainer}>
      <ConfigProvider
        theme={{
          token: {
            colorPrimary: '#00b96b',
            colorBgBase: '#2F3035',
            colorTextBase: '#f0f2f5',
          },
        }}
      >
        <DashboardHeaderComponent title="Dashboard" />
        <div className={Style.metricsContainer}>
          <div className={Style.metric}>
            <div className={Style.metricContent}>
              <div className={Style.metricIcon}>
                <ClockCircleOutlined />
              </div>
              <div className={Style.metricInfo}>
                <p>60 H</p>
                <p> Horas del equipo</p>
              </div>
            </div>
          </div>
          <div className={Style.metric}>
            <div className={Style.metricContent}>
              <div className={Style.metricIcon}>
                <ClockCircleOutlined />
              </div>
              <div className={Style.metricInfo}>
                <p>2.1 H</p>
                <p>Horas Individuales</p>
              </div>
            </div>
          </div>
          <div className={Style.metric}>
            <div className={Style.metricContent}>
              <div className={Style.metricIcon}>
                <ClockCircleOutlined />
              </div>
              <div className={Style.metricInfo}>
                <p>3</p>
                <p>Requiere atención</p>
              </div>
            </div>
          </div>
          <div className={Style.metric}>
            <div className={Style.metricContent}>
              <div className={Style.metricIcon}>
                <CheckCircleOutlined />
              </div>
              <div className={Style.metricInfo}>
                <p>92%</p>
                <p>A tiempo</p>
              </div>
            </div>
          </div>
        </div>

        <div className={Style.chartsContainer}>
          <div className={Style.chart}>
            <h3>Asistencias por Día</h3>
            <div
              className={Style.chartContent}
              ref={(el) => (chartRefs.current[0] = el)}
            >
              <Chart
                options={areaChartOptions}
                series={[{ name: 'Asistencias', data: asistenciasPorDia }]}
                type="area"
                height={chartDimensions['chart-0']?.height || '100%'}
                width={chartDimensions['chart-0']?.width || '100%'}
              />
            </div>
          </div>
          <div className={Style.chart}>
            <h3>Asistencia del Mes</h3>
            <div
              className={Style.graph}
              ref={(el) => (chartRefs.current[2] = el)}
              style={{ height: '100%' }}
            >
              <Chart
                options={pieChartOptions}
                series={asistenciasPorMes}
                type="donut"
                height={'100%'}
                width={'100%'}
              />
            </div>
          </div>
          <div className={Style.bigchart}>
            <h3>Rendimiento del Equipo</h3>
            <div
              className={Style.chartContent}
              ref={(el) => (chartRefs.current[1] = el)}
            >
              <Chart
                options={updatedStackedBarChartOptions}
                series={[
                  {
                    name: 'A Tiempo',
                    data: asistenciasEquipo.map((equipo) => equipo.data[0]),
                  },
                  {
                    name: 'Tardanza',
                    data: asistenciasEquipo.map((equipo) => equipo.data[1]),
                  },
                  {
                    name: 'Falta',
                    data: asistenciasEquipo.map((equipo) => equipo.data[2]),
                  },
                ]}
                type="bar"
                height={chartDimensions['chart-1']?.height || '180%'}
                width={chartDimensions['chart-1']?.width || '100%'}
              />
            </div>
          </div>

          <div className={Style.bigchart}>
            <div className={Style.bigmetrics}>
              <div className={Style.titlemetrics}>
                <h1>RACHA DE ASISTENCIA:</h1>
              </div>
              <img 
                className={Style.img}
                src={`/Racha/fire_${imageNumber}.webp`}
                width={autoTable}
                alt={`Fire ${imageNumber}`}
              />
              <h1>X{rachaValue}</h1>
            </div>
          </div>
        </div>
      </ConfigProvider>
    </div>
  );
}
