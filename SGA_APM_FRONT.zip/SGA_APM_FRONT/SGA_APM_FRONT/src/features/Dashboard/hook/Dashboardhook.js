// hooks/useStatistic.js
import { useState, useEffect } from 'react';
import { fetchStatisticData } from '../services/DashboardServices';

export const useStatistic = () => {
  const [asistenciasPorDia, setAsistenciasPorDia] = useState([]);
  const [asistenciasPorMes, setAsistenciasPorMes] = useState([]);
  const [horastotales, sethorastotales] = useState([]);
  const [asistenciasEquipo, setAsistenciasEquipo] = useState([]);

  const loadData = async () => {
    const data = await fetchStatisticData();

    setAsistenciasPorDia(Object.values(data.asistencias_por_dia));

    setAsistenciasPorMes([
      data.asistencias_por_mes.a_tiempo,
      data.asistencias_por_mes.tardanza,
      data.asistencias_por_mes.falta,
    ]);

    setAsistenciasEquipo(
      Object.keys(data.asistencias_equipo).map((nombre) => ({
        name: nombre,
        data: [
          data.asistencias_equipo[nombre].a_tiempo,
          data.asistencias_equipo[nombre].tardanza,
          data.asistencias_equipo[nombre].falta,
          data.asistencias_equipo[nombre].justificado,
        ],
      })),
    );

    sethorastotales(Object.values(data.horas_por_mes));
  };

  useEffect(() => {
    loadData();
  }, []);

  return {
    horastotales,
    asistenciasPorDia,
    asistenciasPorMes,
    asistenciasEquipo,
  };
};
