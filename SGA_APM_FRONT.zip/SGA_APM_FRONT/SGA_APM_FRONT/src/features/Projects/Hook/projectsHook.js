import { useNavigate } from 'react-router';
import { useToast } from '../../../services/Toastify/Toastify';
import { useState } from 'react';
import {
  listProjects as listProjectsService,
  createProject as createProjectService,
} from '../Services/projectsServices';

export const useProjects = () => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const { showToast } = useToast();
  const [projects, setProjects] = useState([]);
  const navigate = useNavigate();

  const listProjects = async () => {
    try{
        setLoading(true);
        const res = await listProjectsService();
        setProjects(res);
        showToast('success', 'Proyectos listados correctamente');
    } catch (error) {
        showToast('error', error.response?.data?.message || 'Error al listar proyectos');
        setError(error);
    } finally {
        setLoading(false);
    }
  };

  const createProject = async (data) => {
    try {
      setLoading(true);
      const res = await createProjectService(data);
      showToast('success', 'Proyecto creado correctamente');
      navigate('/Inicio/gestionar-projectos');
    } catch (error) {
      showToast('error', error.response?.data?.message || 'Error al crear proyecto');
      setError(error);
    } finally {
      setLoading(false);
    }
  };

  return { loading, error, projects, listProjects, createProject };
};
