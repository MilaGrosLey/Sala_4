import TableComponent from '../../components/Table/Table';
import ButtonComponent from '../../components/Button/Button';
import SearchBarComponent from '../../components/SearchBar/SearchBar';
import styles from './Projects.module.css';
import { Space } from 'antd';
import PaginationComponent from '../../components/Pagination/Pagination';
import ModalCodeInvitation from '../Employees/ModalCodeInvitation/ModalCodeInvitation';
import { useNavigate } from 'react-router';
import { useProjects } from './Hook/projectsHook';
import { useEffect, useState } from 'react';

export default function Projects() {
  const { projects, loading, listProjects, error } = useProjects();
  const [initialLoad, setInitialLoad] = useState(false);

  useEffect(() => {
    if (!initialLoad) {
      listProjects();
      setInitialLoad(true);
    }
  }, [listProjects]);

  const navigate = useNavigate();
  const onViewIntegrants = () => {};

  const onEdit = () => {};

  const onDelete = () => {};

  const onCreate = () => {
    navigate('registro');
  };

  const columns = [
    {
      title: 'Nombre',
      dataIndex: 'name',
      key: 'name',
      minWidth: 90,
    },
    {
      title: 'Descripcion',
      dataIndex: 'description',
      render: (text) => (text ? text : 'Sin descripción'),
      key: 'description',
      minWidth: 90,
    },
    {
      title: 'N° Integrantes',
      dataIndex: 'n_integrantes',
      key: 'n_integrantes',
      render: (text) => (text ? text : '0'),
      minWidth: 90,
      align: 'center',
    },
    {
      title: 'Acciones',
      key: 'actions',
      align: 'center',
      minWidth: 90,
      render: () => (
        <Space size="middle">
          <ButtonComponent
            text="Ver Integrantes"
            onClick={onViewIntegrants}
            background="#c8a357"
            hover="#aa8949"
          />
          <ButtonComponent
            text="Editar"
            onClick={onEdit}
            background="#285cec"
            hover="#1b43b1"
          />
          <ButtonComponent
            text="Eliminar"
            onClick={onDelete}
            background="#b20000"
            hover="#930505"
          />
        </Space>
      ),
    },
  ];

  return (
    <>
      <div className={styles.container}>
        <div className={styles.title}>
          <h1>Gestionar Proyectos</h1>
        </div>
        <div className={styles.header}>
          <ButtonComponent
            text="Crear Proyecto"
            onClick={onCreate}
            background="#35B26E"
            hover="#2E8B57"
          />

          <SearchBarComponent placeholder={'Buscar proyectos'} />
        </div>
        <div className={styles.table}>
          <TableComponent
            loading={loading}
            columns={columns}
            data={projects.data}
          />
        </div>
        <div className={styles.pagination}>
          <PaginationComponent />
        </div>
      </div>
    </>
  );
}
