import { get, post } from '../../../services/Axios/MethodsGeneral';

export const listProjects = async () => {
  try {
    const response = await get('teams');
    return response.data;
  } catch (error) {
    console.error('Error listing projects:', error);
    throw error;
  }
};

export const createProject = async (data) => {
  try {
    const response = await post('teams', data);
    return response.data;
  } catch (error) {
    console.error('Error creating project:', error);
    throw error;
  }
};
