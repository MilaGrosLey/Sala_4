import { ConfigProvider } from 'antd';
import styles from './RegisterProyect.module.css';
import RegisterProyectForm from './RegisterProyectForm';
import { useState } from 'react';

export default function RegisterProyect() {
  const [loading, setLoading] = useState(false);

  const onFinish = async (values) => {
    setLoading(true);
    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1500));
      console.log('Project registered:', values);
      message.success('Proyecto registrado exitosamente!');
      return true;
    } catch (error) {
      message.error('Error al registrar el proyecto');
      return false;
    } finally {
      setLoading(false);
    }
  };

  return (
    <ConfigProvider
      theme={{
        token: {
          colorPrimary: '#19b12d',
          borderRadius: 6,
        },
      }}
    >
      <div className={styles.container}>
        <div className={styles.content}>
          <RegisterProyectForm onFinish={onFinish} loading={loading} />
        </div>
      </div>
    </ConfigProvider>
  );
}
