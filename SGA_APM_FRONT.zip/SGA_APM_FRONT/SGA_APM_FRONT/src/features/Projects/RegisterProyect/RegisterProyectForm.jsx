import { Form, Input, Button, ConfigProvider, message } from 'antd';
import styles from './RegisterProyectForm.module.css';
import { Link } from 'react-router';

export default function RegisterProyectForm({ onFinish, loading }) {
  const validateMessages = {
    required: 'Este campo es obligatorio!',
    types: {
      email: 'Por favor ingresa un correo válido!',
    },
  };

  const handleSubmit = async (values) => {
    try {
      await onFinish(values);
      form.resetFields();
    } catch (error) {
      message.error('Error al registrar el proyecto');
    }
  };

  return (
    <ConfigProvider
      theme={{
        components: {
          Form: {
            labelColor: '#ffffff',
            fontSize: '1rem',
          },
          Button: {
            defaultBg: '#19b12d',
            defaultHoverBg: '#117d20',
            defaultHoverColor: '#ffffff',
            defaultActiveBg: '#117d20',
            defaultActiveColor: '#ffffff',
            colorBorder: 'transparent',
            defaultHoverBorderColor: 'transparent',
          },
          Input: {
            colorBgContainer: '#3d3e42',
            colorBorder: '#5a5b60',
            colorText: '#ffffff',
            colorTextPlaceholder: '#a0a0a0',
            hoverBorderColor: '#19b12d',
            activeBorderColor: '#19b12d',
          },
        },
      }}
    >
      <div className={styles.container}>
        <Form
          layout="vertical"
          onFinish={handleSubmit}
          validateMessages={validateMessages}
          className={styles.form}
          autoComplete="true"
        >
          <div className={styles.formContainer}>
            <div className={styles.formHeader}>
              <h2>Registrar Nuevo Proyecto</h2>
              <p>Complete los detalles del proyecto</p>
            </div>

            <div className={styles.formInputContainers}>
              <div className={styles.formInputGroup}>
                <Form.Item
                  name="nombre"
                  label="Nombre del Proyecto"
                  rules={[
                    {
                      required: true,
                      message: 'Por favor ingrese el nombre del proyecto',
                    },
                  ]}
                >
                  <Input placeholder="Ej: Sistema de Gestión" size="large" />
                </Form.Item>

                <Form.Item
                  name="descripcion"
                  label="Descripción"
                  rules={[
                    {
                      required: true,
                      message: 'Por favor ingrese una descripción',
                    },
                  ]}
                >
                  <Input.TextArea
                    placeholder="Describa el propósito del proyecto"
                    rows={4}
                    showCount
                    maxLength={500}
                  />
                </Form.Item>
              </div>
            </div>

            <div className={styles.formFooter}>
              <Link to="/Inicio/gestionar-projectos">
                <Button type="default" className={styles.cancelButton}>
                  Cancelar
                </Button>
              </Link>
              <Button
                type="primary"
                htmlType="submit"
                loading={loading}
                className={styles.submitButton}
              >
                Registrar Proyecto
              </Button>
            </div>
          </div>
        </Form>
      </div>
    </ConfigProvider>
  );
}
