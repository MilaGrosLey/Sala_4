import TableComponent from '../../components/Table/Table';
import ButtonComponent from '../../components/Button/Button';
import SearchBarComponent from '../../components/SearchBar/SearchBar';
import styles from './Team.module.css';
import { Space } from 'antd';
import PaginationComponent from '../../components/Pagination/Pagination';
import { useNavigate } from 'react-router';
import { useEffect, useState } from 'react';

export default function Team() {
  const navigate = useNavigate();
  const onEdit = () => {};
  const onDelete = () => {};

  const columns = [];

  return (
    <>
      <div className={styles.container}>
        <div className={styles.title}>
          <h1>Equipo</h1>
        </div>
        <div className={styles.header}>
          <SearchBarComponent placeholder="Buscar por nombre" />
        </div>
        <div className={styles.table}>
          <TableComponent columns={columns} loading={false} data={[]} />
        </div>
        <div className={styles.pagination}>
          <PaginationComponent />
        </div>
      </div>
    </>
  );
}
