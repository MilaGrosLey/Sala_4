import locate from 'antd/es/time-picker/locale/es_ES';

const PersonalConfigLocale = Object.assign(Object.assign({}, locate), {
  lang: Object.assign(Object.assign({}, locate.lang), {
    shortMonths: [
      'Ene',
      'Feb',
      'Mar',
      'Abr',
      'May',
      'Jun',
      'Jul',
      'Ago',
      'Sep',
      'Oct',
      'Nov',
      'Dic',
    ],
  }),
});

export default PersonalConfigLocale;
