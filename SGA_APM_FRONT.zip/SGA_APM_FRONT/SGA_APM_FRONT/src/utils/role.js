const role = 2;

export const getRole = () => role;
