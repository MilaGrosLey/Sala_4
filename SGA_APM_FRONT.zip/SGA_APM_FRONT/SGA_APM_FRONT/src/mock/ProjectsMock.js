const ProjectMock = [
  {
    id: 1,
    name: 'ReflexoPeru',
    description: 'Proyecto de desarrollo de aplicaciones para terapia física',
    n_integrantes: 22,
  },
  {
    id: 3,
    name: 'MarketingMedico',
    description:
      'Plataforma de marketing especializado para profesionales de la salud',
    n_integrantes: 22,
  },
  {
    id: 4,
    name: 'AgentesIA',
    description:
      'Desarrollo de agentes inteligentes para automatización de procesos',
    n_integrantes: 22,
  },
  {
    id: 5,
    name: 'MaquetacionWeb',
    description: 'Diseño y maquetación de interfaces web modernas',
    n_integrantes: 22,
  },
  {
    id: 6,
    name: 'Scrum Master',
    description: 'Herramientas para gestión ágil de proyectos',
    n_integrantes: 22,
  },
  {
    id: 7,
    name: 'MemberSHIP',
    description: 'Sistema de membresías y suscripciones online',
    n_integrantes: 22,
  },
  {
    id: 8,
    name: 'Automatizacion',
    description: 'Soluciones de automatización para PyMEs',
    n_integrantes: 22,
  },
];

export default ProjectMock;
