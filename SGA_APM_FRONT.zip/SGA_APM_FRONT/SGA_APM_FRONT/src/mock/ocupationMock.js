const Ocupation = [
  {
    id: 1,
    name: 'Backend',
  },
  {
    id: 2,
    name: 'Frontend',
  },
  {
    id: 3,
    name: 'Fullstack',
  },
];

export default Ocupation;
