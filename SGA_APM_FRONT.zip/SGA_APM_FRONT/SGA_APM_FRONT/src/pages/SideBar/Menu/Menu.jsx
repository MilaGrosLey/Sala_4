import {
  CalendarBlankIcon,
  ChartBarIcon,
  FileDocIcon,
  FolderSimplePlusIcon,
  UserCirclePlusIcon,
  UsersThreeIcon,
} from '@phosphor-icons/react';
import { ConfigProvider, Menu } from 'antd';
import { useState } from 'react';
import styles from './Menu.module.css';
import { Link } from 'react-router';

export default function MenuSideBar() {
  const role = 1;
  const [stateOpenKeys, setStateOpenKeys] = useState(['2', '23']);
  const items = [
    {
      key: '1',
      icon: <CalendarBlankIcon color="white" />,
      label: <Link to="asistencia">Asistencia</Link>,
    },
    {
      key: '2',
      icon: <ChartBarIcon color="white" />,
      label: <Link to="estadisticas">Estadisticas</Link>,
    },
    ...(role === 2 || role === 1
      ? [
          {
            key: '23',
            icon: <FileDocIcon color="white" />,
            label: <Link to="reportes">Reportes</Link>,
          },
        ]
      : []),
    ...(role === 1
      ? [
          {
            key: '3',
            icon: <UserCirclePlusIcon color="white" />,
            label: <Link to="gestionar-usuarios">Gest. Usuarios</Link>,
          },
          {
            key: '4',
            icon: <FolderSimplePlusIcon color="white" />,
            label: <Link to="gestionar-projectos">Gest. Projectos</Link>,
          },
        ]
      : []),
    ...(role === 2 || role === 1
      ? [
          {
            key: '5',
            icon: <UsersThreeIcon color="white" />,
            label: <Link to="gestionar-equipo">Gest. Equipo</Link>,
          },
        ]
      : []),
  ];
  const onOpenChange = (openKeys) => {
    const currentOpenKey = openKeys.find(
      (key) => stateOpenKeys.indexOf(key) === -1,
    );
    // open
    if (currentOpenKey !== undefined) {
      const repeatIndex = openKeys
        .filter((key) => key !== currentOpenKey)
        .findIndex((key) => levelKeys[key] === levelKeys[currentOpenKey]);
      setStateOpenKeys(
        openKeys
          // remove repeat key
          .filter((_, index) => index !== repeatIndex)
          // remove current level all child
          .filter((key) => levelKeys[key] <= levelKeys[currentOpenKey]),
      );
    } else {
      // close
      setStateOpenKeys(openKeys);
    }
  };
  const getLevelKeys = (items1) => {
    const key = {};
    const func = (items2, level = 1) => {
      items2.forEach((item) => {
        if (item.key) {
          key[item.key] = level;
        }
        if (item.children) {
          func(item.children, level + 1);
        }
      });
    };
    func(items1);
    return key;
  };
  const levelKeys = getLevelKeys(items);
  return (
    <ConfigProvider
      theme={{
        components: {
          Menu: {
            colorBgContainer: 'none',
            itemSelectedBg: 'transparent',
            itemSelectedColor: '#C8A357',
            itemHoverBg: '#C8A357',
            itemColor: '#ffffff',
            fontSize: 'clamp(1rem, 2.5vw, 1.15rem)',
            iconMarginInlineEnd: '8px',
            fontFamily: 'Arial, Helvetica, sans-serif',
            iconSize: '1.5rem',
            itemMarginBlock: '18px',
            itemMarginInline: '0px',
            itemActiveBg: '#947940',
          },
        },
      }}
    >
      <Menu
        mode="inline"
        defaultOpenKeys={[]}
        openKeys={stateOpenKeys}
        onOpenChange={onOpenChange}
        items={items}
        className={styles.menu}
      />
    </ConfigProvider>
  );
}
