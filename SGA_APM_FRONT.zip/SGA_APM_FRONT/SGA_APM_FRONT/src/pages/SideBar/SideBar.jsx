import { Avatar, Divider, Switch } from 'antd';
import MenuSideBar from './Menu/Menu';
import styles from './SideBar.module.css';
import { useState } from 'react';
import { useTheme } from '../../hooks/useTheme';
import { MoonIcon, SunIcon } from '@phosphor-icons/react';
import BtnLogOut from './BtnLogOut/BtnLogOut';
import { Link, Outlet } from 'react-router';
import { getLocalStorage } from '../../utils/localStorage';

export default function SideBar() {
  const { theme, switchTheme } = useTheme();
  const name = getLocalStorage('name') || 'Usuario Anónimo';

  return (
    <div className={styles.container}>
      <div className={styles.sidebar}>
        <div className={styles.header}>
          <Link to="/Inicio/perfil" className={styles.linkProfile}>
            <div className={styles.avatar}>
              <Avatar
                icon={<img src="/lgoApmInversiones.webp" />}
                className={styles.avatarImg}
              />
            </div>
            <div className={styles.name}>
              <p>{name}</p>
            </div>
          </Link>
        </div>
        <Divider className={styles.divider} />
        <div className={styles.menu}>
          <MenuSideBar />
        </div>
        <Divider className={styles.divider} />
        <div className={styles.footer}>
          <div className={styles.theme}>
            <SunIcon className={styles.iconTheme} />
            <Switch checked={theme === 'dark'} onChange={switchTheme} />
            <MoonIcon className={styles.iconTheme} />
          </div>
          <div className={styles.logout}>
            <BtnLogOut />
          </div>
        </div>
      </div>
      <div className={styles.content}>
        <Outlet />
      </div>
    </div>
  );
}
