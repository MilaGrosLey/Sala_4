import { removeLocalStorage } from '../../../utils/localStorage';
import styles from './BtnLogOut.module.css';
import { useNavigate } from 'react-router';

export default function BtnLogOut() {
  const navigate = useNavigate();
  const onSubmit = () => {
    removeLocalStorage('token');
    removeLocalStorage('name');
    removeLocalStorage('user_id');
    navigate('/');
  };
  return (
    <>
      <button className={styles.btnLogOut} onClick={onSubmit}>
        Cerrar Sesion
      </button>
    </>
  );
}
