import { useState } from 'react';
import { AuthProvider } from './routes/AuthContext';
import Router from './routes/Router';

function App() {
  return (
    <AuthProvider>
      <Router />
    </AuthProvider>
  );
}

export default App;
