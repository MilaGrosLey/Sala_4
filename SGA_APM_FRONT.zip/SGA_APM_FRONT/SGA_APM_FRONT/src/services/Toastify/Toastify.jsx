import React, { useState, useContext, createContext } from 'react';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const ToastContext = createContext();
const MAX_TOAST = 3;

export const ToastProvider = ({ children }) => {
  const [toastIds, setToastIds] = useState([]);

  const removeToastId = (id) => {
    setToastIds((prev) => prev.filter((toastId) => toastId !== id));
  };

  const showToast = (type = 'default', message = 'Mensaje') => {
    if (toastIds.length < MAX_TOAST) {
      const id = toastByType(type, message);
      setToastIds((prev) => [...prev, id]);
    } else {
      const idToReplace = toastIds[0];
      toast.update(idToReplace, {
        type: type,
        autoClose: 3000,
        onClose: () => removeToastId(idToReplace),
      });
      const newIds = [...toastIds.slice(1), idToReplace];
      setToastIds(newIds);
    }
  };

  const toastByType = (type, message) => {
    const id = toast((type, message), {
      type: type,
      autoClose: 3000,
      onClose: () => removeToastId(id),
    });
    return id;
  };

  return (
    <ToastContext.Provider value={{ showToast }}>
      {children}
      <ToastContainer
        position="top-right"
        autoClose={3000}
        limit={MAX_TOAST}
        closeOnClick
        pauseOnHover
        draggable
        theme="colored"
      />
    </ToastContext.Provider>
  );
};

export const useToast = () => {
  const context = useContext(ToastContext);
  if (!context) throw new Error('useToast debe usarse dentro de ToastProvider');
  return context;
};
