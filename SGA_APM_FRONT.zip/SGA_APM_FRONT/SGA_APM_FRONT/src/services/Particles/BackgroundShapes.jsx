import { useEffect, useState } from 'react';
import styles from './BackgroundShapes.module.css';

const particles = Array.from({ length: 30 }).map((_, i) => ({
  id: i,
  size: Math.random() * 10 + 5, // Partículas más grandes
  left: Math.random() * 100,
  top: Math.random() * 100,
  opacity: Math.random() * 0.7 + 0.3, // Más visibles
  duration: Math.random() * 8 + 5, // Animación más rápida
  delay: Math.random() * 3,
  movementX: (Math.random() * 200 - 100) * 2, // Mayor rango horizontal (duplicado)
  movementY: (Math.random() * 200 - 100) * 2, // Mayor rango vertical (duplicado)
  rotation: Math.random() * 360, // Rotación adicional
}));

export default function BackgroundShapes() {
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
    return () => setMounted(false);
  }, []);

  return (
    <div className={`${styles.background} ${mounted ? styles.animated : ''}`}>
      {particles.map((particle) => (
        <div
          key={particle.id}
          className={styles.particle}
          style={{
            '--size': `${particle.size}px`,
            '--left': `${particle.left}%`,
            '--top': `${particle.top}%`,
            '--opacity': particle.opacity,
            '--duration': `${particle.duration}s`,
            '--delay': `${particle.delay}s`,
            '--move-x': `${particle.movementX}px`,
            '--move-y': `${particle.movementY}px`,
            '--rotate': `${particle.rotation}deg`,
            '--glow': `${particle.size * 1.5}px`,
          }}
        />
      ))}
    </div>
  );
}
