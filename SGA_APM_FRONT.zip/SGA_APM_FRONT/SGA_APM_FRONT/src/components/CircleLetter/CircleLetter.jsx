// components/CircleLetterIcon.jsx
const CircleLetterIcon = ({
  letter,
  bgColor = '#ff4040',
  textColor = 'white',
  size = 16,
}) => (
  <svg
    width="100%"
    height="100%"
    viewBox="0 0 24 24"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    style={{
      backgroundColor: bgColor,
      borderRadius: '50%',
      padding: '2px',
    }}
  >
    <circle cx="12" cy="12" r="10" fill={bgColor} />
    <text
      x="12"
      y="16"
      textAnchor="middle"
      fill={textColor}
      fontSize="12"
      fontWeight="bold"
      fontFamily="Arial, sans-serif"
    >
      {letter}
    </text>
  </svg>
);

export default CircleLetterIcon;
