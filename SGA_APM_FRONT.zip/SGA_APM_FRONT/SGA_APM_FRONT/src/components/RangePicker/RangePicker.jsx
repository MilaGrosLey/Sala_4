import React from 'react';
import { DatePicker, ConfigProvider } from 'antd';

const { RangePicker } = DatePicker;

const DateRangePicker = ({ onDateChange }) => {
  const handleDateChange = (dates, dateStrings) => {
    onDateChange(dates, dateStrings);
  };

  return (
    <ConfigProvider
      theme={{
        token: {
          colorPrimary: '#006400',
        },
      }}
    >
      <RangePicker
        placeholder={['Inicio', 'Fin']}
        allowEmpty={[false, true]}
        onChange={handleDateChange}
        format="DD/MM/YYYY"
        style={{ margin: '0 auto' }}
      />
    </ConfigProvider>
  );
};

export default DateRangePicker;
