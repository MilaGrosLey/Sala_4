import { ConfigProvider, Pagination } from 'antd';
import styles from './Pagination.module.css';
export default function PaginationComponent() {
  return (
    <ConfigProvider
      theme={{
        components: {
          Pagination: {
            colorPrimary: '#ffffff',
            colorBgContainer: '#616161',
            colorText: '#ffffff',
            colorPrimaryHover: '#00000',
            itemActiveBg: '#313131',
            fontSize: 16,
            fontFamily: 'Arial',
          },
        },
      }}
    >
      <Pagination
        defaultCurrent={1}
        total={500}
        align="center"
        className={styles.pagination}
        showSizeChanger={false}
      />
    </ConfigProvider>
  );
}
