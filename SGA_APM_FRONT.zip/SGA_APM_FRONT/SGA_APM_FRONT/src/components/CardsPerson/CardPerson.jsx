import { Avatar } from 'antd';
import styles from './CardPerson.module.css';
import {
  CheckCircleIcon,
  ClockIcon,
  NotePencilIcon,
  XCircleIcon,
} from '@phosphor-icons/react';
import { useState } from 'react';

export default function CardPerson({
  attendanceStatus = 'absences',
  openClick,
  name,
  rol,
}) {
  const [status, setStatus] = useState(attendanceStatus);

  const changeAttendance = () => {
    if (status === 'present') {
      setStatus('late');
    }
    if (status === 'late') {
      setStatus('absences');
    }
    if (status === 'justify') {
      setStatus('present');
    }
    if (status === 'absences') {
      setStatus('justify');
    }
  };

  return (
    <>
      <div
        className={`${styles.card} ${status == 'absences' ? styles.cardAbsence : ''}`}
      >
        <div className={styles.person}>
          <div className={styles.avatar}>
            <Avatar
              icon={<img src="/lgoApmInversiones.webp" />}
              className={styles.avatarImg}
              size={46}
            />
          </div>
          <div className={styles.info}>
            <button className={styles.infoButton} onClick={openClick}>
              <div className={styles.name}>{name}</div>
              <div className={styles.rol}>{rol}</div>
            </button>
          </div>
        </div>
        <div className={styles.attendance}>
          <button onClick={changeAttendance}>
            {status === 'present' ? (
              <CheckCircleIcon weight="fill" color="#3bdd83" size={36} />
            ) : null}
            {status === 'late' ? (
              <ClockIcon weight="fill" color="#ffb95b" size={36} />
            ) : null}
            {status === 'justify' ? (
              <NotePencilIcon weight="fill" color="#8ec4ff" size={36} />
            ) : null}
            {status === 'absences' ? (
              <XCircleIcon weight="fill" color="#ff4040" size={36} />
            ) : null}
          </button>
        </div>
      </div>
    </>
  );
}
