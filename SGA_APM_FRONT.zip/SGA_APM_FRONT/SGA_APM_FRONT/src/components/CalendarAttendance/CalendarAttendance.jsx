import { DayPicker } from 'react-day-picker';
import 'react-day-picker/dist/style.css';
import styles from './CalendarAttendance.module.css';
import { es } from 'date-fns/locale';

export default function CalendarioAsistencias({ asistencias }) {
  // Convertir los datos de la API a un formato más manejable
  const fechasEstilizadas = asistencias.reduce((acc, item) => {
    const [day, month, year] = item.fecha.split('/');
    const date = new Date(`20${year}`, month - 1, day);
    acc[date.toISOString().split('T')[0]] = item.type;
    return acc;
  }, {});

  // Definir los estilos para cada tipo de asistencia
  const modifiers = {
    asistio: [],
    falto: [],
    justificado: [],
  };

  // Añadir las fechas a sus respectivos modificadores
  asistencias.forEach((item) => {
    const [day, month, year] = item.fecha.split('/');
    const date = new Date(`20${year}`, month - 1, day);
    modifiers[item.type].push(date);
  });

  // Estilos para los modificadores
  const modifiersStyles = {
    asistio: {
      color: 'white',
      backgroundColor: '#52c41a',
      borderRadius: '50%',
    },
    falto: {
      color: 'white',
      backgroundColor: '#ff4d4f',
      borderRadius: '50%',
    },
    justificado: {
      color: 'white',
      backgroundColor: '#1890ff',
      borderRadius: '50%',
    },
  };

  return (
    <div className={styles.container}>
      <DayPicker
        locale={es}
        modifiers={modifiers}
        modifiersStyles={modifiersStyles}
        className={styles.calendar}
        mode="disabled"
        navLayout="around"
        showOutsideDays
        animate
        fixedWeeks
        styles={{
          caption: { color: '#fff' },
          head_cell: { color: '#aaa' },
          day: { color: '#fff' },
          nav_button: { color: '#fff' },
        }}
      />
      <div className={styles.legend}>
        <div className={styles.legendItem}>
          <span className={`${styles.legendColor} ${styles.asistio}`}></span>
          <span>Asistió</span>
        </div>
        <div className={styles.legendItem}>
          <span
            className={`${styles.legendColor} ${styles.justificado}`}
          ></span>
          <span>Justificado</span>
        </div>
        <div className={styles.legendItem}>
          <span className={`${styles.legendColor} ${styles.falto}`}></span>
          <span>Faltó</span>
        </div>
      </div>
    </div>
  );
}
