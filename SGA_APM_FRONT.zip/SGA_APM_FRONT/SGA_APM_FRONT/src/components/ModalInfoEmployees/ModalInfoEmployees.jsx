import { Avatar, ConfigProvider, Modal } from 'antd';
import styles from './ModalInfoEmployees.module.css';
import { XCircleIcon } from '@phosphor-icons/react';
export default function ModalInfoEmployees({ modalOpen, onOk, onCancel }) {
  return (
    <ConfigProvider
      theme={{
        components: { Modal: { contentBg: '#252525' } },
        token: {
          borderRadiusLG: 30,
        },
      }}
    >
      <>
        <Modal
          title={''}
          centered
          open={modalOpen}
          onOk={onOk}
          closeIcon={false}
          onCancel={onCancel}
          footer={null}
        >
          <div className={styles.container}>
            <div className={styles.header}>
              <div className={styles.avatar}>
                <Avatar
                  icon={<img src="/lgoApmInversiones.webp" />}
                  className={styles.avatarImg}
                  size={46}
                />
              </div>
              <div className={styles.name}>
                <p>Luis Jeremy Villodas Almiron</p>
              </div>
              <div className={styles.close}>
                <button onClick={onCancel}>
                  <XCircleIcon weight="fill" color="#ff0000" size={32} />
                </button>
              </div>
            </div>
            <div className={styles.attendance}>
              <div className={styles.attendanceDates}>
                <div className={`${styles.absences} ${styles.attendanceDate}`}>
                  <div>
                    <p className={styles.textAttendance}>Faltas</p>
                  </div>
                  <div className={styles.dateNumber}>
                    <p>12</p>
                  </div>
                </div>
                <div
                  className={`${styles.asistances} ${styles.attendanceDate}`}
                >
                  <div>
                    <p className={styles.textAttendance}>Asistencias</p>
                  </div>
                  <div className={styles.dateNumber}>
                    <p>152</p>
                  </div>
                </div>

                <div className={`${styles.tardances} ${styles.attendanceDate}`}>
                  <div className={styles.textAttendance}>
                    <p>Tardanzas</p>
                  </div>
                  <div className={styles.dateNumber}>
                    <p>12</p>
                  </div>
                </div>
              </div>
              <div className={styles.DatesJustify}>
                <p>Dias Justificados: Martes , Jueves</p>
              </div>
            </div>
            <div className={styles.informationPractices}>
              <div>
                <p>Informacion</p>
                <p>Inicio de practicas: 12/12/2022</p>
                <p>Fin de practicas: 12/12/2022</p>
              </div>
            </div>
            <div className={styles.informationContact}>
              <div>
                <p>Informacion de contacto</p>
                <p>Telefono: 999999999</p>
                <p>Correo: 1Z2Q5@example.com</p>
              </div>
            </div>
          </div>
        </Modal>
      </>
    </ConfigProvider>
  );
}
