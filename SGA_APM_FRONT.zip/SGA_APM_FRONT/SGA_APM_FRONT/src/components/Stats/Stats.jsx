import { useState, useEffect } from 'react';
import styles from './Stats.module.css';
import dayjs from 'dayjs';
import { getRole } from '../../utils/role';
import {
  CheckCircleOutlined,
  ClockCircleOutlined,
  CloseCircleOutlined,
  CalendarOutlined,
} from '@ant-design/icons';
import { ConfigProvider } from 'antd';

export default function Stats() {
  const role = getRole();
  const [day, setDay] = useState(dayjs());
  const [animatedValues, setAnimatedValues] = useState({
    asistances: 0,
    tardances: 0,
    absences: 0,
  });

  useEffect(() => {
    const targetValues =
      role === 1
        ? { asistances: 128, tardances: 21, absences: 12 }
        : { asistances: 123, tardances: 12, absences: 12 };

    const duration = 1000;
    const startTime = Date.now();

    const animate = () => {
      const elapsed = Date.now() - startTime;
      const progress = Math.min(elapsed / duration, 1);

      setAnimatedValues({
        asistances: Math.floor(progress * targetValues.asistances),
        tardances: Math.floor(progress * targetValues.tardances),
        absences: Math.floor(progress * targetValues.absences),
      });

      if (progress < 1) {
        requestAnimationFrame(animate);
      }
    };

    animate();
  }, [role]);

  return (
    <ConfigProvider
      theme={{
        components: {
          Card: {
            colorBgContainer: '#1a1a1a',
            colorBorderSecondary: '#333',
          },
        },
      }}
    >
      <div className={styles.container}>
        <div className={styles.stats}>
          {/* Stat Asistencias */}
          <div className={`${styles.stat} ${styles.statAsistances}`}>
            <div className={styles.icon}>
              <CheckCircleOutlined />
            </div>
            <div className={styles.content}>
              <div className={styles.title}>
                <h3>
                  {role === 1
                    ? 'Promedio de Asistencias Diarias'
                    : 'Asistencias'}
                </h3>
              </div>
              <div className={styles.value}>
                <p>{animatedValues.asistances}</p>
              </div>
            </div>
          </div>

          {/* Stat Tardanzas */}
          <div className={`${styles.stat} ${styles.statTardances}`}>
            <div className={styles.icon}>
              <ClockCircleOutlined />
            </div>
            <div className={styles.content}>
              <div className={styles.title}>
                <h3>
                  {role === 1 ? 'Promedio de Tardanzas Diarias' : 'Tardanzas'}
                </h3>
              </div>
              <div className={styles.value}>
                <p>{animatedValues.tardances}</p>
              </div>
            </div>
          </div>

          {/* Stat Ausencias */}
          <div className={`${styles.stat} ${styles.statAbsences}`}>
            <div className={styles.icon}>
              <CloseCircleOutlined />
            </div>
            <div className={styles.content}>
              <div className={styles.title}>
                <h3>
                  {role === 1 ? 'Promedio de Ausencias Diarias' : 'Ausencias'}
                </h3>
              </div>
              <div className={styles.value}>
                <p>{animatedValues.absences}</p>
              </div>
            </div>
          </div>

          {/* Fecha */}
          <div className={`${styles.stat} ${styles.statDate}`}>
            <div className={styles.icon}>
              <CalendarOutlined />
            </div>
            <div className={styles.content}>
              <div className={styles.title}>
                <h3>Fecha Actual</h3>
              </div>
              <div className={styles.valueDate}>
                <p>{day.format('DD/MM/YYYY')}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </ConfigProvider>
  );
}
