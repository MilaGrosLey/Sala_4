import { ConfigProvider, Table } from 'antd';
import { useEffect, useRef, useState } from 'react';
import styles from './Table.module.css';

export default function TableComponent({ columns, data, loading }) {
  const tableRef = useRef(null);
  const [tableHeight, setTableHeight] = useState(400); // Valor inicial

  // Calcular altura dinámicamente
  useEffect(() => {
    const updateHeight = () => {
      if (tableRef.current) {
        // Altura del viewport menos los elementos fijos (header, título, etc.)
        const windowHeight = window.innerHeight;
        const headerHeight =
          document.querySelector('.ant-table-header')?.offsetHeight || 0;
        const otherElementsHeight = 200; // Ajusta según tu diseño

        const newHeight =
          windowHeight - headerHeight - otherElementsHeight - 40; // 40px de margen
        setTableHeight(Math.max(newHeight, 300)); // Mínimo 300px
      }
    };

    updateHeight();
    window.addEventListener('resize', updateHeight);
    return () => window.removeEventListener('resize', updateHeight);
  }, [data]);

  return (
    <ConfigProvider
      theme={{
        components: {
          Table: {
            headerBg: 'rgb(64,64,64)',
            colorBgContainer: 'rgb(91,91,91)',
            headerColor: 'rgba(255,255,255,0.88)',
            colorText: 'rgba(255,255,255,0.88)',
            fontSize: 18,
            borderColor: 'transparent',
            headerBg: '#252525',
            colorBgContainer: '#2f3035',
          },
        },
      }}
    >
      <div
        ref={tableRef}
        style={{ flex: 1, display: 'flex', flexDirection: 'column' }}
      >
        <Table
          loading={loading}
          tableLayout="auto"
          rowKey="id"
          className={styles.table}
          columns={columns}
          dataSource={data}
          pagination={false}
          scroll={{ y: tableHeight }}
          style={{
            flex: 1,
          }}
        />
      </div>
    </ConfigProvider>
  );
}
