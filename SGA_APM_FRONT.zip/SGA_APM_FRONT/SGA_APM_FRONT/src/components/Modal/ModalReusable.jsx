import React from 'react';
import { Modal, DatePicker, ConfigProvider } from 'antd';
import './ModalReusable.module.css';
import ButtonComponent from '../Button/Button';

const { RangePicker } = DatePicker;

const DateRangeModal = ({ visible, onOk, onCancel, onDateChange }) => {
  const handleDateChange = (dates, dateStrings) => {
    onDateChange(dates, dateStrings);
  };

  return (
    <ConfigProvider
      theme={{
        token: {
          colorPrimary: '#006400',
        },
        components: {
          Modal: {
            colorBgBase: '#333',
            colorTextBase: '#fff',
            algorithm: true,
          },
        },
      }}
    >
      <Modal
        open={visible}
        onOk={onOk}
        footer={null}
        onCancel={onCancel}
        centered
        styles={{
          body: {
            fontSize: '1.5rem',
            gap: '1rem',
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
          },
        }}
      >
        <h1>Seleccione un rango de fechas</h1>
        <RangePicker
          placeholder={['Inicio', 'Fin']}
          allowEmpty={[false, true]}
          onChange={handleDateChange}
          format="DD/MM/YYYY"
          style={{ margin: '0 auto' }}
        />
        <ButtonComponent text="Aplicar" background="#006400" onClick={onOk} />
      </Modal>
    </ConfigProvider>
  );
};

export default DateRangeModal;
