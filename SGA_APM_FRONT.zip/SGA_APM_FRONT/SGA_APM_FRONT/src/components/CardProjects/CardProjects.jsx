import {
  ArrowRight,
  CalendarDays,
  Clock,
  FileEdit,
  XCircle,
  CheckCircle2,
} from 'lucide-react';
import styles from './CardProjects.module.css';

export default function CardProjects({
  onClick,
  projectName,
  asistances,
  tardances,
  absences,
  justifieds,
}) {
  return (
    <div className={styles.container} onClick={onClick}>
      <div className={styles.card}>
        <div className={styles.header}>
          <div className={styles.projectName}>
            <h3>{projectName}</h3>
          </div>
          <div className={styles.projectDate}>
            <CalendarDays size={18} />
            <span>31 de mayo de 2025</span>
          </div>
        </div>

        <div className={styles.statsGrid}>
          <div className={`${styles.statItem} ${styles.asistances}`}>
            <CheckCircle2 size={20} className={styles.statIcon} />
            <div className={styles.statContent}>
              <span className={styles.statLabel}>Asistencias</span>
              <span className={styles.statValue}>{asistances}</span>
            </div>
          </div>

          <div className={`${styles.statItem} ${styles.tardances}`}>
            <Clock size={20} className={styles.statIcon} />
            <div className={styles.statContent}>
              <span className={styles.statLabel}>Tardanzas</span>
              <span className={styles.statValue}>{tardances}</span>
            </div>
          </div>

          <div className={`${styles.statItem} ${styles.absences}`}>
            <XCircle size={20} className={styles.statIcon} />
            <div className={styles.statContent}>
              <span className={styles.statLabel}>Ausencias</span>
              <span className={styles.statValue}>{absences}</span>
            </div>
          </div>

          <div className={`${styles.statItem} ${styles.justifieds}`}>
            <FileEdit size={20} className={styles.statIcon} />
            <div className={styles.statContent}>
              <span className={styles.statLabel}>Justificados</span>
              <span className={styles.statValue}>{justifieds}</span>
            </div>
          </div>
        </div>

        <div className={styles.footer}>
          <button className={styles.actionButton}>
            Ingresar <ArrowRight size={18} />
          </button>
        </div>
      </div>
    </div>
  );
}
