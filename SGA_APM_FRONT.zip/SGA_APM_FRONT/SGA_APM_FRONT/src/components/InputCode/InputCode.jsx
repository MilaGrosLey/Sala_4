import { ConfigProvider, Input } from 'antd';
import styles from './InputCode.module.css';

export default function InputCode({ placeholder, onChange, value }) {
  return (
    <ConfigProvider
      theme={{
        components: {
          Input: {
            colorBgContainer: '#2a2a2a',
            colorBorder: '#444',
            colorText: '#ffffff',
            colorTextPlaceholder: '#666',
            hoverBorderColor: '#2f3035',
            activeBorderColor: '#2f3035',
            borderRadius: 8,
            paddingBlock: 10,
            paddingInline: 15,
            fontSize: 16,
          },
        },
      }}
    >
      <div className={styles.inputContainer}>
        <Input
          placeholder={placeholder}
          onChange={onChange}
          value={value}
          className={styles.codeInput}
        />
      </div>
    </ConfigProvider>
  );
}
