import React from 'react';
import { Button } from 'antd';
import dayjs from 'dayjs';
import styles from './DashboardHeader.module.css';

const DashboardHeaderComponent = ({ title }) => {
  const currentDate = dayjs().format('D [de] MMMM, YYYY');

  return (
    <div className={styles.header}>
      <div className={styles.titleContainer}>
        <h1 className={styles.title}>{title}</h1>
        <p className={styles.date}>{currentDate}</p>
      </div>
      <div className={styles.buttonContainer}>
        <Button className={styles.button}>Último Mes</Button>
        <Button className={styles.button}>3 Meses</Button>
        <Button className={styles.button}>4 Meses</Button>
        <Button className={styles.button}>Personalizado</Button>
      </div>
    </div>
  );
};

export default DashboardHeaderComponent;
