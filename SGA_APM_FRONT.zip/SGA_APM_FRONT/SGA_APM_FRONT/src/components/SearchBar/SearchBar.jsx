import { ConfigProvider } from 'antd';
import Input from 'antd/es/input/Input';

export default function SearchBarComponent({ placeholder, onChange }) {
  return (
    <ConfigProvider
      theme={{
        components: {
          Input: {
            colorBgContainer: '#3d3e42',
            colorBorder: '#5a5b60',
            colorText: '#ffffff',
            colorTextPlaceholder: '#a0a0a0',
            hoverBorderColor: '#19b12d',
            activeBorderColor: '#19b12d',
            fontSize: 16,
          },
        },
      }}
    >
      <Input placeholder={placeholder} onChange={onChange} />
    </ConfigProvider>
  );
}
