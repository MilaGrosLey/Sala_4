import { Button, ConfigProvider } from 'antd';
import styles from './Button.module.css';

export default function ButtonComponent({
  key,
  text,
  onClick,
  background,
  hover,
  block,
}) {
  return (
    <ConfigProvider
      theme={{
        components: {
          Button: {
            defaultBg: background,
            defaultHoverBg: hover,
            defaultHoverColor: '#ffffff',
            colorText: '#ffffff',
            defaultHoverBorderColor: 'transparent',
            defaultBorderColor: 'transparent',
            defaultActiveBorderColor: 'transparent',
            defaultActiveBg: hover,
            defaultActiveColor: '#ffffff',
          },
        },
      }}
    >
      <>
        <Button
          key={key}
          block={block}
          onClick={onClick}
          className={styles.btn}
        >
          {text}
        </Button>
      </>
    </ConfigProvider>
  );
}
