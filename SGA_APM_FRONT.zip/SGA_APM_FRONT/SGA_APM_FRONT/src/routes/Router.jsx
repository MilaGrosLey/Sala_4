import { createBrowserRouter, RouterProvider } from 'react-router';
import Login from '../features/auth/ui/Login';
import ForgotPassword from '../features/auth/ui/ForgotPassword/ForgotPassword';
import ChangePassword from '../features/auth/ui/ChangesPassword/ChangesPassword';
import SideBar from '../pages/SideBar/SideBar';
import ProtectedRoute from './ProtectedRoute';
import Projects from '../features/Projects/Projects';
import Employees from '../features/Employees/Employees';
import Dashboard from '../features/Dashboard/ui/Dashboard';
import Reports from '../features/Reports/Reports';
import Attendance from '../features/Attendance/Attendance';
import DashboardMember from '../features/Dashboard/ui/DashboardMember';
import Meeting from '../features/Meeting/Meeting';
import DashboardAdmin from '../features/Dashboard/ui/DashboardAdmin';
import { getRole } from '../utils/role';
import Profile from '../features/Profile/Profile';
import RegisterProyectUsusario from '../features/Register/RegisterUser/RegisterUser';
import RegisterProyect from '../features/Projects/RegisterProyect/RegisterProyect';
import Register from '../features/auth/ui/Register/Register';
import { DynamicDashboard } from '../features/Dashboard/ui/DynamicDashboard';
import Team from '../features/Team/Team';

const router = createBrowserRouter([
  {
    path: '*',
    element: <h1>404</h1>,
  },
  {
    path: '/',
    element: <Login />,
  },
  {
    path: '/contraseña-olvidada',
    element: <ForgotPassword />,
  },
  {
    path: '/cambiar-contrasena',
    element: <ChangePassword />,
  },
  {
    path: 'registrar',
    element: <Register />,
  },
  {
    path: '/Inicio',
    element: (
      <ProtectedRoute allowedRoles={['admin', 'user', 'member', 'intern']} />
    ),
    children: [
      {
        path: '',
        element: <SideBar />,
        children: [
          {
            index: true,
            element: <Attendance />,
          },
          {
            path: 'asistencia',
            element: <Attendance />,
          },
          {
            path: 'asistencia/:id',
            element: <Meeting />,
          },
          {
            path: 'estadisticas',
            element: <DynamicDashboard />,
          },
          {
            path: 'perfil',
            element: <Profile />,
          },

          {
            path: 'reportes',
            element: <Reports />,
          },
          {
            path: 'gestionar-usuarios',
            element: (
              <ProtectedRoute allowedRoles={['admin', 'member', 'intern']} />
            ),
            children: [{ index: true, element: <Employees /> }],
          },
          {
            path: 'gestionar-projectos',
            element: <ProtectedRoute allowedRoles={['admin', 'intern']} />,
            children: [{ index: true, element: <Projects /> }],
          },
          {
            path: 'gestionar-projectos/registro',
            element: <ProtectedRoute allowedRoles={['admin']} />,
            children: [
              {
                index: true,
                element: <RegisterProyect />,
              },
            ],
          },
          {
            path: 'gestionar-equipo',
            element: <ProtectedRoute allowedRoles={['admin', 'intern']} />,
            children: [{ index: true, element: <Team /> }],
          },
          //AQUI LAS OTRAS RUTAS
        ],
      },
    ],
  },
]);

export default function Router() {
  return <RouterProvider router={router} />;
}
