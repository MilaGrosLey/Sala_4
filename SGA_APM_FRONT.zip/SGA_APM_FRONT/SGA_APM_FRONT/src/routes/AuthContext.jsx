import { createContext, useContext, useEffect, useState } from 'react';
import { getLocalStorage } from '../utils/localStorage';
import { useToast } from '../services/Toastify/Toastify';

const AuthContext = createContext();

export const useAuth = () => useContext(AuthContext);

//CAMBIAR DESPUES A API QUE VERIFIQUE EL TOKEN/ROL
export const AuthProvider = ({ children }) => {
  const { showToast } = useToast();
  const [authChecked, setAuthChecked] = useState(false);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [userRole, setUserRole] = useState(getLocalStorage('role') || null); // Inicializa con el rol del localStorage

  // Verifica solo el token al cargar la app (sin llamar a get-role)
  useEffect(() => {
    const token = getLocalStorage('token');
    setIsAuthenticated(!!token); // true si hay token, false si no
    setAuthChecked(true);
  }, []);

  return (
    <AuthContext.Provider
      value={{
        isAuthenticated,
        authChecked,
        userRole,
        setIsAuthenticated,
        setUserRole,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};