import { Navigate, Outlet } from 'react-router';
import { useAuth } from './AuthContext';
import styles from './ProtectedRoute.module.css';

const ProtectedRoute = ({ allowedRoles  }) => {
  const { isAuthenticated, authChecked, userRole } = useAuth();

  // Si no ha terminado de verificar la autenticación
  if (!authChecked) {
    return (
      <div className={styles.container}>
        <div className={styles.loader}></div>
      </div>
    );
  }

  // Si no está autenticado
  if (!isAuthenticated) {
    return <Navigate to="/" replace />;
  }

  // Si el rol no está permitido
  if (allowedRoles && !allowedRoles.includes(userRole)) {
    return <Navigate to="/Inicio" replace />;
  }

  // Todo correcto, renderizar la ruta
  return <Outlet />;
};

export default ProtectedRoute;
